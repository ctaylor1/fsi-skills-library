from pathlib import Path
import json,hashlib,sys
root=Path(__file__).resolve().parent;stage=sys.argv[1] if len(sys.argv)>1 else 'final-replay'; checks=[]
def load(case,name):return json.loads((root/stage/case/name).read_text())
def check(case,predicate,invalid=False):
 command_results=load(case,'results.json');codes=[x['exit'] for x in command_results]
 if invalid: passed=codes[:2]==[1,1]; detail='Structural intake and direct calculation both reject; no valid-output check claimed.'
 else:
  passed=codes==[0,0,0] and predicate(load(case,'output.json'));detail='Accepted input, calculation, detached-output reconstruction and independent state expectation.'
 checks.append({'check':case,'passed':bool(passed),'exit_codes':codes,'detail':detail})
check('sanctions_multiple_owners',lambda o:o['cases'][0]['ownership_assessment']['blocked_pct']==55 and o['cases'][0]['disposition_recommendation']=='recommend-true-match-escalate')
check('sanctions_future_listing',lambda o:o['cases'][0]['disposition_recommendation']=='needs-data' and any('not yet effective' in x for x in o['cases'][0]['needs']))
check('sanctions_stale_snapshot',lambda o:o['cases'][0]['disposition_recommendation']=='needs-data')
check('aml_duplicate_no_authorization',lambda o:o['triage'][0]['disposition']=='possible-duplicate')
check('aml_unknown_screening',lambda o:o['triage'][0]['disposition']=='needs-data' and o['triage'][0]['priority_band']=='Unrated')
check('aml_scoped_suppression',lambda o:o['triage'][0]['disposition']=='approved-suppressed' and o['triage'][0]['proposed_only'] is True)
check('aml_invalid_chronology',None,True)
check('sar_exact_facts',lambda o:o['packaging_status']=='needs-evidence' and o['sections']['investigation_rationale']['summary']=='')
check('sar_unmapped_claim',lambda o:o['packaging_status']=='needs-evidence' and o['sections']['narrative']['why']=='')
check('sar_future_activity',lambda o:o['packaging_status']=='needs-evidence' and any('assessment as_of' in x for x in o['sections']['amount_tie_out']['breaks']))
check('sar_unmapped_rationale',lambda o:o['packaging_status']=='needs-evidence' and o['sections']['investigation_rationale']['summary']=='')
check('exam_dated_evidence',lambda o:o['items'][0]['response_status']=='draft-ready-for-review')
check('exam_partial_period',lambda o:o['items'][0]['response_status']=='unsupported-assertion')
check('exam_conflicting_approval_records',lambda o:o['items'][0]['approvals_recorded'][1]['status']=='rejected' and o['items'][0]['response_status']=='needs-approval')
check('monitor_cluster_and_velocity_boundary',lambda o:[r['status'] for r in o['subjects'][0]['rule_results']]==['BREACH','BREACH'])
check('monitor_missing_currency',lambda o:all(r['status']=='NOT_EVALUABLE' for r in o['subjects'][0]['rule_results']) and o['subjects'][0]['recommended_disposition']=='needs_data')
check('monitor_flow_first',lambda o:o['summary']['new']==1 and o['summary']['deduplicated']==0)
check('monitor_changed_ledger_dedup',lambda o:o['summary']['new']==1 and o['summary']['deduplicated']==0)
for case,status in [('router_planned_primary','planned_capability_gap'),('router_action_request','action_requires_separate_authorization'),('router_missing_context','needs_context')]:check(case,lambda o,status=status:o['routes'][0]['status']==status and o['action_taken'] is False)
for case,track in [('cdd_complete_scope','Standard-CDD'),('cdd_future_screening','Needs-Data'),('cdd_conflicting_identity','EDD-Recommended'),('cdd_future_identity_document','Remediate-First')]:check(case,lambda o,track=track:o['recommended_track']==track and o['adjudication_required'] is True)
check('risk_complete_factors',lambda o:o['score_pct']==25 and o['recommended_review_outcome']=='Align-No-Change')
for case in ['risk_missing_factor','risk_future_factor']:check(case,lambda o:o['score_pct'] is None and o['recommended_review_outcome']=='Remediate-Data-First')
check('regulatory_proposed_past_dates',lambda o:'elapsed_compliance_deadline' not in o['raised_findings'] and o['instrument']['lifecycle_state']=='proposed')
check('regulatory_unknown_implementation',lambda o:'elapsed_compliance_deadline' not in o['raised_findings'] and any('implementation status unknown' in r['why'] for r in o['not_evaluable']))
check('regulatory_future_publication',None,True)
check('sar_conforming_mapped_rationale',lambda o:o['packaging_status']=='ready-for-quality-review' and not o['gaps'])
check('sar_isolated_future_activity',lambda o:o['packaging_status']=='needs-evidence' and o['gaps']==['amount/chronology tie-out break'])
check('sar_isolated_unmapped_rationale',lambda o:o['packaging_status']=='needs-evidence' and o['sections']['investigation_rationale']['summary']=='')
for item in load('contract','results.json')+load('contract','additional-results.json'):checks.append({'check':'contract '+item['case'],'passed':item['pass']})
manifest=json.loads((root/'initial-evidence-manifest.json').read_text());changed=[x['path'] for x in manifest if hashlib.sha256((root/x['path']).read_bytes()).hexdigest()!=x['sha256']];checks.append({'check':'original evidence integrity','passed':not changed})
result={'stage':stage,'checks':checks,'passed':sum(x['passed'] for x in checks),'total':len(checks),'all_passed':all(x['passed'] for x in checks),'original_evidence_files':len(manifest),'changed_original_files':changed,'scope':'Bounded independent synthetic tests; not professional, legal, source-truth or production acceptance.'};(root/stage/'independent-acceptance.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'stage':stage,'passed':result['passed'],'total':result['total'],'failed':[x for x in checks if not x['passed']]},indent=2));raise SystemExit(not result['all_passed'])
