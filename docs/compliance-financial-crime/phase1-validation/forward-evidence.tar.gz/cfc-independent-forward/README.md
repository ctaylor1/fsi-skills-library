# CFC independent synthetic forward evidence

Review date: 2026-09-21. See the repository's `docs/compliance-financial-crime/phase1-validation/forward-review.md` for the human review and archive SHA-256.

- `initial/`: original native failures and passing boundaries, retained input/output/commands and source scripts.
- `extended-initial/`: initial fresh CDD, customer-risk and regulatory-change probes.
- `initial-evidence-manifest.json`: SHA-256 of all 378 files in those two original stages.
- `after-repair/`: first monitoring/common-contract repair replay.
- `after-repair-native/`: intermediate native repairs, conforming SAR cases and common-contract rerun.
- `final-replay/`: final authoritative replay after direct-calculator structural validation gates.
- `final-replay/independent-acceptance.json`: 49/49 independent expectations passed: 34 native scenario outcomes, 14 common-contract expectations, and unchanged original evidence hashes.
- `driver-history/`: exact drivers before portability-only changes.
- `run_*.py`, `assess_final.py`: current portable replay and acceptance drivers. They use the real repository validators/calculators, not mocked validators. Each replay writes a separate stage below this extracted evidence directory. Never replay into an existing retained evidence stage.

All cases are synthetic. No external data, report filing, regulator contact, source-system write, source authenticity or legal/professional acceptance is claimed. Two final native cases deliberately fail structural validation and produce no valid native output; their attempted output checks on absent output are recorded but not counted as valid-output checks.

## Verify retained outputs without rerunning calculators

```sh
python3 -B assess_final.py final-replay
```

## Replay against an identified current checkout

Set `CFC_REPO_ROOT` to the actual repository checkout. It defaults to `/Users/taylor/DevRepo/Skills/fsi-skills-library`.

```sh
export CFC_REPO_ROOT=/Users/taylor/DevRepo/Skills/fsi-skills-library
python3 -B run_forward.py independent-rerun
python3 -B run_monitor_router.py independent-rerun
python3 -B run_customer_governance.py independent-rerun
python3 -B run_sar_conforming.py independent-rerun
python3 -B run_contract.py independent-rerun
python3 -B run_contract_additional.py independent-rerun
python3 -B assess_final.py independent-rerun
```

The first four drivers can run independently; the contract driver must finish before the additional contract checks, and all drivers must finish before acceptance. Exact commands used originally are retained in each case's `results.json`; the original inputs and frozen `scripts/` permit inspecting or replaying the previous behavior without substituting rewritten inputs.
