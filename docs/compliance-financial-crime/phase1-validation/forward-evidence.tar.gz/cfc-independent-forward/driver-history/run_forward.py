from pathlib import Path
import copy,json,subprocess,sys,hashlib,shutil
ROOT=Path('/Users/taylor/DevRepo/Skills/fsi-skills-library')
OUT=Path('/tmp/cfc-independent-forward')
STAGE=sys.argv[1] if len(sys.argv)>1 else 'initial'
DEST=OUT/STAGE; DEST.mkdir(exist_ok=True)
def h(d): return hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def run(name,skill,d):
 p=ROOT/'skills/compliance-financial-crime'/skill
 if not p.exists():
  aliases={'sanctions-match-adjudicator':'sanctions-match-investigator','transaction-monitoring-alert-investigator':'transaction-monitoring-scenario-evaluator'}
  p=p.parent/aliases[skill]
 case=DEST/name; case.mkdir(exist_ok=True)
 inp=case/'input.json'; out=case/'output.json'; inp.write_text(json.dumps(d,indent=2)+'\n')
 if not (case/'scripts').exists(): shutil.copytree(p/'scripts',case/'scripts',ignore=shutil.ignore_patterns('__pycache__'))
 results=[]
 for script,args in [('validate_input.py',[str(inp)]),('calculate_or_transform.py',[str(inp)]),('validate_output.py',[str(out),'--input',str(inp)])]:
  cmd=[sys.executable,'-B',str(p/'scripts'/script),*args]
  r=subprocess.run(cmd,capture_output=True,text=True,cwd=p)
  (case/(script+'.log')).write_text(r.stdout+r.stderr)
  if script=='calculate_or_transform.py': out.write_text(r.stdout)
  results.append({'command':cmd,'exit':r.returncode,'stdout':r.stdout if script!='calculate_or_transform.py' else '[output.json]','stderr':r.stderr})
 (case/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 try: result=json.loads(out.read_text())
 except Exception: result={}
 return {'case':name,'skill':p.name,'exit_codes':[r['exit'] for r in results], 'result':result}
summary=[]
sanc={'config_version':'independent-1','cases':[{'alert_id':'SA-004','as_of':'2026-09-21','screening_context':'customer','list_program':'OFAC-SDN','source_ref':'synthetic-screening-run-04','screening_provenance':{'screening_engine':'synthetic-feed','screening_run_id':'R04','screened_at':'2026-09-21','screened_by':'reviewer-a'},'subject':{'subject_id':'CLEARWATER-01','entity_type':'company','name':'Clearwater Tools LLC','source_ref':'synthetic-kyc-4','as_of':'2026-09-21','ownership':[{'owner_id':'P1','owner_name':'Person One','pct':30,'direct':True,'owner_blocked':True,'owner_list_ref':'L1','source_ref':'synthetic-register-p1'},{'owner_id':'P2','owner_name':'Person Two','pct':25,'direct':True,'owner_blocked':True,'owner_list_ref':'L2','source_ref':'synthetic-register-p2'},{'owner_id':'P3','owner_name':'Person Three','pct':45,'direct':True,'owner_blocked':False,'source_ref':'synthetic-register-p3'}]},'matched_entity':{'list_ref':'L1','entity_type':'person','program':'OFAC-SDN','primary_name':'Person One','source_ref':'synthetic-list-snapshot','retrieved_at':'2026-09-21','list_effective_date':'2025-01-01'},'prior_cases':[]}]}
summary.append(run('sanctions_multiple_owners','sanctions-match-adjudicator',sanc))
sanc_future=copy.deepcopy(sanc); sanc_future['cases'][0]['matched_entity']['list_effective_date']='2026-12-01'; summary.append(run('sanctions_future_listing','sanctions-match-adjudicator',sanc_future))
sanc_stale=copy.deepcopy(sanc); sanc_stale['cases'][0]['matched_entity']['retrieved_at']='2026-09-10'; summary.append(run('sanctions_stale_snapshot','sanctions-match-adjudicator',sanc_stale))
alert={'alert_id':'AL-81','entity_id':'E81','account_ref':'A81','rule_id':'TM81','period':{'from':'2026-09-01','to':'2026-09-20'},'amount_total':75000,'currency':'USD','txn_ids':['T81','T82'],'customer':{'risk_rating':'Medium','high_risk_geo':False},'flags':{'sanctions_adverse_media':False},'prior_alerts_90d':2,'source_ref':'synthetic-alert-export-81'}
aml={'config_version':'independent-1','as_of':'2026-09-21','open_cases':[{'case_id':'OPEN81','entity_id':'E81','rule_id':'TM81','period':alert['period'],'txn_ids':['T81','T82']}],'alerts':[alert]}
summary.append(run('aml_duplicate_no_authorization','aml-alert-triager',aml))
aml_partial=copy.deepcopy(aml); aml_partial['alerts'][0]['flags']={}; summary.append(run('aml_unknown_screening','aml-alert-triager',aml_partial))
aml_authorized=copy.deepcopy(aml); aml_authorized['suppression_authorizations']=[{'status':'approved','approved_by':'synthetic-owner','approval_ref':'APP-81','source_ref':'synthetic-approval-81','rule_id':'SUP-DUP-01','config_version':'independent-1','alert_id':'AL-81','entity_id':'E81','period':alert['period'],'txn_ids':['T81','T82'],'effective_from':'2026-09-01','effective_to':'2026-09-30'}]
summary.append(run('aml_scoped_suppression','aml-alert-triager',aml_authorized))
aml_invalid=copy.deepcopy(aml_authorized); aml_invalid['alerts'][0]['period']={'from':'2026-12-31','to':'2026-09-01'}; aml_invalid['open_cases'][0]['period']=aml_invalid['alerts'][0]['period']; aml_invalid['suppression_authorizations'][0]['period']=aml_invalid['alerts'][0]['period']; summary.append(run('aml_invalid_chronology','aml-alert-triager',aml_invalid))
facts={'who':'Customer S88 owns account A88.','what':'Two wire transfers total USD 3000.','when':'The transfers occurred on 2026-09-10 and 2026-09-11.','where':'The supplied account extract identifies US accounts.','why':'The investigator identified an unresolved purpose discrepancy.','how':'The transfers were sent by wire.'}
sar={'config_version':'independent-1','template_version':'sar-v1','as_of':'2026-09-21','jurisdiction':'US','case_id':'SAR88','case_approved_for_sar':True,'approving_investigation':'INV88','subjects':[{'subject_ref':'S88','role':'primary','type':'person','name_masked':'S88','relationship':'account owner'}],'accounts_instruments':[{'account_ref':'A88','type':'deposit','instruments':['wire']}],'activity':{'period':{'from':'2026-09-10','to':'2026-09-11'},'aggregate_amount':3000,'currency':'USD','amount_basis':'gross-listed-transactions','transaction_count':2},'transactions':[{'txn_id':'T88','date':'2026-09-10','amount':1000,'currency':'USD','instrument':'wire','subject_ref':'S88','source_ref':'synthetic-ledger-88'},{'txn_id':'T89','date':'2026-09-11','amount':2000,'currency':'USD','instrument':'wire','subject_ref':'S88','source_ref':'synthetic-ledger-89'}],'typologies':[],'narrative_inputs':facts,'evidence':[{'evidence_id':k,'fact':v,'citation':'synthetic-source-'+k} for k,v in facts.items()],'narrative_evidence_ids':{k:[k] for k in facts},'investigation_rationale':{'summary':'The documented purpose differs between two supplied records; investigator follow-up is needed.','citations':['synthetic-investigation-88']},'required_approvals':['SAR quality reviewer','BSA officer'],'recorded_approvals':[]}
def sar_auth(d):
 d['drafting_authorization']={'status':'approved','role':'BSA officer','approver':'synthetic-officer','source_ref':'synthetic-approval-88','case_id':d['case_id'],'date':'2026-09-21','input_sha256':h({k:v for k,v in d.items() if k not in {'drafting_authorization','recorded_approvals'}})}
sar_auth(sar); summary.append(run('sar_exact_facts','suspicious-activity-report-drafter',sar))
sar_claim=copy.deepcopy(sar); sar_claim['narrative_inputs']['why']='Customer deliberately laundered criminal proceeds.'; sar_auth(sar_claim); summary.append(run('sar_unmapped_claim','suspicious-activity-report-drafter',sar_claim))
sar_future=copy.deepcopy(sar); sar_future['transactions'][1]['date']='2026-12-01'; sar_future['activity']['period']['to']='2026-12-01'; sar_future['narrative_inputs']['when']='The transfers occurred on 2026-09-10 and 2026-12-01.'; sar_future['evidence'][2]['fact']=sar_future['narrative_inputs']['when']; sar_auth(sar_future); summary.append(run('sar_future_activity','suspicious-activity-report-drafter',sar_future))
sar_rationale=copy.deepcopy(sar); sar_rationale['investigation_rationale']={'summary':'Customer deliberately laundered criminal proceeds and violated every AML law.','citations':['unmapped-nonexistent-source']}; sar_auth(sar_rationale); summary.append(run('sar_unmapped_rationale','suspicious-activity-report-drafter',sar_rationale))
response={'request_id':'RQ99','narrative':'Quarterly access reviews were performed for this period.','assertions':[{'assertion_id':'A99','text':'Quarterly access reviews were performed for this period.','source_ref':'synthetic-control-register','period':{'from':'2026-01-01','to':'2026-06-30'}}],'evidence':[{'evidence_id':'EV99','description':'Dated register extract','source_ref':'synthetic-control-register','fact':'Quarterly access reviews were performed for this period.','valid_from':'2026-01-01','valid_to':'2026-06-30','superseded':False,'classification':'compliance_confidential'}],'issue_status':'open','approvals':[]}
def exam_auth(r):
 r['approvals']=[{'role':'regulatory affairs','approver_id':'synthetic-officer','status':'approved','date':'2026-09-21','source_ref':'synthetic-approval-99','request_id':'RQ99','response_sha256':h({k:v for k,v in r.items() if k!='approvals'})}]
exam_auth(response)
exam={'package_version':'independent-1','as_of':'2026-09-21','exam':{'exam_id':'EX99','regulator':'synthetic authority','scope':'access controls','period':{'from':'2026-01-01','to':'2026-06-30'}},'required_approver_roles':['regulatory affairs'],'requests':[{'request_id':'RQ99','prompt':'Supply access control performance evidence for January through June.','category':'information','evidence_required':True}],'responses':[response]}
summary.append(run('exam_dated_evidence','regulatory-exam-response-packager',exam))
exam_partial=copy.deepcopy(exam); exam_partial['responses'][0]['evidence'][0]['valid_from']='2026-03-01'; exam_auth(exam_partial['responses'][0]); summary.append(run('exam_partial_period','regulatory-exam-response-packager',exam_partial))
exam_ledger=copy.deepcopy(exam); exam_ledger['responses'][0]['approvals'].append({'role':'regulatory affairs','approver_id':'someone-else','status':'rejected','date':'2026-12-01','source_ref':'synthetic-rejection','request_id':'OTHER','response_sha256':'not-bound'}); summary.append(run('exam_conflicting_approval_records','regulatory-exam-response-packager',exam_ledger))
(DEST/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for x in summary:
 o=x['result']; status=o.get('packaging_status') or o.get('summary')
 if 'cases' in o: status=[{'disposition':r['disposition_recommendation'],'needs':r['needs'],'ownership':r.get('ownership_assessment')} for r in o['cases']]
 print(x['case'],x['exit_codes'],status)
