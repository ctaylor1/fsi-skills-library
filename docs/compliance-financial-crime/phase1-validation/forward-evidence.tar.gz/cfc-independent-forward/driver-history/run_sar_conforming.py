from pathlib import Path
import json,copy,sys
exec(Path('/tmp/cfc-independent-forward/run_forward.py').read_text().split('summary=[]')[0])
def authorize(doc):doc['drafting_authorization']['input_sha256']=h({k:v for k,v in doc.items() if k not in {'drafting_authorization','recorded_approvals'}})
source=json.loads((OUT/'initial/sar_exact_facts/input.json').read_text())
rationale=source['investigation_rationale'];source['evidence'].append({'evidence_id':'rationale-88','fact':rationale['summary'],'citation':rationale['citations'][0]});rationale['evidence_ids']=['rationale-88'];authorize(source)
results=[run('sar_conforming_mapped_rationale','suspicious-activity-report-drafter',source)]
future=copy.deepcopy(source);future['transactions'][1]['date']='2026-12-01';future['activity']['period']['to']='2026-12-01';future['narrative_inputs']['when']='The transfers occurred on 2026-09-10 and 2026-12-01.';future['evidence'][2]['fact']=future['narrative_inputs']['when'];authorize(future);results.append(run('sar_isolated_future_activity','suspicious-activity-report-drafter',future))
unmapped=copy.deepcopy(source);unmapped['investigation_rationale']['summary']='Customer deliberately laundered criminal proceeds and violated every AML law.';authorize(unmapped);results.append(run('sar_isolated_unmapped_rationale','suspicious-activity-report-drafter',unmapped))
(DEST/'sar-conforming-summary.json').write_text(json.dumps(results,indent=2)+'\n')
for x in results:print(x['case'],x['exit_codes'],x['result']['packaging_status'],x['result']['gaps'],x['result']['sections']['amount_tie_out']['breaks'])
