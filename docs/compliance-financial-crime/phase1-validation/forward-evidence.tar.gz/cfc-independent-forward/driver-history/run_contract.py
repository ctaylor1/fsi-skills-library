from pathlib import Path
import json,copy,sys,subprocess,shutil
exec(Path('/tmp/cfc-independent-forward/run_forward.py').read_text().split('summary=[]')[0])
router=ROOT/'skills/compliance-financial-crime/compliance-financial-crime-router/scripts'
sys.path.insert(0,str(router));sys.path.insert(0,str(ROOT/'shared/compliance-financial-crime'))
from cfc_contract import build_packet,validate_packet,build_handoff,validate_handoff
from native_runner import native_validate
from workflow_contract import build_artifact
sar_path=ROOT/'skills/compliance-financial-crime/suspicious-activity-report-drafter'
def authorize(doc):
 doc['drafting_authorization']['input_sha256']=h({k:v for k,v in doc.items() if k not in {'drafting_authorization','recorded_approvals'}})
def calc(doc):
 path=DEST/'contract-input.json';path.write_text(json.dumps(doc,indent=2)+'\n')
 r=subprocess.run([sys.executable,'-B',str(sar_path/'scripts/calculate_or_transform.py'),str(path)],capture_output=True,text=True)
 if r.returncode: raise ValueError(r.stderr)
 return json.loads(r.stdout)
source=json.loads((OUT/'initial/sar_exact_facts/input.json').read_text())
source['workflow']={'context':{'institution_id':'FI88','legal_entity_id':'FI88-US','capacity':'FIU drafting review','represented_party':'FI88-US','object_id':'SAR88','object_type':'reporting_case','jurisdiction':'US','line_of_business':'retail banking','purpose':'internal reporting draft review'},'as_of':source['as_of'],'role':'decision_support','classification':'sar_restricted','audience':'authorized_fiu','allowed_audiences':['authorized_fiu'],'sources':[{'source_ref':'synthetic-ledger-88','version':'ledger-v1'},{'source_ref':'synthetic-investigation-88','version':'investigation-v1'}],'unresolved_issues':['Supplied customer purpose explanations conflict.']}
authorize(source);output=calc(source)
validator=lambda out,original:native_validate(sar_path,out,original)
receiver=lambda doc:native_validate(sar_path,doc)
kwargs={'producer':sar_path.name,'native_validator':validator}
packet=build_packet(source,output,**kwargs)
results=[]
def check(name,fn,expected_rejected):
 try:
  result=fn(); errors=result if isinstance(result,list) else []
  rejected=bool(errors)
 except (ValueError,TypeError,KeyError) as exc: errors=[str(exc)];rejected=True
 results.append({'case':name,'expected_rejected':expected_rejected,'rejected':rejected,'errors':errors,'pass':rejected==expected_rejected})
check('contract_baseline',lambda:validate_packet(packet,source,**kwargs),False)
for label,mutate in [('different-detached-input',lambda d:d['transactions'][0].update(amount=2000)),('missing-source-version',lambda d:d['workflow']['sources'][0].pop('version')),('sar-classification-downgrade',lambda d:d['workflow'].update(classification='customer_pii')),('sar-customer-audience',lambda d:d['workflow'].update(audience='customer',allowed_audiences=['customer']))]:
 changed=copy.deepcopy(source);mutate(changed)
 if label=='different-detached-input':check(label,lambda:validate_packet(packet,changed,**kwargs),True)
 else:
  authorize(changed);changed_output=calc(changed);check(label,lambda:build_packet(changed,changed_output,**kwargs),True)
for label,mutate in [('invented-native-field',lambda p:p['native_output'].update(report_filed=True)),('dropped-source-issue',lambda p:p['unresolved_issues'].clear())]:
 changed=copy.deepcopy(packet);mutate(changed)
 w=changed['workflow'];metadata={k:w[k] for k in ['context','as_of','sources']};metadata['unresolved_issues']=changed['unresolved_issues'];changed['artifact']=build_artifact(metadata,changed,producer=sar_path.name,artifact_type='compliance-review',completeness='partial',evaluability='partial',issues=changed['unresolved_issues'])
 check(label,lambda:validate_packet(changed,source,**kwargs),True)
target=copy.deepcopy(source);target['workflow']['unresolved_issues']=copy.deepcopy(packet['unresolved_issues']);authorize(target)
supplemental={'reviewed_workflow':target['workflow'],'reviewed_drafting_authorization':target['drafting_authorization']}
mappings=[]
for key in target:
 supplemental_field=key in ['workflow','drafting_authorization']
 mappings.append({'target_field':key,'source':'supplemental' if supplemental_field else 'source_input','source_pointer':'/reviewed_'+key if supplemental_field else '/'+key,'basis':'Exact retained evidence; synthetic reviewer assessment only','reviewed_by':'synthetic-FIU-reviewer','source_refs':['synthetic-FIU-mapping-88']})
hargs={'producer':sar_path.name,'target_skill':sar_path.name,'producer_validator':validator,'receiver_validator':receiver,'mappings':mappings,'supplemental_inputs':supplemental}
handoff=build_handoff(packet,source,target,**hargs)
validate_args={k:v for k,v in hargs.items() if k!='mappings'}
check('same-context-handoff',lambda:validate_handoff(handoff,source,**validate_args),False)
changed=copy.deepcopy(handoff);changed['target_input']['transactions'][0]['amount']=9000;check('changed-receiver-field',lambda:validate_handoff(changed,source,**validate_args),True)
changed=copy.deepcopy(handoff);changed['target_input']['workflow']['unresolved_issues']=[];check('dropped-inherited-issues',lambda:validate_handoff(changed,source,**validate_args),True)
changed=copy.deepcopy(handoff);changed['target_input']['workflow']['audience']='regulator';changed['target_input']['workflow']['allowed_audiences']=['regulator'];check('audience-change',lambda:validate_handoff(changed,source,**validate_args),True)
changed=copy.deepcopy(handoff);changed['target_input']['workflow']['context']['institution_id']='OTHER-BANK';check('cross-institution',lambda:validate_handoff(changed,source,**validate_args),True)
case=DEST/'contract';case.mkdir(exist_ok=True)
for file,data in [('source-input',source),('native-output',output),('packet',packet),('target-input',target),('supplemental-inputs',supplemental),('handoff',handoff),('results',results)]: (case/(file+'.json')).write_text(json.dumps(data,indent=2)+'\n')
if not (case/'contract-source.py').exists():shutil.copyfile(ROOT/'shared/compliance-financial-crime/cfc_contract.py',case/'contract-source.py')
print(json.dumps(results,indent=2));print('PASS',sum(r['pass'] for r in results),'OF',len(results))
