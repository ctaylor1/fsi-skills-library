from pathlib import Path
import json,sys,copy,hashlib
ROOT=Path('/Users/taylor/DevRepo/Skills/fsi-skills-library');OUT=Path('/tmp/cfc-independent-forward');STAGE=sys.argv[1] if len(sys.argv)>1 else 'after-repair'
path=OUT/STAGE/'contract';sys.path.insert(0,str(ROOT/'skills/compliance-financial-crime/compliance-financial-crime-router/scripts'));sys.path.insert(0,str(ROOT/'shared/compliance-financial-crime'))
from cfc_contract import build_handoff
from native_runner import native_validate
source=json.loads((path/'source-input.json').read_text());packet=json.loads((path/'packet.json').read_text());original_target=json.loads((path/'target-input.json').read_text());handoff=json.loads((path/'handoff.json').read_text());p=ROOT/'skills/compliance-financial-crime/suspicious-activity-report-drafter'; results=[]
for name,mutation in [('drop_source_record',lambda d:d['workflow']['sources'].pop()),('replace_source_version',lambda d:d['workflow']['sources'][0].update(version='unrelated-v2'))]:
 target=copy.deepcopy(original_target);mutation(target)
 target['drafting_authorization']['input_sha256']=hashlib.sha256(json.dumps({k:v for k,v in target.items() if k not in {'drafting_authorization','recorded_approvals'}},sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
 supplemental={'reviewed_workflow':target['workflow'],'reviewed_drafting_authorization':target['drafting_authorization']}
 try:
  build_handoff(packet,source,target,producer=p.name,target_skill=p.name,producer_validator=lambda out,doc:native_validate(p,out,doc),receiver_validator=lambda doc:native_validate(p,doc),mappings=handoff['mappings'],supplemental_inputs=supplemental)
  errors=[]
 except ValueError as exc:errors=[str(exc)]
 results.append({'case':name,'expected_rejected':True,'rejected':bool(errors),'errors':errors,'pass':bool(errors)})
 (path/(name+'-target.json')).write_text(json.dumps(target,indent=2)+'\n');(path/(name+'-supplemental.json')).write_text(json.dumps(supplemental,indent=2)+'\n')
(path/'additional-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
