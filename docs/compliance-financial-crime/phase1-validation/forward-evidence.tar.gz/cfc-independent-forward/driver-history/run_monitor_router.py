from pathlib import Path
import json,copy,sys
exec(Path('/tmp/cfc-independent-forward/run_forward.py').read_text().split('summary=[]')[0])
summary=[]
period={'from':'2026-09-01','to':'2026-09-20'}
txns=[{'txn_id':'TX-'+str(i),'date':d,'direction':'in','amount':9500,'currency':'USD','instrument':'cash','counterparty_country':'US'} for i,d in enumerate(['2026-09-01','2026-09-17','2026-09-18','2026-09-19'])]
mon={'run_id':'M101','as_of':'2026-09-21','config_version':'independent-1','max_staleness_days':2,'open_cases':[],'rules':[{'rule_id':'S1','type':'structuring','threshold_amount':10000,'band_pct':10,'window_days':3,'min_count':3,'warn_count':2},{'rule_id':'V1','type':'velocity','multiplier':2,'warn_buffer_ratio':0}],'subjects':[{'subject_id':'S101','alert_id':'A101','escalated':True,'escalation_source':'synthetic-FIU-queue','risk_rating':'Medium','data_as_of':'2026-09-20','transactions_complete':True,'observation_period':period,'baseline_period':period,'currency':'USD','profile':{'expected_period_txns':2},'transactions':txns}]}
summary.append(run('monitor_cluster_and_velocity_boundary','transaction-monitoring-alert-investigator',mon))
partial=copy.deepcopy(mon);partial['subjects'][0]['transactions'][0].pop('currency');summary.append(run('monitor_missing_currency','transaction-monitoring-alert-investigator',partial))
flow=copy.deepcopy(mon);flow['rules']=[{'rule_id':'F1','type':'pass_through','min_ratio_pct':90,'warn_buffer_pct':0,'min_inflow':1000}];flow['subjects'][0]['transactions']=[{'txn_id':'I1','date':'2026-09-10','direction':'in','amount':10000,'currency':'USD','instrument':'wire','counterparty_country':'US'},{'txn_id':'O1','date':'2026-09-11','direction':'out','amount':9500,'currency':'USD','instrument':'wire','counterparty_country':'US'}]
first=run('monitor_flow_first','transaction-monitoring-alert-investigator',flow);summary.append(first)
changed=copy.deepcopy(flow);changed['subjects'][0]['transactions'][1]['txn_id']='DIFFERENT-LEG';changed['subjects'][0]['transactions'][1]['date']='2026-09-19';changed['open_cases']=[{'fingerprint':first['result']['indicators'][0]['fingerprint']}];summary.append(run('monitor_changed_ledger_dedup','transaction-monitoring-alert-investigator',changed))
router=ROOT/'skills/compliance-financial-crime/compliance-financial-crime-router'
routes=json.loads((router/'references/routes.json').read_text())['routes']
for r in routes:
 if r['primary']['support_status']=='planned': chosen=r;break
request={'request_id':'ROUTE101','as_of':'2026-09-21','subject':{'id':'FI101','type':chosen['subject_types'][0]},'context':{'institution_id':'FI101','legal_entity_id':'FI101-US','jurisdiction':'US','role':'oversight'},'intents':[chosen['id']],'requested_action':'analyze','available_skills':[s['name'] for s in chosen['supporting']],'provided_data':chosen['required_data']}
summary.append(run('router_planned_primary','compliance-financial-crime-router',request))
request2=copy.deepcopy(request);request2['requested_action']='file';summary.append(run('router_action_request','compliance-financial-crime-router',request2))
request3=copy.deepcopy(request);request3['context'].pop('institution_id');summary.append(run('router_missing_context','compliance-financial-crime-router',request3))
(DEST/'monitor-router-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for x in summary:
 o=x['result'];print(x['case'],x['exit_codes'],o.get('subjects') or [(r['id'],r['status']) for r in o.get('routes',[])],o.get('summary'))
