#!/usr/bin/env python3
"""Offline adversarial regressions; synthetic fixtures do not prove professional acceptance."""
import copy
import json
from pathlib import Path
import unittest
import calculate_or_transform as c
import validate_output as v
from native_integrity import attach_source

class Phase1Tests(unittest.TestCase):
    def source(self):
        return json.loads((Path(__file__).resolve().parents[1]/"evals/files/run_example.json").read_text())

    def compute(self,d):
        return c.compute(d)

    def test_golden_reconstruction(self):
        d=self.source();self.assertEqual(v.validate(self.compute(d),d),[])
    def test_detached_original_required(self):
        self.assertTrue(v.validate(self.compute(self.source())))
    def test_unbound_extra_output_rejected(self):
        d=self.source();out=self.compute(d);out['invented_claim']='approved';self.assertTrue(v.validate(out,d))
    def test_raw_input_embedding_rejected(self):
        d=self.source();out=self.compute(d);out['source_input']=copy.deepcopy(d);self.assertTrue(v.validate(out,d))
    def test_hash_does_not_authenticate(self):
        d=self.source();out=self.compute(d);self.assertEqual(out['source_truth'],'unverified');out['source_truth']='verified';self.assertTrue(v.validate(out,d))
    def test_rehashed_fabrication_rejected(self):
        original=self.source();changed=copy.deepcopy(original)
        if 'alerts' in changed:changed['alerts'][0]['amount_total']+=100000
        elif 'cases' in changed:changed['cases'][0]['subject']['name']='Fabricated Name'
        elif 'subjects' in changed and 'run_id' in changed:changed['subjects'][0]['transactions'][0]['amount']+=100000
        elif 'transactions' in changed:changed['transactions'][0]['amount']+=100000
        else:changed['responses'][0]['narrative']='Fabricated response'
        forged=attach_source(self.compute(changed),original)
        self.assertTrue(v.validate(forged,original))
    def test_wrong_original_rejected(self):
        d=self.source();out=self.compute(d);other=copy.deepcopy(d);other['detached_evidence_changed']=True;self.assertTrue(v.validate(out,other))

    def one(self):
        d=self.source();d['subjects']=d['subjects'][2:3];return d
    def test_missing_freshness_is_unknown(self):
        d=self.one();d['subjects'][0].pop('data_as_of');r=c.compute(d)['subjects'][0]
        self.assertEqual(r['recommended_disposition'],'needs_data');self.assertTrue(all(x['status']=='NOT_EVALUABLE' for x in r['rule_results']))
    def test_missing_baseline_is_not_pass(self):
        d=self.one();d['subjects'][0]['profile']={};r=c.compute(d)['subjects'][0]
        self.assertEqual(next(x for x in r['rule_results'] if x['rule_id']=='VELOCITY-5X')['status'],'NOT_EVALUABLE');self.assertEqual(r['recommended_disposition'],'needs_data')
    def test_missing_country_is_not_zero_exposure(self):
        d=self.one();d['subjects'][0]['transactions'][0].pop('counterparty_country');r=c.compute(d)['subjects'][0]
        self.assertEqual(next(x for x in r['rule_results'] if x['rule_id']=='HR-GEO-20')['status'],'NOT_EVALUABLE')
    def test_rolling_window_ignores_outlier(self):
        d=self.source();s=d['subjects'][0];t=copy.deepcopy(s['transactions'][0]);t.update(txn_id='OLDER',date='2026-07-01');s['transactions'].append(t)
        r=c.compute(d);self.assertTrue(any(i['subject_id']==s['subject_id'] and i['rule_type']=='structuring' and i['status']=='BREACH' for i in r['indicators']))
    def test_mixed_currency_not_summed(self):
        d=self.one();d['subjects'][0]['transactions'][0]['currency']='EUR';self.assertFalse(c.compute(d)['subjects'][0]['evaluation_complete'])
    def test_changed_evidence_changes_fingerprint(self):
        d=self.source();a=c.compute(d);d['subjects'][0]['transactions'][0]['amount']=9600;b=c.compute(d)
        af={x['fingerprint'] for x in a['indicators'] if x['subject_id']=='CUST-1001'};bf={x['fingerprint'] for x in b['indicators'] if x['subject_id']=='CUST-1001'};self.assertNotEqual(af,bf)
    def test_incomplete_ledger_not_clean(self):
        d=self.one();d['subjects'][0]['transactions_complete']=False;self.assertEqual(c.compute(d)['subjects'][0]['recommended_disposition'],'needs_data')
    def test_negative_amount_not_zero(self):
        d=self.one();d['subjects'][0]['transactions'][0]['amount']=-1;self.assertEqual(c.compute(d)['subjects'][0]['recommended_disposition'],'needs_data')

    def test_malformed_original_structure_rejected(self):
        original=self.source();output=self.compute(original);malformed=copy.deepcopy(original)
        key=next(k for k in ('alerts','cases','requests','transactions','subjects') if k in malformed)
        malformed[key]='wrong type'
        try:
            output=self.compute(malformed)
        except (TypeError, ValueError, KeyError, AttributeError, IndexError):
            return
        self.assertTrue(v.validate(output,malformed))
    def test_nonfinite_original_rejected(self):
        original=self.source();output=self.compute(original);original['invalid_number']=float('nan')
        self.assertTrue(v.validate(output,original))
    def test_empty_required_population_rejected(self):
        original=self.source();output=self.compute(original)
        key=next(k for k in ('alerts','cases','requests','transactions','subjects') if k in original)
        original[key]=[]
        output=self.compute(original)
        self.assertTrue(v.validate(output,original))

if __name__ == '__main__':
    unittest.main()
