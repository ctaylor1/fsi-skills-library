from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parent
def output(stage,case):return json.loads((root/stage/case/'output.json').read_text())
checks=[]
def check(name,result):checks.append({'check':name,'passed':bool(result)})
a=output('after-repair-native','aml_invalid_chronology');check('F1 AML bad chronology cannot suppress',a['triage'][0]['disposition']=='needs-data' and a['summary']['approved_suppressed']==0)
a=output('after-repair-native','sar_isolated_future_activity');check('F2 SAR future activity is incomplete',a['packaging_status']=='needs-evidence' and a['gaps']==['amount/chronology tie-out break'])
a=output('after-repair-native','sar_isolated_unmapped_rationale');check('F3 Unsupported SAR rationale withheld',a['packaging_status']=='needs-evidence' and a['sections']['investigation_rationale']['summary']=='')
a=output('after-repair-native','exam_conflicting_approval_records');check('F4 Rejected exam record preserved',a['items'][0]['approvals_recorded'][1]['status']=='rejected' and a['items'][0]['response_status']=='needs-approval')
a=output('after-repair-native','sanctions_future_listing');check('F5 Future listing is incomplete',a['cases'][0]['disposition_recommendation']=='needs-data' and any('not yet effective' in x for x in a['cases'][0]['needs']))
a=output('after-repair','monitor_cluster_and_velocity_boundary');check('F6 Velocity equality is BREACH',a['subjects'][0]['rule_results'][1]['status']=='BREACH')
a=output('after-repair','monitor_changed_ledger_dedup');check('F7 Changed ledger is new evidence',a['summary']['new']==1 and a['summary']['deduplicated']==0)
a=output('after-repair-native','sar_conforming_mapped_rationale');check('New conforming SAR positive passes',a['packaging_status']=='ready-for-quality-review' and not a['gaps'])
for item in json.loads((root/'after-repair-native/contract/results.json').read_text())+json.loads((root/'after-repair-native/contract/additional-results.json').read_text()):check('Contract '+item['case'],item['pass'])
manifest=json.loads((root/'initial-evidence-manifest.json').read_text());changed=[x['path'] for x in manifest if hashlib.sha256((root/x['path']).read_bytes()).hexdigest()!=x['sha256']];check('Original evidence unchanged',not changed)
result={'scope':'Independent synthetic forward checks only; no legal or professional acceptance','checks':checks,'passed':sum(x['passed'] for x in checks),'total':len(checks),'all_passed':all(x['passed'] for x in checks),'preserved_original_files':len(manifest),'changed_original_files':changed}
(root/'intermediate-acceptance.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));raise SystemExit(not result['all_passed'])
