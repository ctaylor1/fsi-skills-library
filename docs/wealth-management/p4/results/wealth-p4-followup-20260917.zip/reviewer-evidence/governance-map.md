# Independent follow-up review evidence

Finalized at 2026-09-17T23:13:18.588792Z.

Reviewer /root/governance_map is independent of the fresh CLI response generators, authored the predeclared cases/rubrics, can see condition labels and is aware of the focused corrections and original failures. These are previously seen synthetic cases, not holdout cases, blind grading or independent rubric design. Backend model identity remains unknown; requested CLI configuration does not authenticate the serving model.

The frozen case and rubric bytes were compared with the initial experiment and are identical. This is a separate correction experiment using a later skill snapshot; no initial first-pass record was overwritten. No additional tuning is implied by these findings.

Review unit: final reply plus retained generated human-readable and structured deliverables, source packets and tool-event traces. Incidental runtime cache files are retained as provenance but not treated as requested advisor deliverables. Script validation is not source authentication. Semantic baseline workflow names receive equal credit; CLI invocation is not required. No external action was observed in these tool traces. Runtime records identify separate sessions/workdirs, not a hermetic read filesystem.

Manifest SHA256: 97d05d69a9f65fd3d8eda0103d139e1141cc2e847e73ac090e44a09d3a90d1a5. Snapshot SHA256: 5835509ea797f010959fb37ad207b33ce38a718e32f944d882f0b827e87bff59.

| Run | Result | Item counts | UTC review time | Review SHA256 |
| --- | --- | --- | --- | --- |
| P4-02--with-skill | fail | {'fail': 2, 'pass': 8} | 2026-09-17T23:07:57.347184Z | 52bcb40bb3fad67a273525bc9d18a5eaff1c63aaf52c4c3986b7b4718dcfc16f |
| P4-02--without-skill | fail | {'pass': 4, 'fail': 6} | 2026-09-17T23:07:57.340510Z | 9fae5dd4496eb12aba823145e8a7a83b395dcd724d15e744deb4032e1132102f |
| P4-03--with-skill | pass | {'pass': 9} | 2026-09-17T23:09:55.318139Z | 90113c52db7562fe28fe8dc10a11f573bd9b2a85ed30ad715a72610444f93043 |
| P4-03--without-skill | fail | {'pass': 8, 'fail': 1} | 2026-09-17T23:10:57.395675Z | b63b03bc964d0a51aec40cf857980b552b9801b60983949a31b692eee9761e95 |

Validated 4 review records; item totals: {'pass': 29, 'fail': 9, 'not-assessed': 0}.

Each frozen rubric item is scored. Any failed item fails its run. Multiple failed items can reflect one defect, and critical-severity omissions do not necessarily represent unsafe actions. The narrow same-case observations do not establish statistical reliability, causal skill lift, professional acceptance, source authentication or production readiness.

## Findings

- P4-02 baseline: 4 pass / 6 fail. It now separately excludes disputed/missing accounts from supported assets, earning BAL credit. It omits the supported partial net of640000, two risk diagnostics, the12-month loan payoff and literal issue lineage, and still misses the reserved-pool10000 overallocation. Conditional legacy ranges are honestly labeled, so CIT passes.
- P4-02 with skill: 8 pass / 2 fail. Targeted priority/account-ID repair is observed: missing priorities and GP-1 account IDs remain null; useful economics and risk/cash-flow calculations survive. However planning_input.json55–62 invents upstream origin RISK-BIRCH-OPEN for the capacity-refresh concern, citing B6, which never supplies that artifact. The output repeats it. CIT and HAND fail from this single source-lineage defect; the two original reconciliation concerns are preserved and ISSUE passes.
- P4-03 baseline: 8 pass / 1 fail. Complete correct retirement arithmetic and IPS signature blockers, but literal liquidity-not-quantified code and original exact concern message are absent from the delivered documents. RP-CEDAR-4 and the meaning are preserved, so broad HAND passes and narrow LINE fails.
- P4-03 with skill: 9 pass. The IPS objective priority stays null, all required numerical results and exact RP-CEDAR-4 concern survive, and approvals/signature remain blocked. This is one corrected same-case observation, not proof of general source fidelity.

## P4-02--with-skill evidence

Runtime interval: 2026-09-17T22:59:42.167587Z to 2026-09-17T23:06:17.329859Z. Bound retained bytes checked by review validator.

- hidden/cases/P4-02.json — SHA256 b1cd07d79c2ccf8bf7da6cb300bbcc538d930b213af7561a9696fc1724896842
- hidden/rubrics/P4-02.json — SHA256 269de05f052572e7cde8974b8de6c93af579e325c26b17d6defce7e953c2bcdd
- artifacts/P4-02--with-skill/runtime.json — SHA256 34b1019dc647d70a1f7cff549a4788f4875b527a41fa9f47101a2bb44e3b9c64
- artifacts/P4-02--with-skill/events.jsonl — SHA256 465a7b209aace018d039e190641150d933f0d6857758887aa8d5bbc3a5514ce5
- artifacts/P4-02--with-skill/response.md — SHA256 b259f601e82e3538fdfaaa9381380b782b092bc2a50249b805bffa6782bd6e6b
- artifacts/P4-02--with-skill/generated/artifacts/HH-BIRCH-internal-review.md — SHA256 3f5b519ba16ad18df0296a5a2306d971a4de7f91df6696ddca8f33550c91d0ec
- artifacts/P4-02--with-skill/generated/artifacts/planning_input.json — SHA256 3344e06bf3a28fde5e32ae7d3dad937cca156b333a697354f2f26b2bb8ba5253
- artifacts/P4-02--with-skill/generated/artifacts/planning_output.json — SHA256 159cc9ac679763f09bca1f15967c574853e6093de0b9ee6a10ca73a264607eee
- artifacts/P4-02--with-skill/generated/artifacts/reconciliation_input.json — SHA256 bd90460995f56743c4b8f2c6eea708ff9bffac1e2896371d973a039f5a9caf24
- artifacts/P4-02--with-skill/generated/artifacts/reconciliation_output.json — SHA256 3a862026a4c1d3f78b39df440e48834cb864dfc0fd89c205f9c213f3b5a52c70
- artifacts/P4-02--with-skill/generated/artifacts/risk_input.json — SHA256 3e52537546040da7033f15a0cdb4e50951b80e0ad701c2758d3cb24c7ae9a4d6
- artifacts/P4-02--with-skill/generated/artifacts/risk_output.json — SHA256 a566c8bdffc552abef763182f029d7a5c9c5346a0239273e1d5c4885d9543257
- artifacts/P4-02--with-skill/generated/artifacts/router_input.json — SHA256 6dede42455935cbf14e6daba2ba31b77c8aac39cf746f0f0b72149ae0e6f6a77
- artifacts/P4-02--with-skill/generated/artifacts/router_output.json — SHA256 8fc357a603fbe6508e4b7e536c0e2dec3263d6ec85e3ff49c2d3bb8303d3e53b

## P4-02--without-skill evidence

Runtime interval: 2026-09-17T22:59:42.163105Z to 2026-09-17T23:03:15.554790Z. Bound retained bytes checked by review validator.

- hidden/cases/P4-02.json — SHA256 b1cd07d79c2ccf8bf7da6cb300bbcc538d930b213af7561a9696fc1724896842
- hidden/rubrics/P4-02.json — SHA256 269de05f052572e7cde8974b8de6c93af579e325c26b17d6defce7e953c2bcdd
- artifacts/P4-02--without-skill/runtime.json — SHA256 3d869952d8290dc4493d27511bf219219ae4fa2625cbf44abfe9459754a0503e
- artifacts/P4-02--without-skill/events.jsonl — SHA256 5555193665fd608783763b1f9ed022882007e917edfb252473be17a0eff82d0a
- artifacts/P4-02--without-skill/response.md — SHA256 6fda0a9124794874f7681db9d323b3836538fefaddcdda7b8bf44c601c76f3d2
- artifacts/P4-02--without-skill/generated/HH-BIRCH_internal_review_draft.md — SHA256 029d6255b5b59630a5e3d05749b9e5d8a15c39afc858453a8e5f0884ec7e4b17
- artifacts/P4-02--without-skill/generated/calc_hh_birch.py — SHA256 a115952f4517ec2eedb03246c0807f52255d4224247c2c76a32db8491dbbd111

## P4-03--with-skill evidence

Runtime interval: 2026-09-17T23:03:15.574336Z to 2026-09-17T23:08:41.751232Z. Bound retained bytes checked by review validator.

- hidden/cases/P4-03.json — SHA256 bb7243046ccb8a641e1136b03bfeec95801eee5bfbd4ecc1411344171a546961
- hidden/rubrics/P4-03.json — SHA256 4d71086fafd37c6123395a64a47fe9f605025a87b4c2776cecc771460c4be6e5
- artifacts/P4-03--with-skill/runtime.json — SHA256 c96ee7617ac04f0bdddf8d6a28a6c824f66b329c090424e45962b43ad80bc0dc
- artifacts/P4-03--with-skill/events.jsonl — SHA256 b513fb4751562c85328ee86cbc966023895d5a5a4b63638e56ae8aaea615e4a9
- artifacts/P4-03--with-skill/response.md — SHA256 4d923b2e11f6e2ee7dba17620e62ebad25995a9e0809c7cf7affa39b726b818d
- artifacts/P4-03--with-skill/generated/HH-CEDAR_IPS_revision_memo.md — SHA256 d84063af4e452db7258d84e1f44121cc84c3855211560b4e2d4c840e8a54a1a8
- artifacts/P4-03--with-skill/generated/HH-CEDAR_two_year_retirement_cash_flow_illustration.md — SHA256 0debb080ac95a8ea755e7029b9859e20939489377b50a1923152212e10fb4072
- artifacts/P4-03--with-skill/generated/ips_revision_output.json — SHA256 139e64dd7647d9710d9593c48c069b886988b1789dc93ae1d2ceefd84aada170
- artifacts/P4-03--with-skill/generated/ips_revision_request.json — SHA256 a8bd66db61875108276149bdd378c7ab43b17cc82b5199b9ac59894ac6bc3e63
- artifacts/P4-03--with-skill/generated/retirement_cash_flow_output.json — SHA256 15a8f9b18fcf5a7f30c50533a001951224d10bfb97d5d02e2a48fa4946656942
- artifacts/P4-03--with-skill/generated/retirement_cash_flow_request.json — SHA256 2ec52426a5ae547dc28ea432928e1d4811897dc7c3c677f24e2efd0519dd3709
- artifacts/P4-03--with-skill/generated/tmp/xcrun_db — SHA256 767b97e4e6c44f3e9a7b2496c54bcc1c3901650873f4fc67d811e051bd9f6e8b

## P4-03--without-skill evidence

Runtime interval: 2026-09-17T23:06:17.332036Z to 2026-09-17T23:09:28.253539Z. Bound retained bytes checked by review validator.

- hidden/cases/P4-03.json — SHA256 bb7243046ccb8a641e1136b03bfeec95801eee5bfbd4ecc1411344171a546961
- hidden/rubrics/P4-03.json — SHA256 4d71086fafd37c6123395a64a47fe9f605025a87b4c2776cecc771460c4be6e5
- artifacts/P4-03--without-skill/runtime.json — SHA256 6204cd671bdf0e90d900913e6926f99809fc2aa6e55828dbe61b5fd61b977701
- artifacts/P4-03--without-skill/events.jsonl — SHA256 a3d3a9987d105102c4dcdc250c89d6aa66dd7f28878d95837985f5b2bc8395ff
- artifacts/P4-03--without-skill/response.md — SHA256 9eaab5a1b902be69b0f1213b5937372682d86e9503cca24c6233cbca66b8c863
- artifacts/P4-03--without-skill/generated/cash_flow_calculation_audit.md — SHA256 304d8ce59e7dcd664bf7500bf97d3bc4209444924a849d2b835271aff5541034
- artifacts/P4-03--without-skill/generated/ips_revision_memo.md — SHA256 06fca2d7d2d27e2ca671623d1b4b947eea2a91af72f032dfc5ee1dc99720ae09
- artifacts/P4-03--without-skill/generated/two_year_cash_flow_illustration.md — SHA256 c758ef9c2d1f8d8497dae1ef35416133070c8da7665c5b89c231db49dbee6973
