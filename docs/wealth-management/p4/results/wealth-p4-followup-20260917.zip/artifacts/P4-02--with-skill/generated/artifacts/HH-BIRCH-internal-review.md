# HH-BIRCH Internal Balance-Sheet, Risk-Dimension and Goal-Funding Draft

Review as of 2026-09-17. Audience: advisor / planner internal review. Synthetic records only. Draft only; no client delivery, contact, system update, investment selection, risk rating or recommendation was made.

## Executive Read

Status is **needs-data** across routing, reconciliation, risk and planning artifacts. The packet supports a useful planning conversation about known cash flow, stated goals, and documented risk-dimension conflicts, but it does **not** support treating the household balance sheet, risk profile or goal funding as final.

What can safely enter a planning conversation, with labels:

- **Source assertions:** US advisory engagement, USD-only scope, household members B-A and B-B, and expected accounts JOINT-BANK, EXT-BROKER, HOME, LEGACY-ACCOUNT, HELD-AWAY-PENSION and MORTGAGE. [B1]
- **Calculator-verified partial reconciliation:** JOINT-BANK and EXT-BROKER reconcile structurally; household-share included assets are USD240,000, all partial because four expected accounts remain excluded. [B2, B3]
- **Source assertions not yet strict-reconciled:** HOME is asserted at USD600,000 and MORTGAGE as a positive USD200,000 liability, both household share 1.0 and dated 2026-09-16; the strict reconciliation artifact excluded both pending held-away classification evidence. [B2]
- **Calculator-verified cash-flow arithmetic:** USD12,000 after-tax income less USD7,000 living expenses, USD1,000 family-loan payment and USD500 reserve contribution leaves USD3,500 before goals; after stated USD2,500 goal contributions, remaining monthly cash flow is USD1,000. [B5]
- **Risk-dimension evidence:** willingness, provisional loss capacity, liquidity, horizon, experience and constraints can be discussed separately, but no risk rating is assigned and several conflicts require human review. [B4, B6]

Resolve before relying on outputs:

- LEGACY-ACCOUNT has conflicting USD90,000 and USD95,000 September 16 snapshots with no controlling source. [B3, B6]
- HELD-AWAY-PENSION is in scope but has no value, statement or ownership allocation. [B3, B6]
- The provisional CA-4 capacity assessment predates reconciliation and must be refreshed after the balance sheet is resolved. [B4, B6]
- Risk questionnaire method approval owner/reference is not evidenced in the packet; QA-22 is described as a method record, not an authenticated approval. [B4]
- GP-1 source account IDs and human goal priorities are not supplied; the planning tool withheld goal projections for those fields. [B5]
- GP-1 has USD50,000 with USD10,000 reserved, leaving USD40,000 available, while school and renovation allocations total USD50,000; that is a USD10,000 shared-pool over-allocation before considering priority. [B5]

## Reconciliation Draft

Local artifact: `household-wealth-data-reconciler-610f1e50b6521f729a8a`, status `needs-data`; output validated locally with 0 validation errors.

Strict included accounts:

| Account | Source assertion | Household value | Tool status |
| --- | ---: | ---: | --- |
| JOINT-BANK | USD120,000, share 1.0, duplicate BK-1/AG-9 observations, not held away | USD120,000 | Included [B2] |
| EXT-BROKER | USD300,000, household share 0.40, held away, owned by B-A and OUTSIDE-C | USD120,000 | Included [B3] |

Strict excluded accounts:

| Account | Source assertion | Why not final |
| --- | --- | --- |
| HOME | USD600,000, share 1.0, 2026-09-16 planning valuation | Held-away classification absent from structured evidence; excluded by strict tool [B2] |
| MORTGAGE | Positive USD200,000 liability, share 1.0, 2026-09-16 balance | Held-away classification absent from structured evidence; excluded by strict tool [B2] |
| LEGACY-ACCOUNT | Two current snapshots: USD90,000 and USD95,000, share 1.0 | Conflicting values; no controlling source; held-away classification also absent [B3, B6] |
| HELD-AWAY-PENSION | Expected account | No value, statement or ownership allocation received [B3, B6] |

Strict calculator totals: assets USD240,000, liabilities USD0, partial net worth USD240,000. These are **not** complete household totals. No independent household reference total was supplied, so tie-out was not performed. [B1]

Working economic note for discussion only: source-asserted non-conflicting lines JOINT-BANK, EXT-BROKER household share, HOME and MORTGAGE imply USD840,000 assets, USD200,000 liabilities and USD640,000 net worth before LEGACY-ACCOUNT, HELD-AWAY-PENSION and strict classification resolution. This is a calculated illustration from source assertions, not a reconciled balance sheet. [B2, B3]

## Risk-Dimension Review

Local artifact: `investment-risk-profile-reviewer-0dcbe7215dc58e627faf`, status `needs-data`; output validated locally with 0 validation errors. No risk rating was assigned.

Recorded dimensions and calculator checks:

| Dimension | Source assertion | Local arithmetic / issue |
| --- | --- | --- |
| Willingness | B-A accepts at most 20% loss using Q-W2 version 2, administered by Imani with method record QA-22 | Method approval owner/reference is missing; willingness amount on USD600,000 investable assets is USD120,000 [B4] |
| Loss capacity | CA-4 provisionally uses USD600,000 investable assets and USD60,000 assessed loss capacity | Capacity loss percentage is 10%; provisional assessment must be refreshed after reconciliation [B4, B6] |
| Liquidity | USD40,000 available, USD70,000 required within 6 months | Liquidity shortfall is USD30,000 [B4] |
| Horizon | Proposed exposure horizon is 24 months | 36-month lockup exceeds horizon [B4] |
| Experience | No private-credit experience; experienced in listed equities | Private-credit exposure requires review; no experience is recorded for that instrument type [B4] |
| Constraint | B-A requests no leverage | Preserve as constraint; do not infer an investment action [B4] |

Conflict flags for advisor review:

- Stated 20% willingness equals USD120,000 on the provisional USD600,000 investable-assets base, exceeding the provisional USD60,000 loss capacity. [B4]
- Supplied USD90,000 scenario loss exceeds provisional USD60,000 financial loss capacity, though it is below the USD120,000 willingness amount. [B4]
- Proposed 36-month lockup exceeds the 24-month horizon and extends beyond a 6-month underfunded liquidity need. [B4]
- Private-credit experience is recorded as none while the proposed exposure was mapped to private credit from the packet context. [B4]

## Initial Goal-Funding Analysis

Local artifact: `household-financial-planning-assistant-454ea528de7ce6a33933`, status `needs-data`; output validated locally with 0 validation errors. The tool withheld goal projections because GP-1 account IDs and goal priorities were not supplied. [B5]

Monthly cash flow and debt:

| Item | Amount / result | Source |
| --- | ---: | --- |
| After-tax income | USD12,000/month | [B5] |
| Non-debt living expense | USD7,000/month | [B5] |
| Reserve contribution | USD500/month | [B5] |
| Family loan | USD12,000 balance, 0% APR, USD1,000/month, no extra payment | [B5] |
| Modeled family-loan payoff | 12 months, USD0 interest | local arithmetic from [B5] |
| Surplus before goals | USD3,500/month | local arithmetic from [B5] |
| Goal contributions | USD2,500/month | [B5] |
| Remaining after stated goals | USD1,000/month | local arithmetic from [B5] |

Shared funding issue:

| Pool | Balance | Reserved | Available | Assigned | Gap |
| --- | ---: | ---: | ---: | ---: | ---: |
| GP-1 | USD50,000 | USD10,000 | USD40,000 | USD50,000 | USD10,000 over-allocated |

Conditional individual goal math, **not simultaneous funding approval**:

| Goal | Source facts | Conditional result |
| --- | --- | --- |
| G-SCHOOL | USD50,000 nominal target on 2027-09-17; USD30,000 assigned from GP-1; USD1,500 month-end contributions; 0% return and 0% inflation | Projected USD48,000; 96.00% funded; USD2,000 gap; illustrative additional USD166.67/month or 2-month extension under stated assumptions [B5] |
| G-HOME | USD30,000 nominal target on 2027-09-17; USD20,000 assigned from GP-1; USD1,000 month-end contributions; 0% return and 0% inflation | Projected USD32,000; 106.67% funded; no modeled gap under stated assumptions [B5] |

Planning interpretation: cash flow appears able to carry the stated monthly contributions using supplied expenses, debt and reserve facts, but the initial balance allocations cannot both stand as sourced simultaneous funding because GP-1 is USD10,000 over-allocated after reserves. [B5]

## Route And Handoff Plan

Router artifact: `wealth-management-router-b6ef3d6977e88947fd96`, status `needs-data`. It maps the request to household reconciliation, risk profile and financial plan / goal progress.

1. **Data reconciliation owner: planner Imani with custody operations / external source owner.** Resolve LEGACY-ACCOUNT controlling value, obtain HELD-AWAY-PENSION statement/value/ownership allocation, confirm held-away classifications for HOME, MORTGAGE and LEGACY-ACCOUNT, and obtain any independent household reference total if available. [B1, B2, B3, B6]
2. **Risk owner: advisor / qualified planning professional.** Obtain the actual Q-W2 v2 method-approval owner/reference, then refresh CA-4 after reconciliation; preserve liquidity shortfall, lockup/horizon mismatch, no-private-credit-experience, and no-leverage constraint for review. [B4, B6]
3. **Planning owner: advisor / planner.** Identify GP-1 account IDs, confirm whether the USD10,000 reserve is protected, obtain human-assigned goal priorities, and resolve the USD10,000 pool over-allocation before presenting goal-funding choices as a plan. [B5]
4. **Downstream boundary.** Do not hand off to IPS, proposal, portfolio construction or recommendation-evidence work until the balance sheet, risk-dimension conflicts and planning inputs are resolved or explicitly carried as unresolved findings. [B4, B5, B6]

## Concise Client-Discussion Agenda

1. Confirm household scope, USD-only planning basis and expected account inventory. [B1]
2. Review balance-sheet exceptions: legacy account conflict, missing pension evidence, and source-asserted home/mortgage treatment. [B2, B3, B6]
3. Confirm monthly cash flow, reserve contribution, family-loan schedule and whether any expenses or debts are missing. [B5]
4. Discuss school and renovation goals: priorities, GP-1 source account membership, protected reserve, and the USD10,000 over-allocation. [B5]
5. Review risk dimensions separately: willingness, provisional loss capacity, liquidity need, horizon, experience and no-leverage constraint. Do not assign a risk rating in this conversation. [B4, B6]
6. Agree on evidence owners and follow-up dates before any recommendation or client-facing plan is prepared. [B6]

## Local Files

- Inputs: `artifacts/router_input.json`, `artifacts/reconciliation_input.json`, `artifacts/risk_input.json`, `artifacts/planning_input.json`
- Outputs: `artifacts/router_output.json`, `artifacts/reconciliation_output.json`, `artifacts/risk_output.json`, `artifacts/planning_output.json`

Python emitted sandbox cache warnings about `/tmp/xcrun_db-*` but all relevant validators returned 0 errors.
