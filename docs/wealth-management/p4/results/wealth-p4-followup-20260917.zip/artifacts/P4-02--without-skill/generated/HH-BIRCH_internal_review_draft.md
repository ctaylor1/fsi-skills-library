# HH-BIRCH Internal Planning Readiness Draft

Review date: 2026-09-17  
Audience: advisor / internal human review  
Scope: household balance-sheet reconciliation, risk-dimension review, initial goal-funding analysis, route plan, and client-discussion agenda. This draft does not select investments and does not assign a risk rating.

## Executive Readiness View

Some items can enter a planning conversation as source-grounded discussion points, but the household balance sheet and any capacity-sensitive risk discussion should remain provisional. The packet supports a de-duplicated JOINT-BANK value, HOME value, MORTGAGE balance, and a household-share value for EXT-BROKER; it also identifies unresolved LEGACY-ACCOUNT value conflict and missing HELD-AWAY-PENSION evidence that must be carried forward rather than inferred. [B1][B2][B3][B6]

The goal conversation is usable as an initial cash-flow illustration at 0% return and 0% inflation, assuming the stated month-end contributions occur. Under those supplied assumptions, the school goal is projected at USD48,000 against a USD50,000 target, and the renovation goal is projected at USD32,000 against a USD30,000 target; together they exactly match the combined USD80,000 target. [B5]

Risk discussion should focus on dimensions and evidence gaps, not on rating or product selection. Source records show a 24-month horizon, a 36-month lockup on an offered instrument, a supplied USD90,000 loss scenario, USD40,000 available liquidity against USD70,000 needed within six months, no private-credit experience, and no leverage request. [B4]

## Source Status: Assertions vs Reconciled Items

For this internal draft, "reconciled" means internally consistent within the supplied packet, not independently verified outside the packet.

| Item | Status for draft | Treatment |
|---|---:|---|
| Household scope and expected records | Source assertion, internally controlling for scope | Use B-A/B-B, USD only, expected assets and MORTGAGE; carry explicit unresolved facts. [B1] |
| JOINT-BANK | Reconciled packet item | Count once at USD120,000; bank statement BK-1 and aggregator AG-9 are duplicate observations of the same account. [B2] |
| HOME | Reconciled packet item | Include at USD600,000 planning value. [B2] |
| MORTGAGE | Reconciled packet item | Include as positive USD200,000 liability. [B2] |
| EXT-BROKER | Reconciled for household-share value; transfer authority not established | Include USD120,000 household-share planning value, calculated as USD300,000 x 40%; do not treat allocation as transfer authorization. [B3] |
| LEGACY-ACCOUNT | Unresolved conflict | Carry as USD90,000-USD95,000 range or exclude from finalized totals until controlling value is identified. [B3][B6] |
| HELD-AWAY-PENSION | Missing evidence | Do not value; no statement, value, or ownership allocation received. [B3][B6] |
| Family loan | Source assertion, classification unresolved | Use USD1,000 monthly payment in cash-flow analysis; resolve whether the USD12,000 balance belongs in balance-sheet liabilities because B1 names only MORTGAGE as expected liability. [B1][B5] |

## Balance-Sheet Reconciliation

### Planning Values Supported for Discussion

| Balance-sheet item | Packet value | Household share | Draft value | Notes |
|---|---:|---:|---:|---|
| JOINT-BANK | USD120,000 | 100% | USD120,000 | Duplicate bank/aggregator observations; count once. [B2] |
| HOME | USD600,000 | 100% | USD600,000 | Supplied planning valuation dated 2026-09-16. [B2] |
| EXT-BROKER | USD300,000 | 40% | USD120,000 | Held away; household allocation is signed but not transfer authorization. [B3] |
| LEGACY-ACCOUNT | USD90,000 or USD95,000 | 100% | USD90,000-USD95,000 unresolved range | Neither source designated controlling. [B3][B6] |
| HELD-AWAY-PENSION | Unknown | Unknown | Unknown | Expected but not evidenced. [B1][B3][B6] |
| MORTGAGE | USD200,000 liability | 100% | USD200,000 liability | Supplied September 16 balance. [B2] |

Calculation view:

| Measure | Amount |
|---|---:|
| Reconciled assets excluding unresolved LEGACY-ACCOUNT and pension | USD840,000 |
| Visible non-home financial assets excluding unresolved LEGACY-ACCOUNT and pension | USD240,000 |
| Visible non-home financial assets if LEGACY-ACCOUNT range is carried, excluding pension | USD330,000-USD335,000 |
| Assets if LEGACY-ACCOUNT range is carried, excluding pension | USD930,000-USD935,000 |
| Net worth if LEGACY-ACCOUNT range is carried, excluding pension | USD730,000-USD735,000 |
| Pension impact | Unknown |
| Family-loan balance-sheet impact | Unresolved; potential additional USD12,000 liability if confirmed in scope |

Do not present a single final household net-worth figure until the LEGACY-ACCOUNT conflict, pension evidence, and family-loan balance-sheet classification are resolved. No independent household reference total was supplied, so reconciliation is item-level only. [B1][B3][B5][B6]

## Risk-Dimension Review

No ordinal risk category has been assigned in the packet, and this draft assigns none. [B4]

Usable source-grounded discussion points:

| Dimension | Packet evidence | Planning implication |
|---|---|---|
| Willingness | B-A recorded willingness to accept at most 20% loss using questionnaire Q-W2 version 2, administered by Imani with method record QA-22. [B4] | Discuss as questionnaire evidence for B-A only; do not generalize to the entire household without B-B evidence. |
| Capacity | Professional assessment CA-4 provisionally uses USD600,000 investable assets and USD60,000 assessed loss capacity, but it predates reconciliation. [B4][B6] | Revisit after balance-sheet reconciliation; visible non-home financial assets in the packet are USD240,000 excluding LEGACY/pension or USD330,000-USD335,000 if the unresolved LEGACY range is carried, before any pension value. |
| Liquidity | USD40,000 available and USD70,000 required within six months. [B4] | Liquidity gap of USD30,000 should be resolved before committing illiquid capital. |
| Time horizon vs lockup | Proposed exposure horizon is 24 months; offered instrument has 36-month lockup. [B4] | Mismatch requires advisor review and client discussion before any planning use. |
| Loss scenario | Offered instrument has supplied USD90,000 loss scenario; provisional assessed loss capacity is USD60,000. [B4] | Scenario exceeds provisional capacity by USD30,000; capacity must be recalculated before use. |
| Experience and constraints | B-A has listed-equities experience, no private-credit experience, and requests no leverage. [B4] | Private-credit education and leverage constraint should be documented before product-specific discussion. |

## Initial Goal-Funding Analysis

Inputs are source assertions from the planning interview and goal worksheet. They are illustrations at 0% return and 0% inflation, not forecasts. [B5]

Cash-flow frame:

| Monthly item | Amount |
|---|---:|
| After-tax income | USD12,000 |
| Non-debt living expense | USD7,000 |
| Reserve contribution | USD500 |
| Family-loan payment | USD1,000 |
| Cash flow before goal contributions | USD3,500 |
| Planned school contribution | USD1,500 |
| Planned renovation contribution | USD1,000 |
| Cash flow after stated goal contributions | USD1,000 |

Contribution timing assumption for this draft: month-end contributions from 2026-09-30 through 2027-08-31, for 12 contributions before the 2027-09-17 target date. This is a calculation convention based on the packet's "month-end contributions" language; confirm with the planning system before client use. [B5]

| Goal | Target date | Target | Initial assignment | Monthly contribution | Projected funding at target | Surplus / shortfall | Funding ratio |
|---|---|---:|---:|---:|---:|---:|---:|
| G-SCHOOL | 2027-09-17 | USD50,000 | USD30,000 | USD1,500 | USD48,000 | -USD2,000 | 0.96 |
| G-HOME | 2027-09-17 | USD30,000 | USD20,000 | USD1,000 | USD32,000 | USD2,000 | 1.07 |
| Combined | 2027-09-17 | USD80,000 | USD50,000 | USD2,500 | USD80,000 | USD0 | 1.00 |

At the supplied at-risk threshold of 0.90, both individual goals are above threshold under the stated contribution schedule, but the school goal still has a nominal USD2,000 shortfall if its assigned funding is not reallocated. The renovation goal has a matching USD2,000 projected surplus. Confirm whether goal-pool funds may be reallocated between goals and clarify the meaning of the USD10,000 reserved amount in GP-1 before presenting a planning conclusion. [B5]

## Missing Evidence and Owners

| Issue | Why it matters | Proposed next owner |
|---|---|---|
| LEGACY-ACCOUNT has two current values, USD90,000 and USD95,000. [B3][B6] | Prevents a final single net-worth and investable-asset total. | Source owner / custody operations to identify controlling record. |
| HELD-AWAY-PENSION lacks value, statement, and ownership allocation. [B3][B6] | Pension may materially affect net worth, retirement resources, and risk capacity. | Advisor/planner to request evidence through normal documentation workflow; held-away data owner to supply statement/allocation. |
| CA-4 capacity assessment predates reconciliation and uses USD600,000 investable assets. [B4][B6] | Capacity-sensitive planning is unreliable until reconciled investable assets are confirmed. | Planner/risk reviewer to rerun or update after reconciliation. |
| Family-loan balance-sheet classification is unclear. [B1][B5] | It is a cash-flow obligation and may also be a liability; B1 lists only MORTGAGE as expected liability. | Advisor/planner to confirm whether the USD12,000 balance belongs on the household balance sheet. |
| GP-1 reserved USD10,000 meaning is unclear. [B5] | Affects whether reserve can cover school shortfall or must remain segregated. | Planner/goal worksheet owner to confirm whether reserved funds are unavailable, earmarked, or separately held. |
| Risk evidence appears to be B-A only. [B4] | Household planning may require B-B willingness, constraints, and liquidity needs. | Advisor to gather B-B inputs before household-level conclusions. |

## Route / Handoff Plan

1. Reconciliation lane: custody operations or source owner resolves LEGACY-ACCOUNT controlling value; held-away data owner supplies pension statement/value/allocation; planner confirms whether family loan is in balance-sheet scope. [B1][B3][B5][B6]
2. Planning lane: planner updates household balance sheet after reconciliation, preserving held-away status and ownership-share treatment; do not collapse to a single final net-worth figure before the unresolved items clear. [B1][B3][B6]
3. Risk lane: risk reviewer revisits CA-4 after reconciled investable assets are available and separately documents liquidity gap, 24-month horizon versus 36-month lockup, USD90,000 scenario loss, no private-credit experience, and no-leverage request. [B4][B6]
4. Goals lane: planner validates the 12 month-end contribution convention, confirms GP-1 reserve treatment, and tests whether school and renovation assignments may be rebalanced. [B5]
5. Advisor lane: use only the source-grounded conversation agenda below; avoid investment selection, risk-rating language, or capacity conclusions until the above lanes return. [B4][B6]

## Concise Client-Discussion Agenda

1. Confirm household records: JOINT-BANK counted once, HOME, MORTGAGE, EXT-BROKER household-share treatment, and held-away status. [B1][B2][B3]
2. Resolve open data: ask for the controlling LEGACY-ACCOUNT value, HELD-AWAY-PENSION statement/allocation, and whether the family loan should appear as a balance-sheet liability. [B3][B5][B6]
3. Review near-term liquidity: discuss USD40,000 available versus USD70,000 needed within six months and any planned sources for the USD30,000 gap. [B4]
4. Discuss risk dimensions without rating: loss willingness, capacity refresh, 24-month horizon, 36-month lockup, USD90,000 loss scenario, no private-credit experience, and no leverage request. [B4][B6]
5. Review goals: school and renovation targets, current GP-1 assignments, monthly contributions, USD10,000 reserved amount, and whether reallocation between goals is allowed. [B5]

## Calculation Note

Arithmetic in this draft was reproduced locally in `calc_hh_birch.py` using only values from the supplied packet. The script does not import outside data or assign missing values.
