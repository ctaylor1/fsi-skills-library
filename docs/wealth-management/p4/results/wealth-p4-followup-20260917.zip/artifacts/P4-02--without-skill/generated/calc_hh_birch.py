from datetime import date
import calendar
import json


def month_ends_after_through(start, target):
    months = []
    year, month = start.year, start.month
    while True:
        last_day = calendar.monthrange(year, month)[1]
        month_end = date(year, month, last_day)
        if start < month_end <= target:
            months.append(month_end.isoformat())
        month += 1
        if month == 13:
            year += 1
            month = 1
        if date(year, month, 1) > target:
            break
    return months


review_date = date(2026, 9, 17)
goal_target = date(2027, 9, 17)
contribution_month_ends = month_ends_after_through(review_date, goal_target)
months = len(contribution_month_ends)

joint_bank = 120_000
home = 600_000
ext_broker_household_share = 300_000 * 0.40
legacy_low = 90_000
legacy_high = 95_000
mortgage = 200_000

assets_excluding_unresolved_legacy_and_pension = (
    joint_bank + home + ext_broker_household_share
)
non_home_financial_assets_excluding_unresolved_legacy_and_pension = (
    joint_bank + ext_broker_household_share
)
non_home_financial_assets_with_legacy_range_excluding_pension = (
    non_home_financial_assets_excluding_unresolved_legacy_and_pension
    + legacy_low,
    non_home_financial_assets_excluding_unresolved_legacy_and_pension
    + legacy_high,
)
assets_with_legacy_range = (
    assets_excluding_unresolved_legacy_and_pension + legacy_low,
    assets_excluding_unresolved_legacy_and_pension + legacy_high,
)
net_worth_with_legacy_range_excluding_pension = (
    assets_with_legacy_range[0] - mortgage,
    assets_with_legacy_range[1] - mortgage,
)

income = 12_000
living_expense = 7_000
reserve_contribution = 500
family_loan_payment = 1_000
goal_contributions = 1_500 + 1_000
cash_flow_before_goals = (
    income - living_expense - reserve_contribution - family_loan_payment
)
cash_flow_after_goals = cash_flow_before_goals - goal_contributions

school_target = 50_000
school_initial = 30_000
school_monthly = 1_500
school_funded = school_initial + school_monthly * months

renovation_target = 30_000
renovation_initial = 20_000
renovation_monthly = 1_000
renovation_funded = renovation_initial + renovation_monthly * months

result = {
    "contribution_month_ends_count": months,
    "first_contribution_month_end": contribution_month_ends[0],
    "last_contribution_month_end": contribution_month_ends[-1],
    "assets_excluding_unresolved_legacy_and_pension": assets_excluding_unresolved_legacy_and_pension,
    "non_home_financial_assets_excluding_unresolved_legacy_and_pension": non_home_financial_assets_excluding_unresolved_legacy_and_pension,
    "non_home_financial_assets_with_legacy_range_excluding_pension": non_home_financial_assets_with_legacy_range_excluding_pension,
    "assets_with_legacy_range_excluding_pension": assets_with_legacy_range,
    "net_worth_with_legacy_range_excluding_pension": net_worth_with_legacy_range_excluding_pension,
    "known_mortgage_liability": mortgage,
    "ext_broker_household_share_value": ext_broker_household_share,
    "cash_flow_before_goals": cash_flow_before_goals,
    "cash_flow_after_goals": cash_flow_after_goals,
    "school": {
        "target": school_target,
        "projected_funding": school_funded,
        "surplus_shortfall": school_funded - school_target,
        "funding_ratio": school_funded / school_target,
    },
    "renovation": {
        "target": renovation_target,
        "projected_funding": renovation_funded,
        "surplus_shortfall": renovation_funded - renovation_target,
        "funding_ratio": renovation_funded / renovation_target,
    },
    "combined_goals": {
        "target": school_target + renovation_target,
        "projected_funding": school_funded + renovation_funded,
        "surplus_shortfall": school_funded
        + renovation_funded
        - school_target
        - renovation_target,
    },
}

print(json.dumps(result, indent=2))
