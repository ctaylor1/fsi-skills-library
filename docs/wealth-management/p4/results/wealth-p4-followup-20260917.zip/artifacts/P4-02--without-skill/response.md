Done. I created the internal draft here:

[HH-BIRCH_internal_review_draft.md](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-5v7jvmi8/work/HH-BIRCH_internal_review_draft.md)

I also added the reproducible local calculation script:

[calc_hh_birch.py](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-5v7jvmi8/work/calc_hh_birch.py)

The draft keeps unresolved items explicit, distinguishes source assertions from internally reconciled packet items, cites source IDs throughout, includes route/handoff owners, and avoids selecting investments or assigning a risk rating. I ran the calculation script successfully; the environment emitted restricted temp-cache warnings, but the script produced the expected outputs.