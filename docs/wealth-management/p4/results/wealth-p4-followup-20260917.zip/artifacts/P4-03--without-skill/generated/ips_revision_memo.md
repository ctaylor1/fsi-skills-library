# HH-CEDAR IPS Revision Memo for Review

Review date: 2026-09-17  
Audience: advisor Dana, planner Sol, supervisory reviewer Rowan  
Purpose: reviewable IPS revision handoff, not a signature package

## Bottom Line

This version of the mandate is not ready for signature. It is suitable for review and remediation tracking, but the packet records multiple readiness blockers: no approval or effective IPS date, missing prior-artifact linkage for revision 2, allocation totals that sum to 95% rather than the required 100%, incomplete account-tax coverage because ROTH-C is omitted from the IPS tax-treatment register, pending benchmark selection, and unresolved liquidity/emergency-reserve documentation. [C1][C4][C5][C6]

The planning illustration supports a limited handoff statement: using the supplied assumptions, the two-year base and stress scenarios fund stated net spending in both annual intervals. That statement should not be expanded into a long-term sufficiency conclusion or a signature recommendation. [C2][C3][C6]

## Source Assertions vs. Review Findings

Source assertions:

- IPS template HP-IPS v4 is supplied for revision 2, but the prior artifact ID was not provided. [C1]
- Intended governance parties are client C, advisor Dana, and supervisor Rowan. [C1]
- The packet records no approval or effective IPS date. [C1]
- Objective is to fund stated spending while retaining a separately discussed emergency reserve; the reserve amount is not documented. [C4]
- Draft allocation lists equity 55% with 45-65% band, high-quality fixed income 35% with 25-45% band, and cash 5% with 0-10% band. [C4]
- Monitoring is quarterly, with proposed rebalance review when a class departs its stated band; trades still need a separate process. [C4]
- Benchmark selection is pending. [C4]
- Documented restrictions are no leverage and no direct tobacco holdings. [C4]
- DEF-C tax treatment is documented in the IPS tax-treatment register; ROTH-C is omitted. [C4]
- Risk handoff lists willingness 10% from cited client questionnaire, professionally assessed loss capacity USD 40,000 on USD 300,000 investable assets, funds-experienced investment experience, and unresolved liquidity/emergency-reserve quantification. [C5]
- IPS assembly policy v4 requires all 13 sections substantively supported, allocation total 100%, complete account-tax coverage, explicit prior-artifact linkage for revisions after 1, and pending client/advisor/supervisor approvals. A typed reviewer name or supplied template version does not prove approval. [C6]

Review findings from those assertions:

| Area | Finding | Signature readiness |
|---|---|---|
| Revision linkage | Revision 2 lacks the prior artifact ID required for revisions after 1. [C1][C6] | Blocker |
| Approval evidence | No client approval, advisor approval, supervisor approval, or effective IPS date is recorded. [C1][C4][C6] | Blocker |
| Allocation total | Listed allocation totals 95%: equity 55%, fixed income 35%, cash 5%. Policy requires 100%. [C4][C6] | Blocker |
| Account-tax register | DEF-C is documented, but ROTH-C is omitted despite being part of the planning accounts. Policy requires complete account-tax coverage. [C2][C4][C6] | Blocker |
| Liquidity and reserve | Emergency reserve and near-term liquidity need are unquantified and unresolved. [C4][C5] | Blocker |
| Benchmark | Benchmark selection is pending. [C4] | Blocker or reviewer hold, depending on local policy interpretation |
| Trading process | Rebalance review trigger is described, but trades still need a separate process. [C4] | Blocker or required pre-signature clarification |
| Risk constraint | Risk handoff says Dana should document the governing constraint after reviewing all six dimensions, not convert them into one score. [C5] | Blocker |
| 13 IPS sections | Packet does not provide evidence that all 13 required sections are substantively supported. [C6] | Blocker |

## Planning Handoff to IPS

The two-year cash-flow illustration can be cited in the IPS support file as follows:

"Under the supplied planning assumptions, HH-CEDAR's stated USD 60,000 annual net spending is funded in each of the two complete annual intervals. Annual net pension is USD 24,000 after the supplied 20% tax proxy, leaving a USD 36,000 net portfolio gap. A USD 45,000 gross withdrawal from DEF-C, using the supplied 20% withdrawal-tax proxy and DEF-C-first order, covers the gap in each interval; no ROTH-C withdrawal is required. Ending illustrated assets are USD 210,000 in the 0% base case and USD 166,050 in the -10% annual stress case. This is a two-year deterministic scenario only and excludes unprovided statutory tax, RMD, benefit eligibility, survivor, long-term-care, and probability-of-success analysis." [C2][C3][C6]

IPS drafting caution: the above supports funding of the supplied two-year spending gaps, but it does not support a claim that the mandate retains the separately discussed emergency reserve, because the reserve amount is not documented. [C4][C5]

## Revision Memo Draft Language

Proposed reviewer note:

"Reviewed as of 2026-09-17 using packet records C1-C6 only. The planning scenario funds the stated two-year spending gaps under both the base and supplied stress assumptions, subject to the packet's model limits. The IPS revision is not signature-ready. Before signature, the team should document the prior artifact ID for revision 2, complete all approval/effective-date evidence, correct the allocation to total 100%, add ROTH-C to the tax-treatment register, select benchmarks, document the emergency reserve and liquidity need, define the governing risk constraint, and confirm all 13 IPS sections are substantively supported." [C1][C2][C3][C4][C5][C6]

## Open Items and Next Owners

| Open item | Why it matters | Next owner |
|---|---|---|
| Prior artifact ID for revision 2 | Required by IPS assembly policy for revisions after 1. [C1][C6] | Advisor Dana |
| Approval package and effective date | Packet records no approval/effective date; typed names and template version do not prove approval. [C1][C6] | Advisor Dana; supervisor Rowan to review |
| Allocation correction to 100% | Current listed allocation totals 95%; policy requires 100%. [C4][C6] | Advisor Dana |
| ROTH-C tax-treatment register entry | IPS register omits ROTH-C while planning accounts include ROTH-C. [C2][C4][C6] | Advisor Dana; planner Sol to confirm planning account treatment |
| Emergency reserve amount | Objective references a separately discussed reserve, but no amount is documented. [C4][C5] | Advisor Dana |
| Liquidity need | Risk handoff says liquidity need is unquantified and unresolved. [C5] | Advisor Dana |
| Governing risk constraint | Dana is asked to document the governing constraint after all six dimensions are reviewed. [C5] | Advisor Dana |
| Benchmarks | Benchmark selection is pending. [C4] | Advisor Dana; supervisor Rowan to review |
| Trading process | Draft says trades still need a separate process. [C4] | Advisor Dana; supervisor Rowan to review |
| 13-section support | Policy requires all 13 sections substantively supported; packet does not evidence completion. [C6] | Advisor Dana; supervisor Rowan to review |

## Limits to Preserve

- Do not treat tax proxies as statutory tax calculations or distribution-eligibility conclusions. [C2]
- Do not calculate unprovided RMDs, brackets, benefit eligibility, Roth conversions, survivor changes, or long-term-care shocks. [C3][C6]
- Do not represent this as a probability-of-success model; none is supplied. [C6]
- Do not infer approvals from typed names, governance-party listings, or the template version. [C1][C6]
