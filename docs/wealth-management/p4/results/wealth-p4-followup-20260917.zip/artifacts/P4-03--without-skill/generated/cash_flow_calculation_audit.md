# HH-CEDAR Cash-Flow Calculation Audit

Review date: 2026-09-17  
Purpose: arithmetic support for the two-year illustration, using only `source_packet.json`

## Inputs Used

| Input | Value | Source |
|---|---:|---|
| Opening DEF-C balance | USD 200,000.00 | [C2] |
| Opening ROTH-C balance | USD 100,000.00 | [C2] |
| DEF-C withdrawal-tax proxy | 20% | [C2] |
| ROTH-C withdrawal-tax proxy | 0% | [C2] |
| Withdrawal order | DEF-C, then ROTH-C | [C2] |
| Annual net spending | USD 60,000.00 | [C3] |
| Spending inflation | 0% | [C3] |
| Annual gross pension, ages 65 and 66 | USD 30,000.00 | [C3] |
| Pension income-tax proxy | 20% | [C3] |
| Pension COLA | 0% | [C3] |
| Base return | 0% annually | [C3] |
| Stress return | -10% annually after withdrawals | [C3] |
| Method | Complete annual intervals; cent-rounded withdrawals/tax; returns after withdrawals | [C6] |

## Formulas

- Net pension = gross pension - pension tax proxy.
- Pension tax proxy = gross pension x 20%.
- Net portfolio gap = net spending - net pension.
- Gross DEF-C withdrawal = net portfolio gap / (1 - 20%).
- DEF-C withdrawal-tax proxy = gross DEF-C withdrawal x 20%.
- Ending account value = account value after withdrawal plus return applied after withdrawal.

## Per-Year Calculation

The annual net pension is USD 24,000.00: USD 30,000.00 gross pension less USD 6,000.00 tax proxy. The annual net portfolio gap is USD 36,000.00: USD 60,000.00 net spending less USD 24,000.00 net pension. A USD 45,000.00 gross DEF-C withdrawal produces USD 36,000.00 net cash after the supplied 20% tax proxy. [C2][C3][C6]

## Reconciled Ending Balances

| Scenario | End of interval 1 total | End of interval 2 total | Unfunded spending |
|---|---:|---:|---:|
| Base, 0% annual return | USD 255,000.00 | USD 210,000.00 | USD 0.00 |
| Stress, -10% annual return | USD 229,500.00 | USD 166,050.00 | USD 0.00 |

The stress ending total is USD 43,950.00 below the base ending total after two intervals. This is an arithmetic comparison between supplied return paths, not a policy approval test or probability-of-success result. [C3][C5][C6]

## Excluded Items

No calculation was made for unprovided RMDs, tax brackets, basis, benefit eligibility, Roth conversions, survivor changes, long-term-care shocks, or probability of success. [C2][C3][C6]
