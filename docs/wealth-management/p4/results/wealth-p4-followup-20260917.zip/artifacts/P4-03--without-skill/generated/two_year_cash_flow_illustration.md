# HH-CEDAR Two-Year Retirement Cash-Flow Illustration

Review date: 2026-09-17  
Audience: advisor Dana, planner Sol, supervisory reviewer Rowan  
Scope: synthetic US advisory planning illustration in USD, using only `source_packet.json`

## Review Answer

Under the supplied two-year scenario, stated net spending is funded in both annual intervals in both the base case and the supplied stress case. This is a calculated result from the packet assumptions: USD 60,000 annual net spending, USD 30,000 gross pension taxed at a 20% proxy, withdrawal order DEF-C then ROTH-C, no contributions, and returns applied after withdrawals with cent-rounded amounts. [C2][C3][C6]

This does not prove retirement sufficiency, tax compliance, distribution eligibility, or probability of success. The packet explicitly excludes tax brackets/basis, RMDs, benefit eligibility, Roth conversions, survivor changes, long-term-care shocks, and any probability-of-success model. [C2][C3][C6]

## Evidence Status

Source assertions relied on:

- HH-CEDAR is a US advisory engagement in USD; client C is age 65 in the first complete annual interval beginning 2026-09-17 and age 66 in the second row. [C1]
- Opening balances are DEF-C USD 200,000 and ROTH-C USD 100,000; both are available in this simplified illustration; no contributions occur. [C2]
- DEF-C has a supplied 20% effective withdrawal-tax proxy; ROTH-C has a supplied 0% proxy; withdrawal order is DEF-C then ROTH-C. [C2]
- First-year net spending is USD 60,000, includes healthcare, and has 0% inflation. [C3]
- One gross pension of USD 30,000 begins at age 65 and ends at age 66 inclusive; the pension income-tax proxy is 20% and COLA is 0%. [C3]
- Base return is 0% in both annual intervals. Stress return is -10% per year on every account after withdrawals, with other inputs unchanged. [C3]
- The method uses complete annual intervals, cent-rounded withdrawals/tax, and returns after withdrawals. [C6]

Verified by local calculation from those assertions:

- Net pension cash flow is USD 24,000 per year: USD 30,000 gross pension less USD 6,000 pension tax proxy. [C3]
- Annual net spending gap is USD 36,000: USD 60,000 net spending less USD 24,000 net pension. [C3]
- Because DEF-C is withdrawn first and has a 20% tax proxy, a USD 45,000 gross DEF-C withdrawal produces USD 36,000 net cash and USD 9,000 withdrawal-tax proxy in each interval. [C2][C3]
- No ROTH-C withdrawal is required in either interval under either supplied return path. [C2][C3]

## Base Case: 0% Return

| Annual interval | Client age | Net spending need | Net pension | Net portfolio gap | Gross DEF-C withdrawal | DEF-C withdrawal tax proxy | Gross ROTH-C withdrawal | Unfunded spending | Ending DEF-C | Ending ROTH-C | Ending total |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 65 | USD 60,000.00 | USD 24,000.00 | USD 36,000.00 | USD 45,000.00 | USD 9,000.00 | USD 0.00 | USD 0.00 | USD 155,000.00 | USD 100,000.00 | USD 255,000.00 |
| 2 | 66 | USD 60,000.00 | USD 24,000.00 | USD 36,000.00 | USD 45,000.00 | USD 9,000.00 | USD 0.00 | USD 0.00 | USD 110,000.00 | USD 100,000.00 | USD 210,000.00 |

Base-case conclusion: the supplied spending is funded for both intervals, with ending illustrated assets of USD 210,000.00. This is a scenario calculation, not a statutory tax or retirement adequacy conclusion. [C2][C3][C6]

## Stress Case: -10% Annual Return After Withdrawals

| Annual interval | Client age | Net spending need | Net pension | Net portfolio gap | Gross DEF-C withdrawal | DEF-C withdrawal tax proxy | Gross ROTH-C withdrawal | Unfunded spending | Ending DEF-C | Ending ROTH-C | Ending total |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 65 | USD 60,000.00 | USD 24,000.00 | USD 36,000.00 | USD 45,000.00 | USD 9,000.00 | USD 0.00 | USD 0.00 | USD 139,500.00 | USD 90,000.00 | USD 229,500.00 |
| 2 | 66 | USD 60,000.00 | USD 24,000.00 | USD 36,000.00 | USD 45,000.00 | USD 9,000.00 | USD 0.00 | USD 0.00 | USD 85,050.00 | USD 81,000.00 | USD 166,050.00 |

Stress-case conclusion: the supplied spending is funded for both intervals, with ending illustrated assets of USD 166,050.00. The two-year stress ending value is USD 43,950.00 lower than the base-case ending value, reflecting the supplied -10% annual return path after withdrawals. [C3][C6]

## Planning-to-IPS Handoff

The spending illustration can be handed to the IPS review only as a two-year scenario. It supports the narrow statement that the supplied base and stress assumptions fund the stated two-year spending gaps, but it does not resolve the mandate objective to retain a separately discussed emergency reserve because the reserve amount is not documented. [C4][C5]

Risk and liquidity handoff items:

| Item | Evidence status | Proposed next owner |
|---|---|---|
| Emergency reserve amount | Undocumented; objective says reserve was separately discussed but amount is not recorded. [C4] | Advisor Dana |
| Near-term liquidity need | Unquantified and unresolved in risk handoff RP-CEDAR-4. [C5] | Advisor Dana |
| Governing risk constraint | Dana is asked to document the governing constraint after reviewing all six dimensions, not to convert them into one score. [C5] | Advisor Dana |
| Loss-capacity comparison | Source assertion says assessed loss capacity is USD 40,000 on USD 300,000 investable assets; the supplied two-year stress ending total is USD 43,950 below the base ending total. This comparison is arithmetic only and not an approval test supplied by the packet. [C5][C6] | Planner Sol and supervisory reviewer Rowan |
| Model limits | Exclusions include tax brackets/basis, RMDs, benefit eligibility, survivor transitions, long-term-care shocks, and probability of success. [C3][C6] | Planner Sol to disclose; Rowan to review |

## Missing Evidence

- Emergency reserve amount and governing liquidity constraint are missing. [C4][C5]
- No evidence is supplied for RMDs, tax brackets, account basis, benefit eligibility, survivor assumptions, Roth conversions, long-term-care shocks, or probability-of-success analysis; these should remain excluded rather than inferred. [C3][C6]
- No approval or effective IPS date is recorded in the packet. [C1][C4][C6]
