Prepared the review drafts locally.

Files:
- [two_year_cash_flow_illustration.md](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-hcne_xze/work/two_year_cash_flow_illustration.md:1)
- [ips_revision_memo.md](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-hcne_xze/work/ips_revision_memo.md:1)
- [cash_flow_calculation_audit.md](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-hcne_xze/work/cash_flow_calculation_audit.md:1)

Headline conclusions:
- The supplied two-year scenario funds stated spending in both base and stress cases, with no unfunded spending and no ROTH-C withdrawals required.
- The IPS version is not ready for signature. Main blockers are missing approval/effective-date evidence, missing prior-artifact linkage, allocation totaling 95% instead of 100%, omitted ROTH-C tax-treatment coverage, unresolved liquidity/emergency reserve, pending benchmark selection, and incomplete evidence for required IPS support.

I verified the arithmetic with local Python. `git status` could not run usefully because this workspace is not a git repository.