Done. I prepared both review drafts and the local structured artifacts.

Files:
- [HH-CEDAR_two_year_retirement_cash_flow_illustration.md](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-74gwevdc/work/HH-CEDAR_two_year_retirement_cash_flow_illustration.md)
- [HH-CEDAR_IPS_revision_memo.md](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-74gwevdc/work/HH-CEDAR_IPS_revision_memo.md)
- [retirement_cash_flow_output.json](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-74gwevdc/work/retirement_cash_flow_output.json)
- [ips_revision_output.json](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-74gwevdc/work/ips_revision_output.json)

Key conclusions:
- The supplied two-year scenario funds modeled spending in both base and stress cases, with no modeled shortfall or depletion. Base terminal balance is `USD210,000`; stress terminal balance is `USD166,050`.
- The IPS revision is not ready for signature. Main blockers are missing prior artifact ID, unquantified liquidity/reserve, missing governing constraint, allocation totaling `95%` instead of `100%`, pending benchmarks, incomplete ROTH-C tax-treatment coverage, incomplete rebalancing details, and pending approvals.

Validation completed:
- Retirement output validation: `0 error(s)`
- IPS output validation: `0 error(s)`