# HH-CEDAR Two-Year Retirement Cash-Flow Illustration

Review as of 2026-09-17. Audience: advisor, planner and supervisory reviewer. Draft only; not delivered; no system or account action taken.

## Bottom Line

Under the supplied two-year spending-gap scenario, modeled spending is funded in both complete annual intervals at ages 65 and 66. The base case ends with USD210,000 and the stress case ends with USD166,050. Neither scenario shows a spending shortfall or asset depletion inside the two-year horizon. This is a local deterministic calculation from the supplied packet assumptions, not a probability of success, tax opinion, benefit entitlement determination or investment recommendation. [C1][C2][C3][C6]

The illustration does not prove the broader retirement mandate is complete because the emergency reserve and near-term liquidity need remain unquantified in the risk handoff. That unresolved issue should carry into planning and the IPS review. [C5]

Structured local artifact: `retirement_cash_flow_output.json`  
Artifact ID: `retirement-income-scenario-modeler-cbcf81c5615db6cf7844`  
Status: `needs-data` because upstream liquidity evidence remains unresolved. [C5]

## Source Assertions Used

- HH-CEDAR is a synthetic US advisory engagement in USD; Client C is age 65 at the first complete annual interval beginning 2026-09-17, and the second row is age 66. [C1]
- Opening assets supplied for this simplified illustration are DEF-C USD200,000 tax-deferred with a 20% effective withdrawal-tax proxy, and ROTH-C USD100,000 tax-free with a 0% proxy; withdrawal order is DEF-C then ROTH-C; no contributions occur. [C2]
- First-year net spending is USD60,000, includes healthcare, has 0% inflation, and is funded using spending-gap withdrawals. [C3]
- Pension income is supplied as USD30,000 gross annually from age 65 through age 66 inclusive, with 20% income-tax proxy and 0% COLA. [C3]
- Base return is 0% in both intervals; stress return is -10% per year on every account after withdrawals; surplus is not reinvested. [C3]
- Model limitations exclude RMDs, tax brackets/basis/capital gains, benefit eligibility, Roth conversions, survivor changes and long-term-care shocks; no probability-of-success model is supplied. [C3][C6]

## Verified Local Calculation

The local model calculates annual pension tax as USD30,000 x 20% = USD6,000, leaving USD24,000 net income. The remaining spending need is USD60,000 - USD24,000 = USD36,000. With a 20% withdrawal-tax proxy on DEF-C, the gross withdrawal required is USD36,000 / 80% = USD45,000, producing USD9,000 withdrawal tax and USD36,000 net withdrawal. [C2][C3]

### Scenario Comparison

| Scenario | Terminal portfolio | First spending shortfall age | Total spending shortfall | First asset depletion age | Depleted before horizon? | Depleted by horizon? |
| --- | ---: | --- | ---: | --- | --- | --- |
| Base: 0% annual return | USD210,000 | None | USD0 | None | No | No |
| Stress: -10% annual return | USD166,050 | None | USD0 | None | No | No |

### Base Annual Rows

| Age | Opening portfolio | Net spending | Net income | Gross withdrawals | Withdrawal tax | Net withdrawals | Return | Closing portfolio | Shortfall |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 65 | USD300,000 | USD60,000 | USD24,000 | USD45,000 | USD9,000 | USD36,000 | USD0 | USD255,000 | USD0 |
| 66 | USD255,000 | USD60,000 | USD24,000 | USD45,000 | USD9,000 | USD36,000 | USD0 | USD210,000 | USD0 |

### Stress Annual Rows

| Age | Opening portfolio | Net spending | Net income | Gross withdrawals | Withdrawal tax | Net withdrawals | Return | Closing portfolio | Shortfall |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 65 | USD300,000 | USD60,000 | USD24,000 | USD45,000 | USD9,000 | USD36,000 | -USD25,500 | USD229,500 | USD0 |
| 66 | USD229,500 | USD60,000 | USD24,000 | USD45,000 | USD9,000 | USD36,000 | -USD18,450 | USD166,050 | USD0 |

### Account-Level Notes

- In both scenarios, withdrawals come entirely from DEF-C under the supplied order; ROTH-C is not tapped during the two-year illustration. [C2][C3]
- Base DEF-C ending balance is USD110,000 and ROTH-C remains USD100,000. [C2][C3]
- Stress DEF-C ending balance is USD85,050 and ROTH-C ending balance is USD81,000 after the -10% annual return assumption. [C2][C3]

## Planning-to-IPS Handoff

Pass the scenario evidence downstream as bounded planning support only: household HH-CEDAR, advisory capacity, as-of 2026-09-17, two annual intervals, opening assets USD300,000, net spending USD60,000 annually, pension net income USD24,000 annually, spending-gap gross withdrawals USD45,000 annually from DEF-C, no modeled shortfall in either scenario, and the model limitations above. [C1][C2][C3][C6]

Carry forward the unresolved liquidity issue: emergency reserve and near-term liquidity need have not been quantified. The cash-flow illustration does not establish how much of the USD300,000 should be reserved, whether all balances should be considered mandate assets, or whether the proposed IPS liquidity language is sufficient. Next owner: advisor Dana with risk reviewer/planner Sol support; supervisory reviewer Rowan to confirm before signature readiness. [C4][C5][C6]

## Missing Evidence and Owners

| Missing or unresolved item | Why it matters | Next owner |
| --- | --- | --- |
| Emergency reserve and near-term liquidity amount | The spending illustration uses both accounts as available assets, but the mandate objective says a separate reserve should be retained. [C2][C4][C5] | Advisor Dana / planner Sol |
| Tax, RMD, basis, benefit eligibility, Roth conversion and survivor analysis | The model uses flat supplied proxies and excludes these determinations. [C2][C3][C6] | Tax/benefits/legal or qualified planning reviewer |
| IPS signature readiness | The cash-flow result is evidence for the IPS, not approval of the mandate. [C6] | Advisor Dana and supervisor Rowan |

