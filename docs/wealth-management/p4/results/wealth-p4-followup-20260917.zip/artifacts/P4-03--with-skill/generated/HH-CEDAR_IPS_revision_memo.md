# HH-CEDAR IPS Revision 2 Review Memo

Review as of 2026-09-17. Audience: advisor, planner and supervisory reviewer. Draft only; not delivered; no system or account action taken.

## Signature Readiness Answer

This version of the mandate is not ready for signature. The local IPS assembly artifact validates structurally but remains `needs-data` because the packet documents unresolved liquidity evidence, missing revision lineage, incomplete mandate content, incomplete tax-treatment coverage, pending benchmarks and pending approvals. [C1][C4][C5][C6]

Structured local artifact: `ips_revision_output.json`  
Artifact ID: `investment-policy-statement-builder-701f7e23fa40c0c41ebf`  
Status: `needs-data`

## What Is Documented for Review

- Engagement and template: HH-CEDAR is a US advisory engagement in USD; HP-IPS v4 is supplied for revision 2. [C1]
- Parties: client C, advisor Dana and supervisor Rowan are the intended governance parties. [C1]
- Purpose: fund stated spending while retaining a separately discussed emergency reserve; reserve amount is not documented. [C4]
- Account facts for planning: DEF-C USD200,000 tax-deferred with 20% effective withdrawal-tax proxy; ROTH-C USD100,000 tax-free with 0% proxy. [C2]
- Time horizon/risk handoff: 24 months for this illustration; willingness 10%, loss capacity USD40,000 on USD300,000 investable assets, funds experienced, and no leverage/direct tobacco constraints. [C5]
- Restrictions: no leverage and no direct tobacco holdings are documented. [C4][C5]
- Monitoring/rebalancing concept: quarterly monitoring and proposed rebalance review when a class departs its stated band; trades require a separate process. [C4]
- Approvals/effective date: no approval or effective IPS date is recorded; advisor, supervisor and client approvals remain pending. [C1][C4][C6]

## Planning Evidence to Attach

The companion cash-flow illustration shows that the supplied two-year spending scenario funds modeled spending in both base and stress cases, with no spending shortfall or asset depletion. Base terminal balance is USD210,000; stress terminal balance is USD166,050. This is conditional on the supplied pension, spending, withdrawal order, tax proxies and return assumptions, and it does not resolve liquidity reserve adequacy or mandate suitability. [C2][C3][C5][C6]

## Signature Blockers and Next Owners

| Issue | Evidence | Why it blocks signature | Next owner |
| --- | --- | --- | --- |
| Prior IPS artifact ID missing for revision 2 | Packet says HP-IPS v4 is supplied for revision 2, but prior artifact ID was not provided. [C1] | Revision lineage is required for refresh review. [C6] | Advisor Dana / supervisory reviewer Rowan |
| Emergency reserve and near-term liquidity unquantified | Objective references a reserve, and risk handoff says reserve/liquidity remain unquantified. [C4][C5] | Liquidity requirement and reserve amount cannot be approved as drafted. | Advisor Dana with planner/risk reviewer Sol |
| Governing constraint not documented | Risk handoff asks Dana to document the governing constraint after reviewing all six dimensions. [C5] | The IPS builder must preserve the six dimensions and an attributed human governing constraint; no generated score should replace it. [C5][C6] | Advisor Dana |
| Allocation totals 95%, not 100% | Listed equity 55%, high-quality fixed income 35%, cash 5%; 55 + 35 + 5 = 95. [C4] | IPS policy requires allocation total 100%. [C6] | Advisor Dana / portfolio construction owner |
| Benchmarks pending | Source says benchmark selection is pending. [C4] | Strategic allocation and monitoring benchmark fields are not complete. | Advisor Dana / portfolio construction owner |
| Tax-treatment register omits ROTH-C | Packet documents DEF-C and ROTH-C account tax facts, but the IPS tax-treatment register omits ROTH-C. [C2][C4] | IPS policy requires complete account-tax coverage. [C6] | Advisor Dana / tax-aware reviewer |
| Return objective and objective priority not supplied | Objective is spending/reserve oriented, but no separate return objective or human priority ranking is supplied. [C4][C5] | Required mandate content remains incomplete; source order must not be treated as priority. | Advisor Dana |
| Rebalancing details incomplete | Packet gives band-departure review concept but not a single threshold percentage, tax/cost constraints or exception owner. [C4] | Rebalancing policy is not fully reviewable. | Advisor Dana / supervisor Rowan |
| Approvals pending | Packet records no approval or effective date and draft does not contain client approval. [C1][C4] | Advisor, supervisor and client approval roles must remain pending; draft cannot self-authorize signature. [C6] | Advisor Dana, supervisor Rowan, client C |

## Reviewable IPS Revision Draft Position

Use the current material only as a draft mandate package. Sections documented for review include purpose/scope, governance, time horizon, constraints, approvals-as-pending and disclosures. Sections still needing data include objectives, risk profile, liquidity, tax, allocation, rebalancing and monitoring. This conclusion reflects the local IPS output findings and the cited packet evidence. [C1][C2][C4][C5][C6]

The mandate should not be signed until the owners above provide source-backed updates and a supervisory reviewer confirms that the revised version satisfies template HP-IPS v4, allocation total 100%, complete account-tax coverage, revision lineage and pending-to-approved workflow requirements. [C6]

## Source-Grounded Draft Language for Revision

Suggested planning evidence paragraph:

> A two-year deterministic retirement cash-flow illustration as of 2026-09-17 modeled ages 65 and 66 using supplied spending, pension income, tax-proxy and withdrawal-order assumptions. The base and stress scenarios showed no modeled spending shortfall or asset depletion, with terminal balances of USD210,000 and USD166,050, respectively. The illustration is bounded and does not model RMDs, tax brackets/basis/capital gains, benefit entitlement, Roth conversions, survivor changes, long-term-care shocks or probability of success. [C2][C3][C6]

Suggested unresolved-liquidity paragraph:

> The IPS objective references retaining a separately discussed emergency reserve, but the reserve amount and near-term liquidity need have not been quantified. This item remains unresolved from risk handoff RP-CEDAR-4 and requires advisor documentation before the mandate can be signature-ready. [C4][C5]

## Source Registry Used

- C1: Engagement and revision cover, advisor Dana, 2026-09-17; current through 2026-09-30.
- C2: Account and tax-proxy worksheet, planner Sol, 2026-09-17; current through 2026-09-30.
- C3: Spending and income assumptions, planner Sol, 2026-09-17; current through 2026-09-30.
- C4: Human-owned mandate draft, Dana, 2026-09-16; current through 2026-09-30.
- C5: Risk handoff RP-CEDAR-4, risk reviewer Sol, 2026-09-16; current through 2026-09-30.
- C6: Review instructions and limitations register, control owner Rowan, 2026-09-17; current through 2026-12-31.

