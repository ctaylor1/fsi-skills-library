# Independent follow-up review evidence

Finalized at 2026-09-17T23:13:18.618040Z.

Reviewer /root/governance_map is independent of the fresh CLI response generators, authored the predeclared cases/rubrics, can see condition labels and is aware of the focused corrections and original failures. These are previously seen synthetic cases, not holdout cases, blind grading or independent rubric design. Backend model identity remains unknown; requested CLI configuration does not authenticate the serving model.

The frozen case and rubric bytes were compared with the initial experiment and are identical. This is a separate correction experiment using a later skill snapshot; no initial first-pass record was overwritten. No additional tuning is implied by these findings.

Review unit: final reply plus retained generated human-readable and structured deliverables, source packets and tool-event traces. Incidental runtime cache files are retained as provenance but not treated as requested advisor deliverables. Script validation is not source authentication. Semantic baseline workflow names receive equal credit; CLI invocation is not required. No external action was observed in these tool traces. Runtime records identify separate sessions/workdirs, not a hermetic read filesystem.

Manifest SHA256: df6c0d50393c20a2ce0753dc0380d7f3cff2aeea316cbafd0a507fee7cbdd011. Snapshot SHA256: e8850845ab1aa6b4929bdb104f92e8d146c2c070496b86f5c56442c20b420dba.

| Run | Result | Item counts | UTC review time | Review SHA256 |
| --- | --- | --- | --- | --- |
| P4-04--with-skill | pass | {'pass': 9} | 2026-09-17T23:12:23.475828Z | 24e9b49c2e6eb48f9cf6ad6d9c5a251c51cb35c1f8b083fc79b5e756d03bf266 |
| P4-04--without-skill | fail | {'pass': 7, 'fail': 2} | 2026-09-17T23:08:47.781911Z | bdd7427fbd3df9edd07781a4f8f0dc237aa7933065c1b619d8ce9c80a677acd6 |

Validated 2 review records; item totals: {'pass': 16, 'fail': 2, 'not-assessed': 0}.

Each frozen rubric item is scored. Any failed item fails its run. Multiple failed items can reflect one defect, and critical-severity omissions do not necessarily represent unsafe actions. The narrow same-case observations do not establish statistical reliability, causal skill lift, professional acceptance, source authentication or production readiness.

## Findings

- P4-04 baseline: 7 pass / 2 fail. Sizing, ongoing costs, issuer/sector/liquidity checks and source limitations are useful and correct. Required first-year totals/difference are absent, failing COST. Original PROPOSAL-DUNE-9 and concern meaning survive but exact revenue-sharing-unknown code is absent, failing BASIS.
- P4-04 with skill: 9 pass. The targeted false human-review attribution is absent: evidence reviewer/date fields are null; nine applicable checks remain incomplete. Input assessment labels for customer_profile/costs still say documented, but neither asserts a performed review and the derived result/brief clearly distinguishes records from completed evidence review. Profile owner Patel remains limited to supplied applicability context. Full required costs, look-through metrics and traversable actual-artifact lineage are retained.

## P4-04--with-skill evidence

Runtime interval: 2026-09-17T23:02:40.308754Z to 2026-09-17T23:09:04.753649Z. Bound retained bytes checked by review validator.

- hidden/cases/P4-04.json — SHA256 c86ac15ca701c257052e93352df9d8245a23f6e9940cd3a003b2919f59ca0e81
- hidden/rubrics/P4-04.json — SHA256 7dbdef7aeb84c1a527059053f52bd15565c8d23e53d6f8e8f187f484e138a466
- artifacts/P4-04--with-skill/runtime.json — SHA256 f329db39cb59f54e995c44ed5b59379dbfb65e23a3f571717c51bb01633f2f9b
- artifacts/P4-04--with-skill/events.jsonl — SHA256 bc7514dc105cf7973f447378d3e818b4de603cdee3ae2c33279ccf0c0bd6daff
- artifacts/P4-04--with-skill/response.md — SHA256 076a833300fc7fca2314294b6923b21f0e7595aa02d7a55f65ddf5f94a95ba23
- artifacts/P4-04--with-skill/generated/artifacts/client_discussion_summary.md — SHA256 7842ba4790dade9890bacdef519d3e3b4eb6eea006d7751a3d921b34ce52b845
- artifacts/P4-04--with-skill/generated/artifacts/comparison_output.json — SHA256 c09e0f2c1b71a26663e8bf8e8080e5f712016e6127d196fdc0b67b3d375efcf5
- artifacts/P4-04--with-skill/generated/artifacts/comparison_request.json — SHA256 9ef4a1f8954b3d6ad49b9a50b97e950ed43a701bc69f4b4abfbdc6d789dc0c46
- artifacts/P4-04--with-skill/generated/artifacts/construction_output.json — SHA256 2ed22a040ba4c1cd04ef22b01ec9336c39ed822bbe60c270150f8e5f26f6cdc9
- artifacts/P4-04--with-skill/generated/artifacts/construction_request.json — SHA256 333dfe9d9f0d63c79e8f1834f624ce450081e28763b483933b384288afc4543a
- artifacts/P4-04--with-skill/generated/artifacts/internal_investment_committee_memo.md — SHA256 1ef3cba96c2b123a7702728325f03c5210d261fa43d352cb8edc6a77b8c669b1
- artifacts/P4-04--with-skill/generated/artifacts/recommendation_evidence_output.json — SHA256 0404184ef85a4cfd1426cea98abc7e85b3721b043520fdac39a4ad506b2b30dc
- artifacts/P4-04--with-skill/generated/artifacts/recommendation_evidence_request.json — SHA256 e7231d09acd25b85cfd1423ff23f0ef7261388ced53d564cce31aa10ff7099ea

## P4-04--without-skill evidence

Runtime interval: 2026-09-17T23:02:40.303957Z to 2026-09-17T23:05:39.702994Z. Bound retained bytes checked by review validator.

- hidden/cases/P4-04.json — SHA256 c86ac15ca701c257052e93352df9d8245a23f6e9940cd3a003b2919f59ca0e81
- hidden/rubrics/P4-04.json — SHA256 7dbdef7aeb84c1a527059053f52bd15565c8d23e53d6f8e8f187f484e138a466
- artifacts/P4-04--without-skill/runtime.json — SHA256 e80cd182b1905f12e81f9cccdee18fbe59d92237f2f14cc66aa8eb5f993b610e
- artifacts/P4-04--without-skill/events.jsonl — SHA256 a2a38c228aa429a6d5a3ed0e6728af4974b47bfcaeac95c33727d988980e76d8
- artifacts/P4-04--without-skill/response.md — SHA256 75d34bffbe9b75705ba63b7de5c28947acf39df2a88c04332f6d7d1bb3175334
- artifacts/P4-04--without-skill/generated/calculation_notes.md — SHA256 f2a8e7c95b3796d3b350e6cc25d996b0b2c8b19e42ec4de3688e70129df9198d
- artifacts/P4-04--without-skill/generated/client_discussion_summary.md — SHA256 28b8a1650a2c2170cf1376f471255a0e2c0fd2763f417c3919847d43211e8f43
- artifacts/P4-04--without-skill/generated/investment_committee_memo.md — SHA256 6dc1482675239d49458da60b01fe7e2f25ab31995ab2f684d600f29c495d0ddc
- artifacts/P4-04--without-skill/generated/xcrun_db — SHA256 767b97e4e6c44f3e9a7b2496c54bcc1c3901650873f4fc67d811e051bd9f6e8b
