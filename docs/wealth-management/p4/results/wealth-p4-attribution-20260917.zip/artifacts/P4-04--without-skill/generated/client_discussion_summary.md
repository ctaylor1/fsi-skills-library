# HH-DUNE Client-Discussion Summary

Review date: 2026-09-17  
Audience: Client discussion preparation  
Status: Draft only; no proposal selected

## Purpose

The advisory team is reviewing two possible proposals for a contemplated nonretirement strategy switch. This summary uses only the supplied records and does not forecast returns or recommend a selection. [D5, D6]

The statements below are based on source assertions in the packet plus arithmetic checked from those assertions. They are not independent verification of outside facts, approvals, or delivery events.

## Current Model Sizing

The supplied model for a USD500,000 candidate would size the account as follows: USD300,000 in EQ, USD150,000 in BD, and USD50,000 in cash. This comes from the supplied 60% equity fund, 30% bond fund, and 10% cash model sleeve. [D1]

## Proposal Comparison in Plain Terms

ALPHA matches the supplied model sleeve: 60% EQ, 30% BD, and 10% cash. [D1, D2] Based on supplied costs, ALPHA's modeled ongoing cost is 65 bps, or about USD3,250 per year on USD500,000, plus a separate one-time transaction cost of USD200. [D2, D4]

BETA is 80% FUND-Z and 20% cash. [D3] Based on supplied costs, BETA's modeled ongoing cost is 77 bps, or about USD3,850 per year on USD500,000, with no supplied one-time transaction cost. [D3, D4] BETA has a lower advisory fee than ALPHA, but the calculated total modeled ongoing cost is higher after including fund expenses and custody. [D2, D3, D4]

Using the supplied comparison policy, ALPHA is within the stated issuer, sector, liquidity, and modeled-cost limits. [D2, D4] BETA is within the modeled-cost limit but exceeds the supplied issuer, sector, and illiquidity limits based on look-through data. [D3, D4]

## Items to Discuss Before Any Decision

The records show several open items. The advisor rationale for the switch is incomplete, the trading-series review has not been received, and conflict treatment is incomplete for BETA's proprietary FUND-Z position. [D5] Revenue-sharing evidence for FUND-Z is missing and unresolved, and a cheaper share class is documented as available but not yet explained. [D3, D5, D6]

The required disclosure LIB-ADV v6 is recorded as delivered on 2026-09-18, after the 2026-09-17 review date, and the packet says no evidence is dated as already delivered today. [D5]

## Suggested Client-Framing Notes

The team can explain that ALPHA is closer to the supplied model allocation, while BETA differs materially because it concentrates 80% in FUND-Z. [D1, D2, D3] The discussion should make clear that BETA's lower advisory fee is not the same as a lower total modeled ongoing cost under the supplied comparison method. [D2, D3, D4]

Before any recommendation or switch decision, the team should resolve the missing rationale, trading review, disclosure timing, revenue-sharing, proprietary-product conflict treatment, and cheaper-share-class questions. [D3, D5, D6]
