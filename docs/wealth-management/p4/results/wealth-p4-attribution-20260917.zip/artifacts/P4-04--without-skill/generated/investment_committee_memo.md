# HH-DUNE Internal Investment-Committee Memo

Review date: 2026-09-17  
Audience: US advisory investment committee  
Status: Draft for human review; no proposal selected

## Executive Summary

The supplied model sizing for the USD500,000 candidate allocates USD300,000 to EQ, USD150,000 to BD, and USD50,000 to cash under model M-D1 v3's 60% equity fund / 30% bond fund / 10% cash sleeve. This is calculated from the mandate's supplied proportional-within-model-sleeve method and sizing amount; the packet characterizes the model evidence as attributed selection/approval evidence, not authentication. [D1]

ALPHA matches the supplied model sleeve at EQ 60%, BD 30%, and cash 10%. [D2] Using the supplied cost fields and comparison policy, ALPHA's modeled ongoing cost is 65 bps, or USD3,250 annually on USD500,000, with a separate one-time transaction cost of USD200. [D2, D4] ALPHA is within the supplied comparison limits for modeled cost, issuer concentration, sector exposure, and 30-day illiquidity based on the packet's look-through data. [D2, D4]

BETA is 80% FUND-Z and 20% cash. [D3] Using the supplied cost fields and comparison policy, BETA's modeled ongoing cost is 77 bps, or USD3,850 annually on USD500,000, with no supplied one-time transaction cost. [D3, D4] BETA remains below the 80 bps modeled-cost limit, but based on supplied look-through data it exceeds the comparison policy's 40% issuer maximum, 70% sector maximum, and 20% illiquid maximum. [D3, D4] It also raises unresolved evidence issues: FUND-Z is proprietary, a cheaper share class is documented as available, and revenue-sharing evidence is missing. [D3, D5, D6]

The committee should treat this as comparison and evidence-readiness material, not as a return forecast or recommendation. The recommendation file says the advisor rationale is incomplete, the trading-series review has not been received, conflict treatment and revenue-sharing information are missing, and required disclosure LIB-ADV v6 was recorded as delivered on 2026-09-18 even though the review date is 2026-09-17. [D5, D6]

## Source Status and Scope

All source records, names, people, and firms are synthetic per the packet instructions. This memo uses only `source_packet.json` and should not be read as independent verification outside that packet.

Source assertions include the mandate, proposal terms, policy thresholds, recommendation-file status, and applicability notes supplied in records D1-D6. Verified work performed here is limited to reading the local packet and checking arithmetic derived from those source assertions. No external facts, approvals, delivery events, returns, probabilities, or market views are verified or estimated.

The contemplated action is a nonretirement strategy switch, not a rollover. The profile is on a US advisory fiduciary basis; the packet supplies no automatic Reg BI or Rule 2111 stack. [D5, D6]

## Supplied Model Sizing

| Sleeve | Supplied model weight | Dollar amount on USD500,000 | Source basis |
|---|---:|---:|---|
| EQ | 60% | USD300,000 | Model M-D1 v3; proportional-within-model-sleeve method [D1] |
| BD | 30% | USD150,000 | Model M-D1 v3; proportional-within-model-sleeve method [D1] |
| Cash | 10% | USD50,000 | Model M-D1 v3; proportional-within-model-sleeve method [D1] |

The mandate also supplies these constraints: maximum position 70%, cash 5%-20%, equity 50%-70%, bonds 20%-40%, and no restricted security IDs recorded in the supplied mandate. [D1] EQ and BD are described as eligible under the supplied universe and individually capped at 70%. [D1]

## Proposal Comparison

| Item | ALPHA | BETA |
|---|---:|---:|
| Allocation | EQ 60%, BD 30%, cash 10% [D2] | FUND-Z 80%, cash 20% [D3] |
| Model-sleeve alignment | Matches D1 sleeve [D1, D2] | Does not match D1 sleeve; FUND-Z position is 80% versus mandate max position 70% [D1, D3] |
| Weighted fund expense | 15 bps = 60% x 20 bps + 30% x 10 bps [D2] | 32 bps = 80% x 40 bps [D3] |
| Advisory fee | 50 bps [D2] | 40 bps [D3] |
| Custody / other | 0 bps / 0 bps [D2] | 5 bps / 0 bps [D3] |
| Total modeled ongoing cost | 65 bps; USD3,250/year on USD500,000 [D2, D4] | 77 bps; USD3,850/year on USD500,000 [D3, D4] |
| One-time cost | USD200, kept separate [D2, D4] | USD0 supplied, kept separate [D3, D4] |
| Liquidity | EQ/BD 2 days, cash 0 days [D2] | FUND-Z 90 days, cash 0 days [D3] |
| Proposal flags | Proprietary, revenue-sharing, and cheaper-share-class flags are all false for each holding according to current proposal evidence [D2] | FUND-Z is proprietary; revenue-sharing status not supplied; cheaper share class documented available [D3] |

The proposal desk says BETA has lower advisory fees and may be attractive, but no total-cost calculation was supplied. [D3] The calculated total ongoing cost from supplied fields is higher for BETA than ALPHA because BETA's higher fund expense and custody fee more than offset its lower advisory fee. [D2, D3, D4]

## Look-Through Policy Checks

Comparison policy CP-DUNE v1 requires the same USD500,000 scope, one-time cost kept separate from ongoing expenses, issuer maximum 40%, sector maximum 70%, illiquid maximum 20% using a 30-day horizon, and annual modeled-cost limit of 80 bps. All classes, including cash and sovereigns, remain in sourced exposure arithmetic. [D4]

| Check | Policy threshold | ALPHA calculated from supplied data | BETA calculated from supplied data |
|---|---:|---:|---:|
| Modeled ongoing cost | <= 80 bps [D4] | 65 bps; within limit [D2, D4] | 77 bps; within limit [D3, D4] |
| Max look-through issuer | <= 40% [D4] | Issuer A 30%, issuer B 30%, GOV1 30%, CASH1 10%; within limit [D2, D4] | Issuer A 60%, issuer C 20%, CASH1 20%; exceeds limit [D3, D4] |
| Max sector | <= 70% [D4] | Technology 60%, sovereign fixed income 30%, cash 10%; within limit [D2, D4] | Technology 80%, cash 20%; exceeds limit [D3, D4] |
| Illiquid exposure over 30 days | <= 20% [D4] | 0% based on EQ/BD 2-day and cash 0-day liquidity; within limit [D2, D4] | 80% based on FUND-Z 90-day liquidity; exceeds limit [D3, D4] |

## Evidence Questions for Contemplated Switch

These are evidence questions for human follow-up. They are not system changes and do not imply approval.

| Question | Why it matters | Supplied owner / next owner basis | Source |
|---|---|---|---|
| What is the complete advisor rationale for considering ALPHA versus BETA? | Recommendation file states advisor rationale is incomplete; committee has not chosen a proposal. | Advisor Chen is named on the recommendation file; current review owner/routing includes Patel. | [D5, D6] |
| Is BETA eligible despite exceeding supplied comparison limits for issuer, sector, and illiquidity? | BETA breaches multiple CP-DUNE comparison thresholds on supplied look-through arithmetic. | Patel is control owner for CP-DUNE and supervision routing/current review owner. | [D3, D4, D5, D6] |
| How should the proprietary FUND-Z conflict be treated? | Conflict inventory records proprietary FUND-Z but lacks treatment information. | Recommendation/conflict inventory owner not separately supplied; advisor Chen and routing Patel are the named owners in the packet. | [D3, D5] |
| Is there revenue sharing for FUND-Z? | Upstream artifact PROPOSAL-DUNE-9 says BETA FUND-Z revenue-sharing evidence is missing and unresolved. | Patel is reviewer/current review owner; proposal desk supplied BETA evidence. | [D3, D6] |
| If a cheaper FUND-Z share class is available, why would the contemplated switch use the proposed class? | Cheaper share class is documented available, but treatment is missing. | Advisor Chen and routing Patel are named; no separate share-class owner supplied. | [D3, D5] |
| Has the trading-series review been received and reviewed? | Recommendation file says trading-series review has not been received. | Advisor Chen is named on the recommendation file; Patel is supervision routing. | [D5] |
| Was disclosure LIB-ADV v6 delivered before the September 17 review? | D5 says LIB-ADV v6 was required before the September 17 review, but recorded delivery is September 18; no evidence is dated as already delivered today. | Advisor Chen/recommendation file and Patel routing are supplied; delivery owner not separately supplied. | [D5] |
| Is model approval/selection evidence authenticated beyond attribution? | D1 says the approval evidence is attributed selection/approval evidence, not authentication. | Committee secretary/reference MIN-33 is named as approval record owner. | [D1] |
| Are there turnover or trade instructions for implementing either proposal? | D1 states no turnover or trade instructions accompany the mandate. | Not supplied; committee should request from the appropriate advisory/trading owner. | [D1] |

## Draft Committee Position for Review

Based solely on the packet, ALPHA appears evidence-ready for comparison purposes relative to the supplied model sleeve and CP-DUNE arithmetic, subject to general human review of suitability/alignment materials already described as received. [D1, D2, D4, D5] BETA may have a lower advisory fee, but it has a higher calculated total ongoing cost than ALPHA and unresolved evidence issues around concentration, sector exposure, illiquidity, proprietary conflict treatment, revenue-sharing, and cheaper-share-class treatment. [D3, D4, D5, D6]

The recommendation should not be marked cleared merely because comparison records exist. D6 explicitly instructs retaining the unresolved revenue-sharing issue when moving comparison into recommendation evidence. [D6]
