# Calculation Notes

Review date: 2026-09-17  
Source: `source_packet.json`

These notes document arithmetic derived from the supplied source assertions. They are not independent verification.

## Model Sizing

USD500,000 x 60% EQ = USD300,000. [D1]

USD500,000 x 30% BD = USD150,000. [D1]

USD500,000 x 10% cash = USD50,000. [D1]

## Ongoing Cost

ALPHA weighted fund expense:

60% x 20 bps + 30% x 10 bps + 10% x 0 bps = 15 bps. [D2]

ALPHA total ongoing cost:

15 bps fund expense + 50 bps advisory + 0 bps custody + 0 bps other = 65 bps, or USD3,250 annually on USD500,000. [D2, D4]

BETA weighted fund expense:

80% x 40 bps + 20% x 0 bps = 32 bps. [D3]

BETA total ongoing cost:

32 bps fund expense + 40 bps advisory + 5 bps custody + 0 bps other = 77 bps, or USD3,850 annually on USD500,000. [D3, D4]

## Look-Through Exposures

ALPHA:

EQ is 60% of the proposal. EQ look-through is issuer A half and issuer B half, so issuer A = 30% and issuer B = 30%. BD is 30% GOV1. Cash is 10% CASH1. [D2]

Technology exposure is 60% from issuers A and B. Sovereign fixed-income exposure is 30% from GOV1. Cash exposure is 10%. [D2]

Illiquid exposure over the 30-day horizon is 0% because EQ and BD have 2-day liquidity and cash has 0-day liquidity. [D2, D4]

BETA:

FUND-Z is 80% of the proposal. FUND-Z look-through is issuer A 75% and issuer C 25%, so issuer A = 60% and issuer C = 20%. Cash is 20% CASH1. [D3]

Technology exposure is 80% from issuers A and C. Cash exposure is 20%. [D3]

Illiquid exposure over the 30-day horizon is 80% because FUND-Z has 90-day liquidity and cash has 0-day liquidity. [D3, D4]

