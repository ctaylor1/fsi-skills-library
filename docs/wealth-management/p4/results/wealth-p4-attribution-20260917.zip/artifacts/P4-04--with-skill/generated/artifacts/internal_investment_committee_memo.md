# HH-DUNE Internal Investment-Committee Memo

Draft for human review. Synthetic records only. Review as of 2026-09-17. No committee decision, client delivery, trade instruction, approval or system update is made by this draft.

## Scope and Source Posture

HH-DUNE asked the US advisory team to show how the supplied model sizes a candidate, compare ALPHA and BETA, and assemble evidence questions for a contemplated nonretirement strategy switch. This memo uses only records D1-D6 from `source_packet.json` and local deterministic calculations from the installed skills. Source assertions are treated as supplied evidence, not authenticated facts. Model approval, policy ownership, proposal terms, evidence receipt and review routing all remain subject to human verification. [D1][D2][D3][D4][D5][D6]

Local artifacts generated for review:

| Workflow | Artifact | Status | Use |
| --- | --- | --- | --- |
| Model sizing | `portfolio-construction-assistant-34180aff82c43d062fa7` | `review-ready` | Arithmetic/constraint check only; not approval |
| Proposal comparison | `portfolio-proposal-comparator-5cb70ac35e3b896f4c34` | `needs-data` | Comparison with unresolved BETA issues preserved |
| Switch evidence review | `investment-recommendation-evidence-reviewer-de9b075112b1a93e5da3` | `needs-data` | Evidence inventory/questions only |

The local scripts validated their inputs and outputs with zero validation errors. Platform startup emitted cache warnings from `python3`, but the validators exited successfully.

## Executive View

The supplied model sizes the candidate at USD 500,000 as EQ 60% / BD 30% / cash 10%, producing USD 300,000 EQ, USD 150,000 BD and USD 50,000 cash. The local construction check found the candidate consistent with the supplied equity, bond, cash and position limits, assuming the supplied universe eligibility and attributed approval record are accurate. [D1]

ALPHA and BETA are comparable on the same USD 500,000 scope, but the comparison does not select a winner. ALPHA shows lower ongoing modeled cost and lower first-year modeled dollars under the supplied components. BETA has lower advisory bps but higher all-in ongoing modeled cost after fund expense and custody are included. BETA also has unresolved conflict, concentration and liquidity issues under the supplied comparison policy. [D2][D3][D4][D6]

The contemplated switch file is not recommendation-ready. The applicability profile is supplied as US advisory fiduciary, nonretirement, with no automatic Reg BI/Rule 2111 stack, but all nine applicable evidence checks remain incomplete in the local evidence review because evidence reviewer/date fields are not supplied and substantive gaps remain. Rollover and retirement-applicability checks are not applicable under the supplied nonretirement switch facts. [D5][D6]

## 1. Supplied Model Candidate Sizing

Source assertion: D1 supplies a USD 500,000 sizing amount, method `proportional-within-model-sleeve`, model M-D1 v3, attributed approval evidence from committee secretary / MIN-33, EQ 60%, BD 30% and cash 10%. D1 states EQ and BD are eligible in the supplied universe, individually capped at 70%; mandate limits are max position 70%, cash 5-20%, equity 50-70%, bonds 20-40%, cash 5-20%, and no restricted security IDs are recorded. [D1]

Local calculation from D1:

| Holding | Weight | Amount | Constraint comment |
| --- | ---: | ---: | --- |
| EQ | 60% | USD 300,000 | Within 50-70% equity band and 70% position cap |
| BD | 30% | USD 150,000 | Within 20-40% bond band and 70% position cap |
| Cash | 10% | USD 50,000 | Within 5-20% cash band |

Construction conclusion: constraint-consistent as arithmetic under the supplied model/universe. This is not authentication of model approval, not a suitability finding, not a return forecast, and not trade sizing. D1 itself says the selection/approval evidence is attributed evidence, not authentication, and no turnover or trade instructions accompany it. [D1]

## 2. Proposal Comparison: ALPHA vs BETA

Source assertions:

ALPHA: USD 500,000 with EQ 60%, BD 30%, cash 10%; EQ expense 20 bps, BD 10 bps, cash 0 bps; advisory 50 bps, custody 0 bps, other 0 bps; one-time transaction cost USD 200; EQ and BD liquidity 2 days, cash 0; no proprietary, revenue-sharing or cheaper-share-class flags. [D2]

BETA: USD 500,000 with FUND-Z 80%, cash 20%; FUND-Z expense 40 bps, cash 0; advisory 40 bps, custody 5 bps, other 0 bps; one-time cost 0; FUND-Z liquidity 90 days, cash 0; FUND-Z is proprietary, revenue-sharing status is not supplied and cheaper share class is documented available. [D3]

Comparison policy: issuer max 40%, sector max 70%, illiquid max 20% using a 30-day horizon, annual modeled-cost limit 80 bps; all classes including cash/sovereigns stay in sourced exposure arithmetic; compare same USD 500,000 scope and keep one-time cost separate. [D4]

Local comparison from D2-D4:

| Metric | ALPHA | BETA | BETA minus ALPHA |
| --- | ---: | ---: | ---: |
| Weighted fund expense | 15 bps | 32 bps | +17 bps |
| Advisory fee | 50 bps | 40 bps | -10 bps |
| Custody fee | 0 bps | 5 bps | +5 bps |
| Other annual cost | 0 bps | 0 bps | 0 bps |
| Ongoing modeled cost | 65 bps | 77 bps | +12 bps |
| Ongoing modeled dollars | USD 3,250 | USD 3,850 | USD 600 |
| One-time transaction cost | USD 200 | USD 0 | -USD 200 |
| First-year modeled dollars | USD 3,450 | USD 3,850 | USD 400 |

BETA’s lower advisory fee alone is not the total cost comparison; after supplied fund expense and custody components, BETA is 12 bps higher on ongoing modeled cost and USD 400 higher on first-year modeled dollars. This is a component comparison, not a prediction of returns or lifetime cost. [D2][D3][D4]

Exposure and liquidity:

| Metric | ALPHA | BETA | Policy observation |
| --- | ---: | ---: | --- |
| Max issuer exposure | 30% | 60% issuer A | BETA exceeds 40% issuer max |
| Max sector exposure | 60% technology | 80% technology | BETA exceeds 70% sector max |
| Illiquid weight over 30-day horizon | 0% | 80% | BETA exceeds 20% illiquid max |
| Look-through coverage | 100% supplied | 100% supplied | Coverage complete under supplied rows |

ALPHA did not produce comparison findings under the supplied policy. BETA produced unresolved findings for proprietary conflict review, unknown revenue-sharing, cheaper-share-class availability, issuer concentration, sector concentration and liquidity. D6 separately says the upstream issue `revenue-sharing-unknown` is unresolved and must be retained in recommendation evidence. [D2][D3][D4][D6]

## 3. Switch Evidence Review Questions

Source assertion: D5 says the contemplated action is a nonretirement strategy switch, not a rollover; investment profile and risk/objective/liquidity alignment notes are received; risks/features/costs are documented by D2-D4; alternatives inventory includes ALPHA/BETA but advisor rationale is incomplete; trading-series review has not been received; conflict inventory records proprietary FUND-Z and cheaper class but lacks treatment and revenue-sharing information; supervision routing is Patel and is not approval; LIB-ADV v6 was required before the September 17 review, with recorded delivery on September 18 and no evidence dated as already delivered today. [D5]

Source assertion: D6 supplies profile AP-DUNE v2 as US advisory_fiduciary, nonretirement scope, rationale and current review owner Patel; it says no automatic Reg BI/Rule 2111 stack is supplied and preserves the unresolved BETA revenue-sharing issue. [D6]

Evidence status from local review: 9 applicable checks incomplete, 2 checks not applicable, determination not made. The incompleteness is driven by missing evidence reviewer/date fields across supplied records plus substantive gaps below. [D5][D6]

Key questions for committee/advisor/compliance before any switch recommendation:

| Topic | Evidence question | Current source position | Suggested next owner |
| --- | --- | --- | --- |
| Recommendation rationale | What is the advisor’s rationale for switching, including why the selected proposal is preferred over the available alternative? | Alternatives inventory includes ALPHA/BETA, but rationale is incomplete. [D5] | Advisor Chen |
| BETA concentration | Is the BETA issuer A 60% exposure and technology 80% exposure acceptable under CP-DUNE, or should BETA be revised/escalated? | BETA exceeds supplied 40% issuer and 70% sector limits in local comparison. [D3][D4] | Advisor Chen with Patel/control owner |
| BETA liquidity | Is 80% FUND-Z at 90-day liquidity acceptable for the client’s liquidity alignment and policy limit? | BETA exceeds the 20% illiquid limit using the 30-day horizon. [D3][D4] | Advisor Chen with portfolio specialist/Patel |
| Revenue sharing | Does FUND-Z have revenue sharing, and if so what is the amount, treatment and disclosure? | Revenue-sharing status is not supplied; D6 marks it unresolved. [D3][D6] | Proposal desk / product due diligence |
| Proprietary and cheaper class conflict treatment | What treatment/mitigation is required for proprietary FUND-Z and the cheaper share class? | Conflict inventory records both, but treatment is missing. [D3][D5] | Compliance / conflicts owner |
| Trading series | Has a trading-series review been completed for the switch? | Not received. [D5] | Advisor Chen / supervision process owner |
| Disclosure timing | Was LIB-ADV v6 delivered before the September 17 review, or is the September 18 recorded delivery the only evidence? | Required before Sept. 17 review; delivery recorded Sept. 18; no same-day delivered evidence. [D5][D6] | Advisor Chen / client service / compliance |
| Supervision | What review/approval is required, and has it been completed by an authorized reviewer? | Routing to Patel is supplied, but source states routing is not approval. [D5] | Patel / supervisory review owner |
| Evidence review metadata | Who reviewed each evidence item, and on what date? | Source packet does not identify item-level evidence reviewer/date for the evidence records. [D5][D6] | Advisor team / compliance evidence owner |
| Model approval authentication | Is committee secretary/MIN-33 approval record authenticated and applicable to current use? | D1 says approval evidence is attributed, not authentication. [D1] | Committee secretary / model governance |

## Committee Considerations

The committee has not chosen a proposal. Based on supplied comparisons, ALPHA has fewer unresolved comparison issues under the supplied policy: lower modeled ongoing/first-year cost, no flagged conflicts, and issuer/sector/liquidity within supplied limits. BETA may still be considered only after resolving the revenue-sharing, proprietary/cheaper-class treatment, concentration, liquidity and rationale questions. This memo does not recommend ALPHA or BETA and does not predict performance. [D2][D3][D4][D5][D6]

Before any client recommendation or implementation planning, the file should be refreshed with sourced answers to the unresolved questions, reviewed evidence metadata, and any required approval records. No trade planning should proceed until an authorized professional selects a target and supplies implementation instructions.
