# HH-DUNE Client-Discussion Summary

Draft for advisor use only. Not delivered. Review as of 2026-09-17. The committee has not selected a proposal.

## Purpose

We reviewed the supplied model sizing and two proposal records for HH-DUNE using only the packet records. The review compares supplied costs, exposures, liquidity and conflict information. It does not forecast returns or make a recommendation. [D1][D2][D3][D4][D5][D6]

## Model Sizing

The supplied model sizes USD 500,000 as:

| Component | Weight | Dollar amount |
| --- | ---: | ---: |
| EQ | 60% | USD 300,000 |
| BD | 30% | USD 150,000 |
| Cash | 10% | USD 50,000 |

The sizing fits the supplied mandate bands for equity, bonds and cash, assuming the supplied eligibility and approval references are verified. [D1]

## Proposal Comparison

| Topic | ALPHA | BETA |
| --- | --- | --- |
| Ongoing modeled cost | 65 bps / USD 3,250 | 77 bps / USD 3,850 |
| First-year modeled cost | USD 3,450 | USD 3,850 |
| Highest issuer exposure | 30% | 60% issuer A |
| Highest sector exposure | 60% technology | 80% technology |
| Illiquid weight by 30-day horizon | 0% | 80% |
| Conflict items | No supplied proprietary, revenue-sharing or cheaper-share-class flags | Proprietary FUND-Z, cheaper share class available, revenue-sharing not supplied |

BETA has lower advisory fee bps, but the supplied total ongoing modeled cost is higher once fund expense and custody are included. BETA also raises unresolved liquidity, concentration and conflict questions under the supplied policy. [D2][D3][D4][D6]

## Discussion Questions Before Any Switch

1. What client objective or constraint would the switch be intended to improve? [D5]
2. How should the advisor explain ALPHA versus BETA as available alternatives? [D5]
3. If BETA remains under consideration, how will the team address issuer concentration, technology-sector concentration and 90-day liquidity? [D3][D4]
4. What is the revenue-sharing status for FUND-Z, and what treatment is required for proprietary status and the cheaper share class? [D3][D5][D6]
5. Was LIB-ADV v6 delivered before the September 17 review, or is the September 18 record the only delivery evidence? [D5][D6]
6. What supervisory review or approval is required, given that routing to Patel is not itself approval? [D5]

No proposal should be described as selected or approved until the committee/advisor and required reviewers resolve the evidence questions.

