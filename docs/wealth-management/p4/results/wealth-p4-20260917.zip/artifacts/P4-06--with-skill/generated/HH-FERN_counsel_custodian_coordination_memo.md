# HH-FERN Counsel/Custodian Coordination Memo

Review as of: 2026-09-17  
Audience: authorized advisor, estate counsel, custodian liaison, protection specialist for context only  
Draft status: human review required; no action taken; not delivered  
Machine artifact: `estate_hh_fern_artifact.json`  
Artifact ID: `estate-wealth-transfer-reviewer-36ea828c061d4ed09f25`  
Artifact status: `needs-data`

## Scope and Use

This memo is a coordination draft, not legal drafting, tax advice, document interpretation, beneficiary-update instruction or custodian service request. It compares supplied source assertions about HH-FERN intentions with supplied custodian/record assertions. It does not determine legal effect, document validity, document precedence, beneficiary eligibility or whether any record should be changed.

## Evidence Basis

| Source ID | Source assertion used in this draft | Owner/source type |
| --- | --- | --- |
| F1 | Household intent interview dated 2026-09-16, current through 2026-09-30. Includes asserted IRA-F intent, BANK-F trust-ownership intent, current will/trust listing, POA unknown status and healthcare directive not collected. | Advisor Gray / client-intent assertion |
| F2 | Custodian designations and asset links dated 2026-09-17, current through 2026-09-30. Includes asserted current IRA-F beneficiary record, BANK-F individual registration and lack of governing-document links. | Custodian liaison / record assertion |
| F3 | Estate review policy EW-F v1, effective 2026-09-01 through 2026-12-31. Requires current will, trust, POA and healthcare-directive evidence, plus primary/contingent IRA schedules. | Counsel coordinator Gray / supplied review policy |

Local verification completed: the structured estate input validated with 0 errors; the generated estate artifact validated with 0 errors. That validation checks schema, source-date coverage, comparisons and artifact consistency. It does not authenticate source truth or legal effect.

## Concrete Mismatches for Meeting

| Item | Supplied intention or policy assertion | Supplied record assertion | Meeting issue | Source IDs | Next owner |
| --- | --- | --- | --- | --- | --- |
| IRA-F primary beneficiary | F-A intends spouseF-B as 100% primary beneficiary. | Current custodian designation DES-F3 records former spouseF-X as 100% primary beneficiary. | Primary beneficiary identity differs: spouseF-B intended vs former spouseF-X recorded. | F1, F2 | Advisor to confirm client intent; custodian to confirm current designation record; counsel to advise on legal/document context. |
| IRA-F contingent beneficiaries | F-A intends childrenF-C/F-D as 50% each contingent. | Current custodian designation DES-F3 records childF-C 60% and childF-D 40% contingent. | Contingent share schedule differs: intended 50/50 vs recorded 60/40. | F1, F2 | Advisor to confirm intent; custodian to confirm schedule and form/version. |
| BANK-F ownership | Intention is trustTR-F ownership; policy source also says owner/document intention for BANK-F is TR-F. | BANK-F registration remains individual F-A. | Recorded owner differs from stated trust-ownership intention. No transfer was requested. | F1, F2, F3 | Counsel to advise on desired legal structure; custodian to identify required process only after separate authorization. |
| BANK-F governing-document link | Intended governing-document link is trustTR-F. | BANK-F has no governing-document links. | Intended trust link differs from recorded no-link status. | F1, F2, F3 | Counsel to confirm whether any trust/account linkage is legally intended; custodian to confirm record fields and requirements. |

## Missing or Unresolved Evidence

| Open item | Why it matters for coordination | Source IDs | Next owner |
| --- | --- | --- | --- |
| IRA-F recorded owner and titling intention were not collected in the supplied packet. | The estate artifact flags ownership/titling as unknown for IRA-F; no title mismatch conclusion was made. | F1, F2 | Advisor/custodian liaison |
| IRA-F governing-document intention was not collected. | No inference was made about whether any will/trust/account form controls IRA-F. | F1, F2 | Advisor/counsel |
| BANK-F beneficiary intention remains uncollected. | No inference was made from the absence of a separate BANK-F beneficiary designation. | F3 | Advisor/counsel |
| No source states whether a will, trust or account form legally controls. | Legal effect and precedence are outside this comparison. | F2 | Estate counsel |
| WillW-F v2 and trustTR-F v1 are asserted current and executed in 2024, with signed copies in counsel register, but exact execution dates were not supplied. | Local artifact preserves a document-status/date gap and makes no validity inference. | F1 | Estate counsel |
| Power-of-attorney has unknown current status. | Policy requires current POA evidence; no current POA record was supplied. | F1, F3 | Estate counsel/advisor |
| Healthcare directive was not collected. | Policy requires healthcare-directive evidence; no current healthcare-directive record was supplied. | F1, F3 | Estate counsel/advisor |

## Meeting Questions

1. For IRA-F, does F-A still intend spouseF-B 100% primary and childF-C/childF-D 50/50 contingent, as asserted in F1, despite the custodian record in F2 showing former spouseF-X 100% primary and 60/40 contingent shares?
2. Can the custodian confirm DES-F3 as the only current IRA-F designation and provide the form/version or record locator supporting the F2 schedule?
3. Does counsel have reviewed copies of WillW-F v2 and trustTR-F v1, including exact execution dates and current/superseded status?
4. For BANK-F, should counsel/advisor treat the trust-ownership intention as current client intent, given that F1 says no transfer was requested and F2 says the account remains individually registered to F-A?
5. What evidence is needed to confirm or update the POA and healthcare-directive status under the EW-F v1 review scope?

## Guardrails

Do not use this memo to change titles, beneficiaries or account records. Any custodian packaging, beneficiary update or transfer request needs a separate authorized workflow after professional review. The memo preserves source assertions and local comparison results only.
