# HH-FERN Protection-Needs Worksheet

Review as of: 2026-09-17  
Audience: authorized advisor, protection specialist, estate counsel for coordination context  
Draft status: human review required; no action taken; not delivered  
Machine artifact: `protection_hh_fern_artifact.json`  
Artifact ID: `protection-needs-reviewer-d823207e01533b231886`  
Artifact status: `review-ready`

## Scope and Use

This worksheet uses supplied level-undiscounted assumptions only. It is not a product recommendation, coverage adequacy conclusion, underwriting view, claims determination, legal insurance requirement or policy-change instruction. Each scenario is an independent alternative event; scenario gaps are not added together.

Local verification completed: the structured protection input validated with 0 errors; the generated protection artifact validated with 0 errors. That validation checks schema, source-date coverage, arithmetic and artifact consistency. It does not verify actual contract terms, claim payment, tax treatment or resource availability outside the supplied assertions.

## Evidence Basis

| Source ID | Source assertion used in this worksheet | Owner/source type |
| --- | --- | --- |
| F4 | Protection assumptions PP-F v2 dated 2026-09-17, current through 2026-09-30. Includes survivor and disability assumptions, level-undiscounted method and statement that no inflation, discounting, probability, claims or coverage interpretation is requested. | Specialist Harper / assumption source |
| F5 | Additional protection assumptions dated 2026-09-17, current through 2026-09-30. Includes long-term-care and liability assumptions and states liability applicability already reflects defense treatment. | Harper / assumption source |
| F6 | Designated resource record dated 2026-09-17, current through 2026-09-30. Includes RES-CASH, RES-LTC and RES-LIAB availability, resource-reuse note and policy requirement for the four scenario types. | Planner Gray / resource source |

## Scenario Results

| Scenario | Supplied assumptions | Local calculation | Modeled remaining gap | Source IDs |
| --- | --- | --- | --- | --- |
| Survivor | Annual spending 90,000; annual survivor income 45,000; support 10 years; debt payoff 150,000; one-time costs 20,000; applicable life benefit 300,000; RES-CASH 50,000 available. | Annual gap 45,000 x 10 = 450,000 support need. Gross need 620,000. Insurance offset 300,000. Resource offset 50,000. | 270,000 | F4, F6 |
| Disability | Monthly spending 7,500; other income 2,500; duration 24 months; waiting period 3 months; applicable monthly benefit 4,000; RES-CASH 50,000 available. | Monthly gap 5,000 x 24 = 120,000 gross need. Eligible benefit months 21. Insurance offset 84,000. Resource offset 50,000. | 0, with 14,000 surplus under supplied assumptions | F4, F6 |
| Long-term care | Monthly care cost 9,000; duration 30 months; waiting period 3 months; monthly benefit 6,000; benefit-month limit 24; lifetime benefit cap 120,000; RES-LTC 30,000 available. | Gross need 270,000. Eligible benefit months 24. Uncapped modeled benefit 144,000, capped at 120,000. Resource offset 30,000. | 120,000 | F5, F6 |
| Liability | Projected loss 500,000; defense costs 50,000; applicable primary amount 100,000; applicable umbrella amount 300,000; RES-LIAB 20,000 available. | Gross need 550,000. Supplied applicable insurance amount 400,000. Resource offset 20,000. | 130,000 | F5, F6 |

## Resource Reuse and Independence

RES-CASH is the same 50,000 cash reserve and is explicitly available separately for the survivor and disability scenarios. The source says it is the same reserve, not two assets. Because these are alternative scenarios, the artifact flags the reuse but does not add scenario needs together or model concurrent events. (F6)

RES-LTC and RES-LIAB are separate available resources for their respective scenarios. All designated resources exclude insurance benefits already counted in the assumptions. No other resources are designated, which does not assert that no other household assets exist. (F6)

## Protection Specialist Questions

1. Survivor: Are the 90,000 spending, 45,000 survivor income, 10-year horizon, 150,000 debt payoff and 20,000 one-time costs still the intended planning assumptions? The modeled gap is 270,000 under those inputs. (F4, F6)
2. Disability: Confirm actual contract provisions, exclusions, waiting period, benefit tax treatment and whether the 4,000 monthly benefit is applicable as modeled. The deterministic scenario shows no gap only under the supplied assumptions. (F4, F6)
3. Long-term care: Confirm whether the 24 eligible benefit months and 120,000 lifetime cap are the appropriate modeled constraints before relying on the 120,000 gap. (F5, F6)
4. Liability: Confirm that the supplied 100,000 primary and 300,000 umbrella applicable amounts already reflect defense treatment and actual policy terms before relying on the 130,000 gap. (F5)
5. Resource availability: Confirm whether RES-CASH, RES-LTC and RES-LIAB are actually available for the modeled events and whether any additional resources should be designated in a separate update. (F6)

## Explicit Non-Assumptions

No inflation, discounting, mortality, disability probability, care-cost escalation, claim likelihood, underwriting eligibility, tax rate, policy exclusion analysis or product solution was supplied or inferred. Benefit amounts are modeled offsets from supplied assumptions, not determinations that a claim would be paid. (F4, F5)
