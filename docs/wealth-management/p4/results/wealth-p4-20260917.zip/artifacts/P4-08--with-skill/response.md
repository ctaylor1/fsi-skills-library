Done. I created three local draft files:

- [HH-HEATH_internal_evidence_review_pack.md](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-t88qi3_a/work/HH-HEATH_internal_evidence_review_pack.md)
- [HH-HEATH_advisor_only_issue_note.md](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-t88qi3_a/work/HH-HEATH_advisor_only_issue_note.md)
- [HH-HEATH_unsent_client_email_draft.md](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-t88qi3_a/work/HH-HEATH_unsent_client_email_draft.md)

The main pack clearly separates Stage 1 pre-meeting evidence from Stage 2 post-meeting follow-up, preserves source assertions vs locally verified packet checks, cites H1-H6 throughout, reports missing evidence and owners, and marks all CRM/email/calendar/trade activity as not performed. The client email draft is separate and limited to the permitted H-A/H-B audience; the advisor-only H4 issue is isolated in its own note.

I used local Python only for packet hash/date/arithmetic checks. I did not run the bundled schema validators because `source_packet.json` is a compact source-record packet, not the normalized v0.2 workflow input contract, and I did not manufacture fields just to satisfy a tool.