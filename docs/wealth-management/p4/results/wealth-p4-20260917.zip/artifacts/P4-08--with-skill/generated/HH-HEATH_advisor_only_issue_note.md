# HH-HEATH Advisor-only Issue Note

Audience: advisor Mira only. Prepared for human review as of 2026-09-17. Do not include this note in the joint household packet, client email, CRM proposal, or assumptions shared with H-B unless separate permission is evidenced. [H4]

## Issue

H-A privately mentioned a possible inheritance and an unresolved dispute with a sibling. Amount and timing are unknown. H-A did not permit disclosure to H-B or use in the joint planning assumptions. [H4]

## Handling Note

Preserve this as restricted context for Mira only. If the topic becomes relevant to planning, obtain explicit consent and documented scope before using it in joint assumptions or communicating it to H-B. No amount, timing, legal position, or planning effect is evidenced. [H4]

Draft-only controls: no client contact, no CRM/system write, no recommendation, and no legal/tax advice. Advisor review remains pending. [H1]
