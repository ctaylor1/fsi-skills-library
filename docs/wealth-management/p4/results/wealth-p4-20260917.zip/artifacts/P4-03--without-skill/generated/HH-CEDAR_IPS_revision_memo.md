# HH-CEDAR IPS Revision Memo

Review date: 2026-09-17  
Prepared for: advisor Dana, planner Sol, supervisory reviewer Rowan  
Draft purpose: reviewable planning-to-IPS handoff; not an approval record.

## Executive Conclusion

The cash-flow illustration supports a narrow statement: using the supplied balances, pension, spending, withdrawal order, tax proxies, and return assumptions, the two-year scenario funds the stated spending in the base case and the -10% stress case [C2, C3, C6].

The IPS mandate is not ready for signature. The packet has signature blockers under the supplied IPS assembly policy: the allocation totals 95% rather than 100%, benchmark selection is pending, ROTH-C is omitted from the IPS tax-treatment register, emergency reserve and liquidity need are unquantified, prior-artifact linkage is missing for revision 2, no client/advisor/supervisor approvals or effective IPS date are recorded, and the packet does not evidence that all 13 IPS sections are substantively supported [C1, C4, C5, C6].

## Source Assertions vs. Derived Review Findings

Source assertion: HP-IPS v4 is supplied for revision 2, but the prior artifact ID was not provided [C1].  
Review finding: revision 2 is missing the explicit prior-artifact linkage required by IPS assembly policy v4 [C6].

Source assertion: intended governance parties are client C, advisor Dana, and supervisor Rowan; the packet records no approval or effective IPS date [C1].  
Review finding: the mandate is not signature-ready because a typed reviewer name or supplied template version does not prove approval, and pending client/advisor/supervisor approvals are required [C6].

Source assertion: the draft allocation is equity 55% with 45-65% band, high-quality fixed income 35% with 25-45% band, and cash 5% with 0-10% band [C4].  
Review finding: the stated allocation sums to 95%, not the 100% required by IPS assembly policy v4 [C6].

Source assertion: account tax treatment is documented for DEF-C, but the IPS tax-treatment register omits ROTH-C [C4].  
Review finding: the IPS does not meet the complete account-tax coverage requirement [C6].

Source assertion: benchmark selection is pending, trades still need a separate process, monitoring is quarterly, and rebalance review is proposed when a class departs its stated band [C4].  
Review finding: monitoring language is partly usable, but benchmark and trade-process content remain incomplete for a signature package.

Source assertion: objective is to fund stated spending while retaining a separately discussed emergency reserve; reserve amount is not documented [C4].  
Review finding: the objective cannot be fully signed as drafted because the governing reserve/liquidity constraint is unresolved [C5].

Source assertion: willingness is 10% from a cited client questionnaire; assessed loss capacity is USD40,000 on USD300,000 investable assets; horizon is 24 months; liquidity need and emergency reserve remain unquantified [C5].  
Review finding: the IPS should preserve the six risk dimensions separately and should not collapse them into one score [C5].

Source assertion: IPS assembly policy v4 requires all 13 sections substantively supported [C6].  
Review finding: the packet does not supply enough section-by-section evidence to verify that all 13 sections are substantively supported.

## Cash-Flow Finding for IPS Language

Suggested limited planning language:

> Based solely on the supplied two-year illustration, the stated spending need is funded in each illustrated annual interval after applying the supplied pension, withdrawal order, account tax proxies, and return assumptions. The illustration does not verify sufficiency for the separately discussed emergency reserve, unmodeled taxes, RMDs, benefit eligibility, survivor changes, long-term-care shocks, or periods beyond the 24-month horizon.

Do not broaden this sentence into a long-term sufficiency statement. The packet supplies no probability-of-success model and excludes several planning domains [C3, C6].

## Proposed IPS Revision Notes

1. Objective
   - Retain: fund the stated spending.
   - Revise before signature: define the emergency reserve amount and near-term liquidity need, or state that they remain unresolved and cannot yet govern the signed mandate [C4, C5].

2. Allocation
   - Current source allocation: equity 55%, high-quality fixed income 35%, cash 5%; total 95% [C4].
   - Required before signature: resolve the missing 5 percentage points or revise the allocation to total 100% [C6].

3. Bands and monitoring
   - Current source bands: equity 45-65%, high-quality fixed income 25-45%, cash 0-10%; quarterly monitoring; rebalance review when a class departs its band [C4].
   - Required before signature: complete the trade/rebalance implementation process or identify the separate governing trade process [C4].

4. Restrictions
   - Current source restrictions: no leverage and no direct tobacco holdings [C4, C5].
   - Required before signature: confirm whether these are complete restrictions for this mandate or document any missing restriction review.

5. Account tax-treatment register
   - Current source status: DEF-C treatment documented; ROTH-C omitted [C4].
   - Required before signature: add ROTH-C coverage or document why it is out of scope. The current packet says both balances are available in the simplified illustration [C2].

6. Benchmark
   - Current source status: benchmark selection pending [C4].
   - Required before signature: add benchmark selection or document the pending status as a blocker.

7. Revision control and approvals
   - Current source status: revision 2 template supplied, prior artifact ID missing, no approval or effective IPS date recorded [C1].
   - Required before signature: add prior-artifact linkage and collect/document client, advisor, and supervisor approvals under the assembly policy [C6].

## Missing Evidence and Next Owners

| Missing evidence / unresolved item | Why it matters | Next owner |
|---|---|---|
| Emergency reserve dollar amount | Needed to determine whether spending objective and reserve objective can both be supported | Dana, with planning input from Sol [C4, C5] |
| Near-term liquidity need | Risk handoff issue RP-CEDAR-4 remains unresolved | Dana [C5] |
| Allocation total equals 100% | IPS assembly policy requires allocation total 100%; current source total is 95% | Dana, review by Rowan [C4, C6] |
| Benchmark selection | Source says benchmark selection is pending | Dana [C4] |
| Trade/rebalance process | Source says trades still need a separate process | Dana / operations owner to be named [C4] |
| ROTH-C in IPS tax-treatment register | IPS policy requires complete account-tax coverage | Dana, review by Rowan [C4, C6] |
| Prior artifact ID for revision 2 | Required for revisions after 1 | Dana or document-control owner, review by Rowan [C1, C6] |
| Client/advisor/supervisor approvals and effective date | Required before signature; typed names or template version do not prove approval | Client C, Dana, Rowan [C1, C6] |
| Confirmation that listed restrictions are complete | Current packet documents no leverage and no direct tobacco only | Dana [C4, C5] |
| Evidence that all 13 IPS sections are substantively supported | IPS assembly policy requires all 13 sections substantively supported | Dana, review by Rowan [C6] |

## Supervisory Readiness Decision

Recommended status: not ready for signature.

Rationale: the spending illustration is arithmetically complete for the supplied two-year scenario, but the IPS revision has unresolved governance, completeness, and policy requirements. The supervisory reviewer can use the calculation as planning support, but should not treat the mandate as signature-ready until the blockers above are resolved and approvals are documented [C1, C4, C5, C6].
