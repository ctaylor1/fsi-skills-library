# HH-CEDAR Two-Year Retirement Cash-Flow Illustration

Review date: 2026-09-17  
Audience: advisor Dana, planner Sol, supervisory reviewer Rowan  
Scope: synthetic US advisory planning draft in USD, using only `source_packet.json`.

## Short Answer

Under the supplied simplified scenario, the illustrated spending is funded in both annual intervals under the base case and the -10% stress case. This conclusion uses the supplied balances, withdrawal order, tax proxies, pension, spending, and return assumptions [C2, C3]. The spending gap is fully covered by DEF-C withdrawals in each year, with no ROTH-C withdrawals needed and no illustrated unfunded spending gap.

This is not a probability-of-success result, tax opinion, RMD analysis, benefits analysis, or emergency-reserve sufficiency review. The source packet explicitly excludes tax brackets/basis, RMDs, benefit eligibility, survivor transitions, long-term-care shocks, and any supplied probability-of-success model [C3, C6].

## Source Assertions Used

- Client C is age 65 in the first complete annual interval beginning 2026-09-17; the second row is age 66 [C1].
- Opening balances are DEF-C USD200,000 with a 20% effective withdrawal-tax proxy, and ROTH-C USD100,000 with a 0% proxy; withdrawal order is DEF-C then ROTH-C [C2].
- First-year net spending is USD60,000, including healthcare; spending inflation is 0% [C3].
- Pension income is USD30,000 gross at ages 65 and 66 inclusive, with a 20% income-tax proxy and 0% COLA [C3].
- There are no contributions, and withdrawals cover the remaining net spending gap [C2, C3].
- Base return is 0% in both annual intervals; stress return is -10% per year on every account after withdrawals, with other inputs unchanged [C3].
- The calculation method uses complete annual intervals, cent-rounded withdrawals/tax, and returns after withdrawals [C6].

## Verified / Derived Calculation Facts

- Pension tax proxy: USD30,000.00 x 20% = USD6,000.00, using the supplied pension and income-tax proxy [C3].
- Net pension available for spending: USD30,000.00 - USD6,000.00 = USD24,000.00 [C3].
- Net spending gap before account withdrawals: USD60,000.00 - USD24,000.00 = USD36,000.00, using supplied net spending of USD60,000.00 [C3].
- DEF-C gross withdrawal required to produce USD36,000.00 net at a 20% withdrawal-tax proxy: USD45,000.00 gross, USD9,000.00 proxy tax, USD36,000.00 net [C2, C3].
- Because DEF-C can support USD45,000.00 gross in both illustrated years under both scenarios, ROTH-C is not used in this illustration; this follows the supplied DEF-C-first withdrawal order [C2].

## Base Case: 0% Return After Withdrawals

| Annual interval | Age | Starting DEF-C | Starting ROTH-C | Pension net | Net spending | Gross DEF-C withdrawal | Withdrawal tax proxy | ROTH-C withdrawal | Unfunded gap | Return after withdrawals | Ending DEF-C | Ending ROTH-C | Ending total |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 65 | USD200,000.00 | USD100,000.00 | USD24,000.00 | USD60,000.00 | USD45,000.00 | USD9,000.00 | USD0.00 | USD0.00 | USD0.00 | USD155,000.00 | USD100,000.00 | USD255,000.00 |
| 2 | 66 | USD155,000.00 | USD100,000.00 | USD24,000.00 | USD60,000.00 | USD45,000.00 | USD9,000.00 | USD0.00 | USD0.00 | USD0.00 | USD110,000.00 | USD100,000.00 | USD210,000.00 |

Base-case conclusion: the supplied two-year scenario funds the stated spending in both years and ends year 2 with USD210,000.00 illustrated account value.

## Stress Case: -10% Return After Withdrawals

| Annual interval | Age | Starting DEF-C | Starting ROTH-C | Pension net | Net spending | Gross DEF-C withdrawal | Withdrawal tax proxy | ROTH-C withdrawal | Unfunded gap | Return after withdrawals | Ending DEF-C | Ending ROTH-C | Ending total |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 65 | USD200,000.00 | USD100,000.00 | USD24,000.00 | USD60,000.00 | USD45,000.00 | USD9,000.00 | USD0.00 | USD0.00 | -USD25,500.00 | USD139,500.00 | USD90,000.00 | USD229,500.00 |
| 2 | 66 | USD139,500.00 | USD90,000.00 | USD24,000.00 | USD60,000.00 | USD45,000.00 | USD9,000.00 | USD0.00 | USD0.00 | -USD18,450.00 | USD85,050.00 | USD81,000.00 | USD166,050.00 |

Stress-case conclusion: the supplied two-year scenario funds the stated spending in both years and ends year 2 with USD166,050.00 illustrated account value.

## Important Limits and Unknowns for Review

- Tax proxies are supplied scenario assumptions, not statutory tax calculations or distribution-eligibility conclusions [C2].
- No RMDs, tax brackets, basis, benefit eligibility, Roth conversions, or survivor changes were calculated because the packet instructs not to calculate unprovided items [C3].
- Emergency reserve and near-term liquidity need remain unquantified, so this illustration does not verify that the stated spending and the separately discussed reserve can both be maintained [C4, C5].
- The horizon here is 24 months for this illustration only [C5].
- No long-term-care shock or probability-of-success model is supplied [C6].

## Planning-to-IPS Handoff

Planner handoff item: the spending cash-flow illustration can support the IPS objective only for the supplied two-year inputs and only before testing the still-undocumented emergency reserve. The IPS should not state that the overall retirement plan is sufficient beyond this limited two-year scenario [C3, C4, C5, C6].

Advisor handoff item: Dana should document the governing liquidity and emergency-reserve constraint after reviewing all six risk dimensions, rather than converting the dimensions into a single score [C5].

Supervisor handoff item: Rowan should treat the calculation as a source-grounded illustration, not as approval evidence, because the packet records no effective IPS date, no client approval, and no completed IPS-signature package [C1, C6].
