Done. I created the two local drafts:

- [protection_review_HH-IRIS_2026-09-17.md](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-v6egas_q/work/protection_review_HH-IRIS_2026-09-17.md)
- [operations_package_HH-IRIS_2026-09-17.md](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-v6egas_q/work/operations_package_HH-IRIS_2026-09-17.md)

Key outputs: protection review is framed as escalation for authorized review only, not a diagnosis or restriction decision. Operations package carries unresolved DIST-18 conditions, TR-10 status, and aggregate funding: USD 28,000 requested against USD 25,000 settled cash, creating a USD 3,000 shortfall if both are funded from supplied cash. I also ran the local arithmetic check for the amount screen and cited source IDs throughout.