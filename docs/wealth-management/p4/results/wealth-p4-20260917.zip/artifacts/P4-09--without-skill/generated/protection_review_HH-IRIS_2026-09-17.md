# HH-IRIS Protection Screening Draft

Audience: authorized protection reviewer and operations only  
Review date: 2026-09-17  
Scope: source-grounded screening draft from the supplied packet only. No diagnosis, exploitation finding, hold decision, restriction decision, contact instruction, or system change is made in this draft.

## 1. Screening posture

Escalate for authorized protection review based on the supplied brokerage US screening convention that third-party or communication concerns independently warrant escalation to the authorized reviewer. The same configuration states it is not a legal Rule 2165 applicability or hold determination. [I6]

This draft treats the packet as the sole source set. Facts below are either source assertions from the cited records or calculations from cited packet data. No external verification was performed.

No missing field was inferred. The only verified items in this draft are internal arithmetic and consistency checks against the supplied records; all relationship, account, observation, and request details remain source assertions from the packet.

## 2. Source assertions relevant to protection review

- HH-IRIS is described in the packet as a US brokerage relationship. Adult I-A is age 72 and owns individual account AC-IRIS; Relative I-N is not recorded as an account owner or authorized person. The record also states that age is demographic context, trusted-contact information was offered and declined on 2026-09-10, and no impairment determination has been supplied. [I1]
- Request DIST-18 is a proposed USD 18,000 cash distribution to masked new external payee PAY-NEW for "urgent family assistance"; it has not been submitted. Request TR-10 is a proposed USD 10,000 partial cash transfer to masked destination DEST-I in I-A's name; it also has not been submitted. [I2]
- In observed call notes, I-N repeatedly answered questions directed to I-A. I-A reportedly said, "I was told this must happen today and not to tell the rest of the family." The analyst recorded third-party influence=true, urgency=true, and secrecy=true. The same record states confusion, recall, and repetition were not assessed, and no one diagnosed incapacity or established exploitation. [I5]
- The destination disagreement for DIST-18 remains unresolved. The screening configuration includes origin SERVICE-I-18, code destination-conflict, message "DIST-18 destination evidence conflicts," unresolved, with sources I2 and I5. [I2] [I5] [I6]
- A beneficiary-change request was recorded on 2026-09-15; its legal validity was not assessed in the packet. [I4]

## 3. Calculations and screening signals from packet data

- The bounded transaction history states the 2026-08-19 through 2026-09-17 lookback is complete. Executed debits to PAY-REG were USD 1,000 on 2026-09-02, USD 1,200 on 2026-09-08, and USD 800 on 2026-09-10, with no other executed debit in that lookback. [I4]
- Using those three executed debits, the calculated average executed debit is USD 1,000 and the population standard deviation is approximately USD 163.30. A three-standard-deviation amount screen from that baseline is approximately USD 1,489.90. This calculation uses the screening configuration's amount k=3 population standard deviations and minimum baseline of 3. [I4] [I6]
- DIST-18's proposed USD 18,000 debit to new external payee PAY-NEW materially exceeds that calculated baseline screen and also exceeds the supplied new-payee threshold of USD 5,000. [I2] [I4] [I6]
- Executed debits in the bounded history within the recent seven-day window total USD 800 if 2026-09-10 is included; this does not exceed the USD 10,000 recent executed-outflow threshold. The proposed DIST-18 and TR-10 requests are not recorded as executed. [I4] [I6]
- The trusted-contact gap is administrative and excluded from concern counts under the supplied screening configuration. [I1] [I6]

Assumption note: the recent seven-day executed-outflow calculation above treats 2026-09-10 as included in the 2026-09-17 seven-day window. If excluded, the recent executed-outflow total would be USD 0; either way, it does not exceed the supplied USD 10,000 threshold. [I4] [I6]

## 4. Protection review issue list

1. Third-party and communication concerns: I-N is not recorded as an owner or authorized person, yet call notes state I-N repeatedly answered questions directed to I-A, and the analyst recorded third-party influence, urgency, and secrecy. [I1] [I5]
2. Proposed large new-payee distribution: DIST-18 is a proposed USD 18,000 distribution to a masked new external payee for urgent family assistance, and the amount exceeds the configured new-payee and statistical amount screens based on the supplied history. [I2] [I4] [I6]
3. Unresolved destination conflict: DIST-18 has two conflicting destination confirmations, and the supplied screening configuration records an unresolved destination-conflict condition. [I2] [I6]
4. Recent account-change context: a beneficiary-change request was recorded two days before the proposed service requests, but the packet does not assess legal validity. [I4]

## 5. Missing or unresolved evidence

- No impairment determination, incapacity diagnosis, or established exploitation finding is supplied. Do not infer one from age, third-party presence, urgency, secrecy, or the proposed transactions. [I1] [I5]
- Confusion, recall, and repetition observations were not assessed in the supplied call notes. [I5]
- DIST-18 lacks a signed authority record and a tax instruction reference, and its destination evidence is inconsistent. [I2] [I3]
- The extra callback-review condition is recorded as conflicting and not cleared; the service profile states that a conflicting callback condition is not waived merely because it is outside the required list. [I2] [I3]
- The beneficiary-change request's legal validity is unknown from the packet. [I4]
- There is no source authorizing the preparer to contact anyone, change systems, place holds, restrict the account, or submit either request. [I3]

## 6. Recommended next owners

- Authorized protection reviewer: review the third-party/communication concerns, urgency/secrecy statement, unresolved destination conflict, proposed new-payee amount, and recent beneficiary-change context. This is a review referral only, not a restriction or diagnosis decision. [I5] [I6]
- Operations: preserve the unresolved conditions in the service-request package and do not treat the records as complete while required or supplied-conflicting conditions remain unresolved. [I2] [I3]
- Advisor/request intake owner: supply or obtain any missing packet evidence through approved internal procedures only if authorized by firm process. This draft does not authorize external contact. [I3]
