# HH-BIRCH Internal Draft Review

Audience: advisor / planning reviewer. As of 2026-09-17. Draft only; no client delivery, system update, recommendation, investment selection or risk rating.

## Source Posture

This report uses only `source_packet.json`. All people, firms and records are synthetic. The source records are treated as supplied assertions; the local tools verified structure and arithmetic only, not source authenticity, legal ownership, method approval, suitability or authority to act. Source IDs are cited at material claims.

Local artifacts:

- Routing: `drafts/route_output.json`, status `needs-data`.
- Balance-sheet reconciliation: `drafts/reconciliation_output.json`, status `needs-data`.
- Risk-dimension review: `drafts/risk_output.json`, status `needs-data`.
- Planning worksheet: `drafts/planning_output.json`, status `needs-data`.

## Executive Readiness View

Safe to enter a planning conversation:

- Discuss a partial household-share balance sheet with explicit exclusions: JOINT-BANK, EXT-BROKER, HOME and MORTGAGE are included; LEGACY-ACCOUNT and HELD-AWAY-PENSION are not resolved. Computed partial net worth is USD640,000 on a household-share basis: USD840,000 included assets less USD200,000 included liabilities. [B1, B2, B3]
- Discuss that the available monthly cash flow appears positive under supplied figures: USD12,000 after-tax income minus USD7,000 living expenses, USD1,000 family-loan payment and USD500 reserve contribution leaves USD3,500 before goals; after USD2,500 declared goal contributions, USD1,000 remains. [B5]
- Discuss risk dimensions separately: willingness, provisional capacity, liquidity, horizon, experience and constraints can be reviewed, but no rating has been assigned. [B4, B6]
- Discuss that GP-1 is overallocated: USD50,000 balance less USD10,000 reserve leaves USD40,000 available, while USD50,000 is assigned across school and renovation goals. [B5]

Resolve before relying on planning outputs:

- LEGACY-ACCOUNT has two current supplied values, USD90,000 and USD95,000, with no controlling source; the account is excluded from reconciled totals. [B3, B6]
- HELD-AWAY-PENSION is expected but has no value, statement or ownership allocation; it is excluded from reconciled totals. [B1, B3, B6]
- Capacity assessment CA-4 uses USD600,000 investable assets and USD60,000 assessed loss capacity, but it predates reconciliation and must be revisited after balance-sheet issues are resolved. [B4, B6]
- Goal projections are not evaluable as a simultaneous plan until GP-1 allocations are reduced or reprioritized by at least USD10,000. [B5]

## Balance-Sheet Reconciliation

Declared scope: USD advisory household for B-A and B-B; expected assets are JOINT-BANK, EXT-BROKER, HOME, LEGACY-ACCOUNT and HELD-AWAY-PENSION; expected liability is MORTGAGE. Valuation policy allows values at most seven days old. No independent household reference total was supplied. [B1]

Included accounts, local household-share calculation:

| Account | Type | Whole value | Household share | Household value | Notes | Sources |
| --- | --- | ---: | ---: | ---: | --- | --- |
| JOINT-BANK | Asset | USD120,000 | 100% | USD120,000 | Bank and aggregator records are duplicate observations of the same account. | [B2] |
| EXT-BROKER | Asset | USD300,000 | 40% | USD120,000 | Held away; co-owned by B-A and OUTSIDE-C; signed allocation assigns 40% household share and is not transfer authority. | [B3] |
| HOME | Asset | USD600,000 | 100% | USD600,000 | Supplied planning valuation; ownership mapping treated as supplied in scope record. | [B1, B2] |
| MORTGAGE | Liability | USD200,000 | 100% | USD200,000 | Positive liability balance. | [B1, B2] |

Partial totals: included household-share assets USD840,000, liabilities USD200,000, net worth USD640,000. Coverage is 4 included accounts out of 6 expected accounts, so totals are partial and should not be described as complete household wealth. [B1, B2, B3]

Unreconciled:

| Account | Issue | Needed evidence | Next owner |
| --- | --- | --- | --- |
| LEGACY-ACCOUNT | Two September 16 snapshots show USD90,000 and USD95,000; neither source is controlling. | Reconciled value or designated controlling source, with reviewed source ID. | Source owner / planner Imani. [B3, B6] |
| HELD-AWAY-PENSION | Expected account; no value, statement or ownership allocation received. | Current statement/value, ownership/household-share allocation, valuation date and held-away status. | Planner Imani / client-service owner. [B1, B3, B6] |
| Household reference total | No independent household reference total supplied. | Optional independent household-share total if firm process requires tie-out. | Advisor / planning reviewer. [B1] |

## Risk-Dimension Review

No investment recommendation or risk rating is made.

| Dimension | Source assertion | Review observation |
| --- | --- | --- |
| Willingness | B-A recorded maximum willingness to accept a 20% loss using questionnaire Q-W2 version 2, administered by Imani with method record QA-22. | Recorded as source evidence; method approval is not independently authenticated by this draft. [B4] |
| Loss capacity | CA-4 provisionally uses USD600,000 investable assets and USD60,000 assessed loss capacity. | Diagnostic capacity loss percentage is 10.0%; CA-4 must be refreshed after reconciliation. [B4, B6] |
| Liquidity | USD40,000 available, USD70,000 required within 6 months. | Diagnostic liquidity shortfall is USD30,000. [B4] |
| Horizon | Proposed exposure horizon is 24 months. | A supplied 36-month lockup exceeds the recorded horizon. [B4] |
| Experience | B-A has no private-credit experience and is experienced in listed equities. | Proposed private-credit exposure requires human review; no experience is recorded for that instrument type. [B4] |
| Constraint | B-A requests no leverage. | Preserve as a constraint for any later IPS/proposal work. [B4] |

Risk conflicts / review flags:

- Willingness loss amount is USD120,000 using provisional investable assets of USD600,000 times 20%, which exceeds the assessed USD60,000 loss capacity. [B4, B6]
- Supplied scenario loss of USD90,000 exceeds the provisional assessed capacity of USD60,000. [B4, B6]
- Liquidity is underfunded by USD30,000, and the 36-month lockup extends beyond the 6-month liquidity need. [B4]
- 36-month lockup exceeds the 24-month horizon. [B4]
- No private-credit experience is recorded for B-A. [B4]

## Initial Goal-Funding Analysis

Cash-flow figures are source-supplied monthly amounts, not independently verified budget facts. [B5]

| Item | Monthly amount | Sources |
| --- | ---: | --- |
| After-tax income | USD12,000 | [B5] |
| Non-debt living expenses | USD7,000 | [B5] |
| Family-loan scheduled payment | USD1,000 | [B5] |
| Reserve contribution | USD500 | [B5] |
| Surplus before goals | USD3,500 | [B5] |
| Declared goal contributions | USD2,500 | [B5] |
| Remaining after declared goals | USD1,000 | [B5] |

Debt: the USD12,000 zero-interest family loan with USD1,000 monthly payment models to a 12-month payoff with USD0 interest, assuming the supplied fixed payment and no new charges. [B5]

Goal funding pool:

| Pool | Balance | Reserved | Available | Assigned | Over/under |
| --- | ---: | ---: | ---: | ---: | ---: |
| GP-1 | USD50,000 | USD10,000 | USD40,000 | USD50,000 | Overallocated by USD10,000 |

Because GP-1 is overallocated, the tool marks both G-SCHOOL and G-HOME projections as not evaluable as a simultaneous plan. It is safe to discuss the stated priorities, target amounts and monthly contributions, but not safe to present both current allocations as feasible together. [B5]

Declared goals requiring prioritization:

| Goal | Target | Date | Assigned from GP-1 | Monthly contribution | Status |
| --- | ---: | --- | ---: | ---: | --- |
| G-SCHOOL | USD50,000 nominal | 2027-09-17 | USD30,000 | USD1,500 | Blocked by shared-pool over-allocation. [B5] |
| G-HOME | USD30,000 nominal | 2027-09-17 | USD20,000 | USD1,000 | Blocked by shared-pool over-allocation. [B5] |

## Route And Handoff Plan

1. Household reconciliation to `household-wealth-data-reconciler`: preserve declared scope, included partial totals and excluded accounts. Do not pass the partial net worth as complete household wealth. Owner: planning reviewer / source owner for legacy and pension evidence. [B1, B2, B3, B6]
2. Risk profile to `investment-risk-profile-reviewer`: carry willingness, provisional capacity, liquidity, horizon, experience and constraints separately. Advisor or qualified planning professional must reconcile willingness-versus-capacity, liquidity and lockup conflicts; no rating should be selected by this draft. [B4, B6]
3. Financial planning to `household-financial-planning-assistant`: carry unresolved upstream issues and GP-1 over-allocation. Rerun goal projections only after GP-1 assignments are adjusted or an additional sourced pool is supplied. [B5, B6]
4. Later downstream work, if requested: after human resolution, route to IPS/recommendation-evidence workflows with updated source registry, artifact IDs and unresolved findings. This draft does not prepare a proposal, select investments or authorize implementation.

## Client-Discussion Agenda

1. Confirm the household inventory: review included accounts, explain that LEGACY-ACCOUNT and HELD-AWAY-PENSION are unresolved, and request the missing/controlling evidence. [B1, B3, B6]
2. Confirm liquidity need: verify USD70,000 needed within 6 months and current USD40,000 available; discuss the USD30,000 shortfall as a planning fact, not an investment instruction. [B4]
3. Review risk dimensions separately: B-A's 20% stated willingness, provisional USD60,000 loss capacity, 24-month horizon, no private-credit experience and no-leverage constraint. [B4, B6]
4. Review goals and priority: decide how to handle GP-1 because USD50,000 is assigned while only USD40,000 is available after reserve. [B5]
5. Agree next evidence owners and timing: legacy value resolution, pension statement/allocation, updated capacity assessment and revised goal-pool allocation. [B3, B5, B6]
