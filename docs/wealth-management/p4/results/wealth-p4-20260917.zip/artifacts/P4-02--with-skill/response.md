Prepared the internal HH-BIRCH draft here: [hh_birch_internal_review.md](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-9xhsbtq4/work/drafts/hh_birch_internal_review.md).

I also created and validated the local structured artifacts in `drafts/` for routing, reconciliation, risk, and planning. All substantive artifacts correctly remain `needs-data`.

Key outputs:
- Partial household-share net worth: `USD640,000`, based on included assets `USD840,000` less liabilities `USD200,000`; not complete because LEGACY-ACCOUNT and HELD-AWAY-PENSION are unresolved.
- Risk review: no rating assigned; flags willingness/capacity conflict, liquidity shortfall, lockup/horizon issue, scenario-loss/capacity issue, and no private-credit experience.
- Planning: monthly cash flow is positive under supplied figures, but GP-1 is overallocated by `USD10,000`, so simultaneous goal projections are blocked.

Validated outputs with the local skill validators. Python emitted sandbox temp-cache warnings, but all validation commands returned success.