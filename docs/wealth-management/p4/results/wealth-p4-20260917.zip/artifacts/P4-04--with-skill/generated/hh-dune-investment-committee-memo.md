# HH-DUNE Internal Investment-Committee Memo

Review date: 2026-09-17  
Audience: US advisory investment committee  
Status: Draft for human review; no proposal selected; no client delivery, trade, approval, or system change.

All people, firms, and records in the packet are synthetic. This memo uses only `source_packet.json` and local deterministic calculations from the supplied skill packages.

## Executive View

The supplied model sizing for a USD500,000 candidate produces EQ USD300,000, BD USD150,000, and cash USD50,000. The local construction calculator verified that the resulting equity, bond, and cash weights are within the supplied mandate bands and that there are no unallocated sleeves. [D1]

ALPHA and BETA were compared under the supplied CP-DUNE policy, not on expected returns. ALPHA has lower modeled ongoing cost under the complete supplied components, while BETA has lower advisory fee alone but higher modeled ongoing and first-year cost once fund expense and custody are included. BETA also triggers supplied-policy review items for issuer concentration, sector concentration, 30-day liquidity, proprietary status, cheaper-share-class availability, and missing revenue-sharing evidence. [D2][D3][D4][D6]

The recommendation evidence file is not ready to clear. The validated evidence artifact remains `needs-data` because advisor rationale is incomplete, trading-series review is missing, required disclosure delivery is recorded after the review date, conflict treatment/revenue-sharing evidence is incomplete, and supervision routing is not an approval. [D5][D6]

## Source Assertions vs Verified Arithmetic

Source assertions used:

- D1 asserts the mandate/model record: USD500,000 sizing amount; proportional-within-model-sleeve method; model M-D1 v3 with EQ 60%, BD 30%, cash 10%; EQ/BD eligible and individually capped at 70%; mandate max position 70%; cash 5-20%; equity 50-70%; bonds 20-40%; no supplied restricted security IDs. D1 also says the approval evidence is attributed selection/approval evidence, not authentication. [D1]
- D2 asserts ALPHA proposal data: USD500,000; EQ 60%, BD 30%, cash 10%; EQ expense 20 bps, BD 10 bps, cash 0 bps; advisory 50 bps; custody/other 0 bps; one-time transaction cost USD200; two-day EQ/BD liquidity; all conflict flags false. [D2]
- D3 asserts BETA proposal data: USD500,000; FUND-Z 80%, cash 20%; FUND-Z expense 40 bps; advisory 40 bps; custody 5 bps; one-time cost 0; FUND-Z liquidity 90 days; FUND-Z issuer look-through A 75% and C 25%; FUND-Z proprietary; revenue-sharing not supplied; cheaper share class documented available. [D3]
- D4 supplies comparison limits: issuer maximum 40%, sector maximum 70%, illiquid maximum 20% using a 30-day horizon, and annual modeled-cost limit 80 bps; same USD500,000 scope; one-time cost separate from ongoing expenses. [D4]
- D5/D6 assert recommendation evidence status and applicability: contemplated action is a nonretirement strategy switch under a US advisory fiduciary profile; advisor rationale is incomplete; trading-series review has not been received; revenue-sharing evidence for BETA FUND-Z is unresolved; Patel routing is not approval; LIB-ADV v6 delivery is required before review, with delivery recorded September 18 rather than as delivered by September 17. [D5][D6]

Locally verified from supplied inputs:

- Model sizing: EQ 60% = USD300,000; BD 30% = USD150,000; cash 10% = USD50,000. Equity, bond, and cash weights meet the supplied bands; EQ and BD are below the 70% position cap. Artifact: `portfolio-construction-assistant-9cabc57f4486f51a10cb`; validated with zero output errors. [D1]
- ALPHA modeled costs: weighted fund expense 15 bps; ongoing modeled cost 65 bps, or USD3,250; first-year modeled cost USD3,450 including USD200 one-time transaction cost. [D2][D4]
- BETA modeled costs: weighted fund expense 32 bps; ongoing modeled cost 77 bps, or USD3,850; first-year modeled cost USD3,850. BETA minus ALPHA is +12 bps ongoing and +USD400 first-year under the supplied component scope. Artifact: `portfolio-proposal-comparator-7d56f5aaa08b0d8e3341`; validated with zero output errors. [D2][D3][D4]
- ALPHA look-through: maximum issuer exposure 30%; technology sector 60%; known illiquid weight 0%, all within supplied comparison limits. [D2][D4]
- BETA look-through: issuer A exposure 60% versus 40% supplied maximum; technology sector exposure 80% versus 70% supplied maximum; known illiquid weight 80% versus 20% supplied maximum using the 30-day horizon. [D3][D4]

## Proposal Comparison

| Item | ALPHA | BETA | Draft read-through |
| --- | ---: | ---: | --- |
| Portfolio scope | USD500,000 | USD500,000 | Same comparison base. [D2][D3][D4] |
| Allocation | EQ 60%, BD 30%, cash 10% | FUND-Z 80%, cash 20% | BETA is concentrated through FUND-Z look-through. [D2][D3] |
| Weighted fund expense | 15 bps | 32 bps | Complete under supplied holding expense fields. [D2][D3] |
| Advisory/custody/other | 50/0/0 bps | 40/5/0 bps | BETA advisory fee is lower, but custody and fund expense change total cost. [D2][D3] |
| Ongoing modeled cost | 65 bps / USD3,250 | 77 bps / USD3,850 | Both are below the 80 bps supplied limit; BETA is +12 bps. [D2][D3][D4] |
| First-year modeled cost | USD3,450 | USD3,850 | BETA is +USD400 after ALPHA's USD200 one-time cost. [D2][D3][D4] |
| Max issuer exposure | 30% | 60% | BETA exceeds the 40% supplied issuer maximum. [D2][D3][D4] |
| Max sector exposure | 60% technology | 80% technology | BETA exceeds the 70% supplied sector maximum. [D2][D3][D4] |
| Illiquid weight, 30-day horizon | 0% | 80% | BETA exceeds the 20% supplied illiquid maximum. [D2][D3][D4] |
| Conflicts | Supplied flags false | Proprietary; cheaper share class available; revenue-sharing unknown | BETA needs conflict treatment and missing revenue-sharing evidence. [D2][D3][D5][D6] |

No return forecast, tax estimate, suitability conclusion, or recommended winner is provided.

## Evidence Questions Before Any Switch

| Question / missing evidence | Why it matters | Next owner |
| --- | --- | --- |
| Complete advisor rationale for the contemplated switch, including why the selected proposal, if any, is preferred over available alternatives. | D5 says alternatives inventory includes ALPHA/BETA but advisor rationale is incomplete. | Advisor Chen; review by Patel. [D5][D6] |
| Resolve BETA revenue-sharing status for FUND-Z. | D3 leaves revenue-sharing unsupplied; D6 records the issue as unresolved and says to retain it. | Proposal desk / conflicts owner; Patel to confirm resolution evidence. [D3][D6] |
| Document conflict treatment for proprietary FUND-Z and cheaper-share-class availability. | D5 says the conflict inventory records these facts but lacks treatment and revenue-sharing information. | Advisor Chen with conflicts/compliance review. [D3][D5] |
| Address BETA issuer, sector, and liquidity limit breaches if BETA remains under consideration. | Local comparison shows BETA exceeds supplied issuer, sector, and illiquid limits. | Advisor Chen to provide rationale or revised proposal; Patel/committee to review. [D3][D4] |
| Obtain trading-series review. | D5 says it has not been received. | Advisor Chen / supervision route Patel. [D5] |
| Evidence timely LIB-ADV v6 delivery before the September 17 review, or document remediation. | D5 says required delivery is recorded September 18 and no evidence is dated as delivered today. | Advisor Chen / client-service evidence owner; Patel to review. [D5] |
| Confirm required supervisory review after proposal selection. | D5 says Patel routing is not an approval; D6 says not to label the recommendation cleared merely because records exist. | Patel / applicable supervision process. [D5][D6] |

## Draft Committee Framing

The committee can use the supplied comparison to discuss tradeoffs, but the record does not support selecting or clearing either proposal today. ALPHA currently has lower modeled total cost and no comparison-limit breaches under the supplied inputs. BETA has lower advisory fee alone, but higher modeled total cost, higher first-year cost, and unresolved concentration, liquidity, and conflict questions. [D2][D3][D4][D6]

If the committee continues to evaluate BETA, the open evidence should be resolved before a client recommendation is finalized. If the committee prefers ALPHA or requests a revised candidate, the advisor still needs a complete rationale, trading-series review, timely disclosure evidence, and applicable supervisory review. [D5][D6]

## Local Artifacts

- Construction request/output: `construction_request.json`, `construction_artifact.json`
- Comparison request/output: `comparison_request.json`, `comparison_artifact.json`
- Recommendation evidence request/output: `recommendation_request.json`, `recommendation_artifact.json`
- Recommendation evidence artifact status: `needs-data`; counts are 2 documented, 7 incomplete, 0 missing, 2 not applicable.
