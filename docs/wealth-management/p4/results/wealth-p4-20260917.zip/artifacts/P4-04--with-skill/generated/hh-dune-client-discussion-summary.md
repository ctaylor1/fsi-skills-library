# HH-DUNE Client-Discussion Summary

Draft for advisor review. Do not deliver until approved through the applicable firm process.

We reviewed two proposal drafts for the same USD500,000 scope using the firm-supplied comparison policy. The committee has not selected a proposal. The review compared costs, look-through exposures, liquidity, and conflict information from the supplied records; it did not predict returns or make a recommendation. [D2][D3][D4]

Key discussion points:

- The model-sized candidate from the supplied mandate is 60% EQ, 30% BD, and 10% cash, equal to USD300,000 EQ, USD150,000 BD, and USD50,000 cash. This fits the supplied equity, bond, cash, and position limits. [D1]
- ALPHA's modeled ongoing cost is 65 bps, or USD3,250 per year on USD500,000, plus a USD200 one-time transaction cost for a first-year modeled cost of USD3,450. [D2][D4]
- BETA's modeled ongoing cost is 77 bps, or USD3,850 per year on USD500,000, with no one-time transaction cost supplied. Although BETA's advisory fee is lower, the supplied total modeled cost is higher than ALPHA by 12 bps ongoing and USD400 in the first year. [D2][D3][D4]
- BETA has unresolved review questions: issuer concentration, technology-sector concentration, 90-day liquidity for FUND-Z versus a 30-day policy horizon, proprietary FUND-Z status, cheaper-share-class availability, and missing revenue-sharing evidence. [D3][D4][D6]
- Several file items must be completed before any final recommendation: advisor rationale, conflict treatment, trading-series review, timely disclosure evidence, and supervisory review. [D5][D6]

Suggested client-safe positioning after internal approval: "We are still reviewing the alternatives. The current comparison shows different cost, liquidity, concentration, and conflict considerations, and we will not treat the review as complete until the open evidence questions are resolved."
