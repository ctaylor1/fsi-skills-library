# HH-JADE Liquidity-Options Memo Draft

Audience: advisory review team. Review date: 2026-09-17. Draft for human review only. This memo compares known alternatives from the packet and does not allocate a funding strategy, approve borrowing, execute liquidation, schedule meetings, or contact anyone.

## Evidence Boundary

Packet assertion: HH-JADE requested a liquidity-options review on September 17, due September 18, with 30 minutes of internal effort. [K3]

Packet assertion: HH-JADE has a USD 30,000 home-repair payment needed September 25, 2026; it is not a securities purchase. Current unencumbered cash is USD 20,000 and protected reserve is USD 10,000. [K5]

Local arithmetic: if the protected reserve is preserved, unencumbered cash is USD 10,000 short of the USD 30,000 request. The packet does not state whether the protected reserve may be used, and this draft does not assume it can be used.

Packet assertion: no upstream issue artifact has been supplied. [K5]

## Alternatives Known From Supplied Records

| Alternative | Timing vs Sep. 25 need | Cash / proceeds | 12-month service view | Key constraints and uncertainties |
|---|---|---:|---|---|
| Use current unencumbered cash only | Available now per packet | 20,000 | No debt service supplied | Short by 10,000 if protected reserve is preserved. [K5] |
| Liquidation illustration | Available September 26 | 30,300 net after 200 fees and 1,500 tax reserve | No facility service | Net proceeds exceed request by 300, but availability is one day after stated need. Tax reserve is externally supplied; no realized sale is evidenced. [K5] |
| Unsecured U-J | Funding September 24 | 29,700 net if 300 upfront fee is withheld from 30,000 draw | 1,000/month for 30 months at 0%; first 12 months total 12,000 scheduled principal, 18,000 principal remaining | Net proceeds appear 300 short of the 30,000 payment if fee is withheld from proceeds. Monthly service exactly equals the stated 1,000 debt budget before any non-supplied items. No source authenticates approval or permits drawing. [K5], [K6] |
| SBLOC S-J | Funding September 28 | 30,000 draw; existing balance 10,000; total balance after draw 40,000 | Current-rate service: 210/month including existing balance and monthly fee. Stress-rate service: 310/month. | Funding is after the September 25 need. Current collateral capacity calculates to 48,000 against 40,000 post-draw balance, but conservative stressed collateral capacity calculates to 27,500, below the 40,000 balance. Facility is on-demand with ongoing maintenance; no current source authenticates approval or permits drawing. [K5], [K6] |

## Calculation Notes

Liquidation: gross 32,000 - fees 200 - tax reserve 1,500 = 30,300 net available September 26. [K5]

Unsecured U-J: draw 30,000 - 300 upfront fee withheld = 29,700 net proceeds. At 0% over 30 months, straight-line monthly principal is 1,000. The packet does not state another source for the withheld 300. [K6]

SBLOC S-J: eligible collateral value 100,000 with 20,000 reserved elsewhere leaves 80,000 unreserved; at a 60% advance rate, current collateral capacity calculates to 48,000. Existing 10,000 plus proposed 30,000 draw equals 40,000. [K6]

SBLOC stress: rate rises from 6% to 9%; price stress reduces collateral from 100,000 to 75,000; advance rate falls from 60% to 50%. Treating the 20,000 reserved amount as fixed, stressed capacity is (75,000 - 20,000) * 50% = 27,500. If the reserved amount fell proportionally with the price stress, stressed capacity would be 30,000; either way it is below the 40,000 post-draw balance. [K6]

## Missing Evidence and Next Owners

Missing evidence:
- No authenticated loan approval or permitted draw exists for either loan alternative. [K6]
- No record states whether the protected reserve may be used. [K5]
- No source explains how HH-JADE would bridge timing gaps for liquidation or SBLOC funding after September 25. [K5], [K6]
- No source supplies final tax advice, actual sale execution, or realized liquidation tax outcome. [K5]
- No source supplies maturity takeout or refinance funding for the SBLOC; separately available maturity funding is stated as 0. [K6]
- No source supplies a household balance sheet, income verification, risk tolerance, collateral concentration analysis, or legal/credit approval.

Next owners for human review:
- Uma: confirm the household objective, reserve constraint, and whether any missing evidence should be requested internally before a recommendation is considered. [K5]
- Wren or lending owner: confirm approval status, permitted draw status, exact cash delivered after fees, and facility maintenance implications. [K6]
- Tax or portfolio owner, if applicable: verify liquidation tax reserve and sale timing before any liquidation recommendation is made. [K5]
