# Internal Book Work Plan Draft for Advisory Team

Review date: 2026-09-17. Draft for human review. This draft uses only `source_packet.json`; packet statements are treated as source assertions, while arithmetic and date roll-forwards are local calculations from those assertions.

## Scope and Evidence Boundary

Packet assertion: BOOK-KITE is the US advisory book scope for the September 1-17 economic period and current book; HH-JADE, HH-KELP, and HH-LARCH are active, while HH-MOSS departed September 10. All listed households are owner O-UMA, tier CORE, standard/service-model segment. [K1]

Packet assertion: The planning window is September 17-18 inclusive, CORE reviews recur every 100 calendar days, initial reviews are due 30 days after joining, reviews take 60 incremental minutes, evidence gaps take 15 minutes, and ranking is policy-based rather than revenue- or asset-based. [K2]

Packet assertion: O-UMA has 120 working minutes and 60 unrelated committed minutes on each of September 17 and 18; availability is complete and overlap reviewed. [K2]

Local calculation assumption: unrelated committed minutes consume working minutes. On that basis, net capacity for queued service work is 60 minutes per day, or 120 minutes across the two-day window. If that assumption is wrong, the capacity conclusion should be rechecked by Uma or the capacity owner.

## Active Service Queue

| Queue item | Basis | Policy rank | Incremental effort | Timing status | Source / calculation |
|---|---:|---:|---:|---|---|
| HH-KELP overdue CORE review | Last review June 8; +100 days = September 16 | 1 | 60 min | Overdue as of September 17 | [K1], [K2], local date calculation |
| HH-JADE liquidity-options review | Client request due September 18 | 2 | 30 min | Due in planning window | [K3] |
| HH-JADE CORE review | Last review June 9; +100 days = September 17 | 3 | 60 min | Due September 17, not treated as overdue in this draft | [K1], [K2], local date calculation |
| HH-KELP new-service discussion | Confirmed client interest; client-requested growth work does not replace overdue review | 9 | 15 min | Due September 18 | [K2], [K3] |

Excluded or outside-window items:
- HH-LARCH has no prior review, but its initial review date calculates to October 5, 2026, which is outside the September 17-18 window. [K1], [K2]
- HH-MOSS would calculate as review-due September 9 from the last review date, but it departed September 10 and is not included in the current active service queue. [K1], [K2]
- No additional signals are supplied. [K3]

## Capacity Finding

Active queued service work totals 165 minutes: 60 for HH-KELP overdue review, 30 for HH-JADE liquidity-options request, 60 for HH-JADE review due, and 15 for HH-KELP client-requested growth discussion. [K2], [K3]

Net supplied capacity totals 120 minutes under the stated calculation assumption: (120 working minutes - 60 unrelated committed minutes) * 2 days. [K2]

Finding: supplied net capacity does not cover the queued service work. The visible shortfall is 45 minutes. This is a capacity finding only; it is not a meeting schedule and does not allocate any client funding strategy.

## Economics Kept Separate From Priority

Packet assertion: the economic bridge is complete for September 1-17, 2026, in USD; fees debited reconcile assets, revenue is separate accounting evidence, and no fully allocated profitability model is supplied. [K4]

Local arithmetic from the bridge:

| Household | Revenue | Direct cost | Contribution before unallocated costs | Closing assets |
|---|---:|---:|---:|---:|
| HH-JADE | 1,000 | 600 | 400 | 117,000 |
| HH-KELP | 2,000 | 1,000 | 1,000 | 183,000 |
| HH-LARCH | 0 | 100 | -100 | 50,000 |
| HH-MOSS | 0 | 200 | -200 | 0 |
| Total | 3,000 | 1,900 | 1,100 | 350,000 |

The service priority queue above is not based on revenue, closing assets, or contribution. The applicable source says ranking comes from service policy, not revenue or assets. [K2] Economics are included here only for internal book context and should not be used to override the policy queue.

## Missing Evidence and Next Owners

Missing evidence:
- No evidence-gap artifact is supplied for any current household; no additional client signals are supplied. [K3]
- No record clarifies whether the 60 unrelated committed minutes are already netted from, or consume, the 120 working minutes. This draft treats them as consuming the working minutes.
- No fully allocated profitability model is supplied, so only direct-cost contribution can be shown. [K4]

Next owners for human review:
- Uma: confirm the capacity interpretation, validate the active queue, and decide any internal triage if the 45-minute shortfall remains.
- Advisory leadership or service manager: decide whether additional owner capacity is needed for the September 17-18 window.
- Controller Vic: provide any fully allocated profitability model if the team needs economics beyond direct contribution. [K4]
