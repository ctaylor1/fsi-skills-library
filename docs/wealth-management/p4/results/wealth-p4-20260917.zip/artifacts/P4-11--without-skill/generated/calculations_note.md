# Local Calculation Note

Review date: 2026-09-17. Inputs are solely from `source_packet.json`; calculations below verify arithmetic derived from cited packet assertions, not independent real-world facts.

## Service queue and capacity

Source assertions:
- BOOK-KITE active/current households are HH-JADE, HH-KELP, and HH-LARCH; HH-MOSS departed September 10, 2026. All are owner O-UMA, tier CORE. Last completed reviews: JADE June 9, 2026; KELP June 8, 2026; MOSS June 1, 2026; LARCH has no prior review. [K1]
- CORE reviews recur every 100 calendar days; initial review is 30 days after joining; each review is 60 incremental minutes. Planning window is September 17-18, 2026. O-UMA has 120 working minutes and 60 unrelated committed minutes on each day. [K2]
- JADE liquidity-options review is due September 18 and takes 30 incremental minutes. KELP new-service discussion is due September 18 and takes 15 incremental minutes; this growth work does not replace the overdue review. [K3]

Local date calculations:
- JADE: June 9 + 100 calendar days = September 17, 2026.
- KELP: June 8 + 100 calendar days = September 16, 2026.
- MOSS: June 1 + 100 calendar days = September 9, 2026; excluded from current active queue because the household departed September 10. [K1]
- LARCH: September 5 + 30 calendar days = October 5, 2026; outside the September 17-18 planning window.

Capacity calculation:
- Assumption for local calculation: unrelated committed minutes consume the supplied working minutes.
- Net service capacity = (120 - 60) minutes/day * 2 days = 120 minutes.
- Active queued service work in window = KELP overdue review 60 + JADE review due 60 + JADE liquidity-options request 30 + KELP client-requested growth discussion 15 = 165 minutes.
- Result: net service capacity does not cover the active queued service work; shortfall is 45 minutes. If the unrelated committed minutes were not meant to consume working minutes, gross capacity would be 240 minutes, but that reading is not used for the main draft.

## Book economics

Source assertion: the supplied economic bridge covers September 1-17, 2026, in USD, with revenue separate from fee debits and no fully allocated profitability model supplied. [K4]

Local arithmetic:
- JADE contribution before unallocated costs = revenue 1,000 - direct cost 600 = 400.
- KELP contribution before unallocated costs = 2,000 - 1,000 = 1,000.
- LARCH contribution before unallocated costs = 0 - 100 = -100.
- MOSS contribution before unallocated costs = 0 - 200 = -200.
- Total revenue = 3,000; total direct cost = 1,900; contribution before unallocated costs = 1,100.
- Total closing assets reconcile: opening 380,000 + inflows 70,000 - outflows 95,000 + market -2,000 - fees 3,000 = closing 350,000.

## HH-JADE liquidity alternatives

Source assertions:
- HH-JADE needs a USD 30,000 home-repair payment on September 25, 2026; current unencumbered cash is 20,000 and protected reserve is 10,000. [K5]
- Liquidation illustration: gross 32,000, fees 200, tax reserve 1,500, available September 26; no realized sale. [K5]
- Unsecured U-J: draw 30,000; existing 0; limit 30,000; upfront fee 300 withheld; fixed nominal rate 0%; amortizing 30 months; funding September 24; no collateral; no current source authenticates approval or permits drawing. [K6]
- SBLOC S-J: draw 30,000; existing 10,000; limit 60,000; monthly fee 10; floating nominal 6%; interest-only 24 months; funding September 28; on-demand; ongoing maintenance; eligible collateral SEC-J value 100,000 with 20,000 reserved elsewhere; advance rate 60%; stress applies +300 bps rate, -25% collateral price, -10 percentage points advance; no current source authenticates approval or permits drawing. [K6]

Local arithmetic:
- Unencumbered cash shortfall if protected reserve is preserved = 30,000 - 20,000 = 10,000.
- Liquidation net available = 32,000 - 200 - 1,500 = 30,300; timing is one day after the September 25 need.
- Unsecured U-J net cash if fee is withheld from proceeds = 30,000 - 300 = 29,700; 30-month straight-line principal service at 0% = 1,000/month; over 12 months, scheduled payments total 12,000 with 18,000 principal remaining, before any non-supplied terms.
- SBLOC current capacity from unreserved collateral = (100,000 - 20,000) * 60% = 48,000. Balance after proposed draw = 10,000 existing + 30,000 draw = 40,000.
- SBLOC current monthly service, including existing balance, = 40,000 * 6% / 12 + 10 = 210/month.
- SBLOC stress monthly service = 40,000 * 9% / 12 + 10 = 310/month.
- SBLOC conservative stressed collateral capacity, treating the reserved amount as a fixed dollar reservation, = (100,000 * 75% - 20,000) * 50% = 27,500, below the 40,000 balance after proposed draw. If the reservation also fell proportionally with price, stressed capacity would be 30,000, still below the 40,000 balance.
