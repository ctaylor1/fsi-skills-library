Drafts are ready for human review:

- [Internal book work plan draft](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-mtwqrlhr/work/internal_book_work_plan_draft.md)
- [HH-JADE liquidity-options memo draft](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-mtwqrlhr/work/hh_jade_liquidity_options_memo_draft.md)
- [Calculation note](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-mtwqrlhr/work/calculations_note.md)

Key findings: O-UMA’s net supplied capacity covers 120 minutes against 165 minutes of active queued service work, leaving a 45-minute shortfall under the stated capacity assumption. Book economics are shown separately and not used for service priority. For HH-JADE, the memo compares known alternatives without choosing a strategy: cash is short if reserve is preserved, liquidation is net sufficient but late, unsecured funding appears timely but net short after withheld fee, and SBLOC funding is late with stress collateral concerns.

I used only the local packet, cited source IDs throughout, preserved unknowns, and did not contact anyone, schedule meetings, allocate funding, or change any external system.