# HH-JUNIPER Investor-Side Manager Diligence and Private-Market Funding Review

Review as of: 2026-09-17  
Audience: advisor / manager-review owner / administrator  
Status: draft for human review; no action taken; not delivered  
Scope limit: investor-side diligence and client funding review only. This is not a manager DDQ response, subscription approval, eligibility decision, recommendation, transfer authorization, or capital-call payment instruction.

## Source And Calculation Posture

All source records are synthetic and packet-supplied. I treated packet text as source assertions, not independently authenticated fact. Calculated items below are local arithmetic from cited source assertions, not verification of the underlying documents.

Local manager artifact generated from J1-J3: `investment-manager-due-diligence-reviewer-b5a9a631586dccb38125`; input hash `b5a9a631586dccb381256fc8906cabc1d4ad18003ee49ae1b5fb40cbc0dceebb`; status `needs-data`. The output validated with 0 reconstruction errors.

Private-market schema note: J4-J6 support useful arithmetic, but the packet does not provide original inception date and original historical notice/movement dates for the cumulative settled call and distribution inventories. I therefore did not invent those fields to force the strict private-market validator. [J4, J6]

## Manager Diligence Memo

Supplied policy context: HH-JUNIPER is a US advisory household, USD scope, reviewing manager M-J / strategy S-J under supplied policy DD-J v3. Required criteria are leverage maximum 1.0, independent annual assurance report, ongoing base-cost maximum 150 bps, liquidity days maximum 60, evidence observed-age maximum 90 days, with a 30-day monitoring interval. [J1]

| Dimension | Packet assertion / local comparison | Draft assessment |
| --- | --- | --- |
| Investment | Manager-reported leverage is 0.7 observed 2026-09-10; supplied maximum is 1.0. [J1, J2] | Meets supplied numeric criterion, but the leverage value is manager-reported, not independently verified. |
| Operations | Manager response says independent annual assurance report is not available; no independent report supplied. The policy requires independent evidence. [J1, J2] | Not evaluable / needs data. Imported unresolved issue: `independent-assurance-missing`. |
| Fees | Firm-record ongoing base fees are 125 bps; supplied maximum is 150 bps. [J1, J2] | Meets supplied numeric criterion for the stated base-cost field. Confirm scope of “ongoing base fees” before relying on all-in economics. |
| Liquidity | Manager-reported liquidity is 90 days; supplied maximum is 60 days, with gates or suspension possible. [J1, J2] | Criterion concern. Liquidity does not meet the supplied days threshold and availability is contingent. |
| Evidence | Firm evidence inventory observed-age is 30 days, reviewed 2026-09-17; supplied maximum is 90 days. [J1, J2] | Meets supplied observed-age criterion, subject to human review of source truth and completeness. |

Fee illustration: using the supplied one-period, no-high-water-mark scenario on USD 200,000 with 100 bps management, 25 bps other, 10% gross return, 4% hurdle, and 20% incentive rate, local calculation gives base fee $2,500.00, incentive base $9,500.00, incentive fee $1,900.00, total illustrated fee $4,400.00, and illustrated net gain $15,600.00. This is only the supplied scenario, not a quote, forecast, tax analysis, or actual contractual waterfall. [J3]

Manager liquidity scenario: the supplied amount under review is $55,000, notice deadline 2026-09-10, request scenario 2026-09-17, expected settlement 2026-12-15, household need $55,000 on 2026-10-01, and gates may delay access. The request date is after the supplied notice deadline, and expected settlement is after the household need date, so the scenario is not usable as assured funding for the 2026-10-01 need. [J3]

Monitoring: using the supplied 30-day interval, the next review agenda date is 2026-10-17. [J1]

## Private-Market Commitment And Liquidity Review

Supplied account/fund facts: Account PM-J has current settled cash of $40,000 and protected reserve of $10,000. Fund F-J has an operative commitment of $300,000, complete cumulative settled inside-commitment call effects of $120,000, and complete settled recallable distribution effects of $10,000. Unpaid CALL-J1 is $50,000, all inside commitment, due 2026-10-01. Unpaid FEE-J1 is $5,000, outside commitment, due 2026-10-02. Administrator reports uncalled $140,000 and call/fee cash payable $55,000. [J4, J5]

Local commitment roll-forward from supplied mapped amounts:

| Item | Amount | Basis |
| --- | ---: | --- |
| Operative commitment | $300,000.00 | Supplied administrator ledger. [J4] |
| Less settled inside-commitment calls | ($120,000.00) | Supplied cumulative inventory. [J4] |
| Plus settled recallable distributions | $10,000.00 | Supplied cumulative inventory. [J4] |
| Remaining commitment including unpaid inside calls | $190,000.00 | Local calculation from J4. |
| Reserved by unpaid inside-commitment CALL-J1 | $50,000.00 | CALL-J1 supplied as unpaid and all inside commitment. [J4] |
| Uncalled commitment | $140,000.00 | Local calculation; reconciles to administrator reported uncalled. [J4] |
| Total unpaid call/fee cash payable | $55,000.00 | CALL-J1 $50,000 + FEE-J1 $5,000; reconciles to administrator reported payable. [J4] |
| Uncalled plus unpaid call/fee cash payable | $195,000.00 | Local calculation; do not add unpaid inside call again to remaining commitment. |

Funding schedule for PM-J through supplied horizon 2026-11-30:

| Date | Event | Known-obligation balance | Forecast-scenario balance | Source / note |
| --- | --- | ---: | ---: | --- |
| 2026-09-17 | Opening settled cash less protected reserve: $40,000 - $10,000 | $30,000.00 | $30,000.00 | Current cash already reflects historical settled activity. [J5] |
| 2026-09-25 | DIST-J1 expected $20,000 distribution | $30,000.00 | $30,000.00 | Unsettled and not received; no spending credit. [J5] |
| 2026-10-01 | CALL-J1 unpaid inside-commitment call | ($20,000.00) | ($20,000.00) | Account shortfall before any transfer authority. [J4, J5] |
| 2026-10-02 | FEE-J1 unpaid outside-commitment fee | ($25,000.00) | ($25,000.00) | Separate outside-commitment payable. [J4] |
| 2026-11-01 | Active incremental call forecast | ($25,000.00) | ($55,000.00) | Forecast is incremental and does not replace CALL-J1. [J5] |

Account-specific liquidity conclusion for advisor review: PM-J cannot meet the known October 1 and October 2 cash obligations from current settled cash while preserving the protected reserve. The first known shortfall is $20,000 on 2026-10-01; it grows to $25,000 after FEE-J1 and to $55,000 in the incremental forecast scenario. No other accounts may fund PM-J without separately reviewed transfer authority. [J4, J5]

NAV and eligibility: Fund F-J reported NAV is $210,000 as of 2026-06-30. At the 2026-09-17 review date, the NAV is 79 days old, exceeding the supplied 60-day maximum; no refreshed valuation is supplied, and later cash movements are not an approved current-NAV roll-forward. Eligibility review is pending with counsel despite a manager checkbox saying “eligible”; required documents are offering memorandum and subscription record, and only the memorandum has been received. Eligibility is not determined. [J6]

Manager evidence connected to funding: the account-level funding issue exists even before considering the manager liquidity concern. Separately, the manager review has unresolved independent assurance evidence and a liquidity criterion concern. The manager scenario also cannot supply the 2026-10-01 household need because the supplied request date misses the notice deadline and expected settlement is 2026-12-15. [J2, J3, J4, J5, J6]

## Missing Evidence And Next Owners

| Gap / issue | Why it matters | Next owner |
| --- | --- | --- |
| Independent annual assurance report unavailable. [J2] | Required operations criterion cannot be independently supported. | Manager-review owner Reese; manager diligence owner. |
| Manager liquidity 90 days vs 60-day policy; gates possible. [J1, J2] | Liquidity criterion concern and funding cannot be assumed. | Manager-review owner Reese. |
| Liquidity scenario request after 2026-09-10 notice deadline and settlement after 2026-10-01 need. [J3] | Scenario does not solve near-term household liquidity need. | Manager-review owner Reese; advisor. |
| Original inception date and detailed historical notice/movement dates not supplied in packet. [J4] | Prevents strict private-market ledger validator from reconstructing full since-inception lifecycle. | Administrator Taylor / fund administrator. |
| PM-J account cash shortfall by 2026-10-01 before any transfer authority. [J4, J5] | Advisor needs funding plan review; this draft does not authorize transfers. | Advisor; client operations; administrator. |
| NAV stale under supplied 60-day policy. [J6] | No current NAV under supplied review rule; do not infer updated value from cash flows. | Operations Taylor / administrator. |
| Eligibility review pending; subscription record missing; manager checkbox not sufficient. [J6] | Eligibility not determined and no subscription/eligibility decision can be made from this packet. | Counsel / legal eligibility reviewer; administrator. |
| Manager diligence artifact DD-M-J-3 is referenced, but the packet does not supply its input hash. [J6] | Handoff integrity should be confirmed before downstream reliance. | Manager-review owner Reese; operations Taylor. |

## Questions For Manager-Review Owner

1. Can the owner obtain or confirm absence of an independent annual assurance report, and identify whether any alternative independent operational-control evidence is acceptable under DD-J v3? [J1, J2]
2. Does the 125 bps firm-record base fee represent the full “ongoing base-cost” criterion scope, or are additional manager/fund/admin expenses outside that field? [J1, J2]
3. Is the 90-day manager-reported liquidity term the governing investor liquidity term for this household/fund/account, and what documents support any gates or suspension conditions? [J2]
4. Should the missed 2026-09-10 notice deadline / 2026-12-15 expected settlement scenario be removed from funding assumptions for the 2026-10-01 need? [J3]
5. Please confirm the authoritative manager diligence artifact ID, input hash, review date, and unresolved issue list for DD-M-J-3. [J2, J6]

## Questions For Administrator / Operations

1. Provide the original since-inception notice and settlement ledger for F-J, including inception date, notice IDs/dates, settlement dates, cash amounts, and commitment-effect allocations supporting the $120,000 settled inside-call and $10,000 recallable-distribution totals. [J4]
2. Confirm CALL-J1 is entirely inside commitment and FEE-J1 is entirely outside commitment, with no netting, offsets, or pending settlements after the 2026-09-17 cash snapshot. [J4, J5]
3. Confirm whether DIST-J1 has settled after the packet date; if still unsettled, confirm it remains unavailable for funding. [J5]
4. Provide a refreshed NAV or confirm when the next administrator valuation will be available; current supplied NAV is 79 days old against a 60-day policy threshold. [J6]
5. Confirm protected reserve restrictions and whether any separately reviewed transfer authority exists for PM-J; none is assumed in this draft. [J5]
6. Provide counsel’s eligibility review status and the missing subscription record; do not rely on the manager checkbox as an eligibility determination. [J6]

## Draft Handoff

For advisor review, the immediate account-specific issue is PM-J’s October funding deficit: $30,000 cash after reserve versus $55,000 known call/fee payable by 2026-10-02. The manager diligence issue is separate but relevant: independent operational assurance is missing, liquidity exceeds the supplied threshold, and the supplied manager liquidity scenario does not meet the household’s 2026-10-01 need. Human review is required before any client communication, recommendation, eligibility conclusion, transfer, or payment. [J2, J3, J4, J5]
