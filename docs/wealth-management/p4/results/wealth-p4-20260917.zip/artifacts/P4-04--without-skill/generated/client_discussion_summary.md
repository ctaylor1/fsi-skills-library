# HH-DUNE Client-Discussion Summary

Draft for advisor use after review. Review date: 2026-09-17. This summary is based only on the supplied internal packet and should not be read as a final recommendation or approval.

## Current Status

The committee has not selected a proposal. The current work compares two proposals, ALPHA and BETA, for a contemplated nonretirement strategy switch. The packet states that investment profile and risk/objective/liquidity alignment notes were received, but the advisor rationale is incomplete and several evidence items remain open [D5].

## Model Sizing Illustration

The supplied model uses a USD 500,000 sizing amount with EQ 60%, BD 30%, and cash 10% [D1]. On that basis, the model-sized candidate would be:

| Sleeve | Amount |
|---|---:|
| EQ | USD 300,000 |
| BD | USD 150,000 |
| Cash | USD 50,000 |
| Total | USD 500,000 |

The packet says this model evidence is attributed selection/approval evidence, not independently authenticated evidence [D1].

## Proposal Comparison For Discussion

ALPHA uses the same allocation as the supplied model: EQ 60%, BD 30%, and cash 10% [D1][D2]. Its derived ongoing modeled cost is 65 bps, or about USD 3,250 per year on USD 500,000, plus a separate one-time transaction cost of USD 200 [D2][D4]. Its look-through issuer, sector, illiquidity, and modeled-cost checks are within the supplied comparison limits [D2][D4].

BETA uses FUND-Z 80% and cash 20% [D3]. Its derived ongoing modeled cost is 77 bps, or about USD 3,850 per year on USD 500,000, with no one-time cost supplied [D3][D4]. The packet says BETA has a lower advisory fee, but the full modeled ongoing cost is higher than ALPHA after product expense and custody fee are included [D2][D3][D4].

BETA raises unresolved review questions. The look-through comparison shows issuer A at 60%, equity/technology exposure at 80%, and 80% in a 90-day-liquidity fund; these exceed the supplied comparison limits for issuer concentration, sector concentration, and illiquidity [D3][D4]. FUND-Z is proprietary, revenue-sharing evidence is missing, and a cheaper share class is documented available [D3][D5][D6].

## Items To Resolve Before Any Recommendation Is Final

The advisor rationale for choosing between ALPHA and BETA is incomplete [D5]. The trading-series review has not been received [D5]. Conflict treatment for proprietary FUND-Z, revenue sharing, and cheaper share class availability is incomplete [D3][D5][D6]. The required LIB-ADV v6 disclosure was required before the September 17 review, but recorded delivery is September 18 and no evidence is dated as already delivered today [D5].

No return forecast is included in this discussion draft. The comparison is limited to the supplied model sizing, costs, liquidity, exposures, conflicts, and evidence gaps in the packet.
