# HH-DUNE Internal Investment-Committee Memo

Draft for human review. Review date: 2026-09-17. All names, firms and records are synthetic. This memo uses only `source_packet.json`; no external verification, client contact, system change, return forecast, or approval action was performed.

## Decision Posture

The committee has not chosen a proposal. The supplied record set supports a candidate sizing illustration, a comparison of ALPHA and BETA, and a list of evidence gaps to resolve before any contemplated nonretirement strategy switch is treated as cleared. The recommendation file itself says the advisor rationale is incomplete, the trading-series review has not been received, and supervision routing to Patel is not an approval [D5]. The upstream cover also says not to label the recommendation cleared merely because records exist [D6].

## Source Versus Verified Fact

Source assertions are statements supplied in the packet and cited by source ID. Verified facts in this draft are limited to arithmetic derived from those source assertions, such as dollar allocations, weighted modeled costs, and look-through concentration percentages. No third-party records, client communications, market data, performance expectations, or operational systems were checked.

## Supplied Model Sizing

The mandate record states a USD 500,000 sizing amount and a proportional-within-model-sleeve method for model M-D1 v3: EQ 60%, BD 30%, and cash 10% [D1]. Based on that supplied method, the candidate sizing is:

| Sleeve | Supplied weight | Derived dollar amount |
|---|---:|---:|
| EQ | 60% | USD 300,000 |
| BD | 30% | USD 150,000 |
| Cash | 10% | USD 50,000 |
| Total | 100% | USD 500,000 |

The mandate record asserts that EQ and BD are eligible under the supplied universe and individually capped at 70%; it also states mandate limits of max position 70%, cash 5-20%, equity 50-70%, bonds 20-40%, and no restricted security IDs recorded in the supplied mandate [D1]. The packet labels the model selection and approval record as attributed selection/approval evidence, not authentication [D1].

## Proposal Comparison

| Item | ALPHA | BETA |
|---|---:|---:|
| Scope | USD 500,000 [D2] | USD 500,000 [D3] |
| Allocation | EQ 60%, BD 30%, cash 10% [D2] | FUND-Z 80%, cash 20% [D3] |
| Derived dollars | EQ USD 300,000; BD USD 150,000; cash USD 50,000 | FUND-Z USD 400,000; cash USD 100,000 |
| Liquidity | EQ/BD 2 days; cash 0 days [D2] | FUND-Z 90 days; cash 0 days [D3] |
| Conflict flags | Proprietary, revenue-sharing, and cheaper-share-class-available are asserted false for every holding [D2] | FUND-Z is proprietary; revenue-sharing status is not supplied; cheaper share class is documented available [D3] |
| Desk comment | No desk preference supplied in D2 | Proposal desk says BETA has lower advisory fees and may be attractive, but no total-cost calculation was supplied [D3] |

### Modeled Costs

Comparison policy requires the same USD 500,000 scope, keeps one-time costs separate from ongoing expenses, and sets an annual modeled-cost limit of 80 bps [D4].

| Cost item | ALPHA | BETA |
|---|---:|---:|
| Weighted product expense | 15 bps, derived from EQ 60% x 20 bps plus BD 30% x 10 bps [D2] | 32 bps, derived from FUND-Z 80% x 40 bps [D3] |
| Advisory fee | 50 bps [D2] | 40 bps [D3] |
| Custody fee | 0 bps [D2] | 5 bps [D3] |
| Other fee | 0 bps [D2] | 0 bps [D3] |
| Derived ongoing modeled cost | 65 bps, or USD 3,250/year on USD 500,000 | 77 bps, or USD 3,850/year on USD 500,000 |
| One-time transaction cost | USD 200, kept separate [D2][D4] | USD 0, kept separate [D3][D4] |
| Result against 80 bps annual modeled-cost limit | Within limit [D4] | Within limit, but closer to limit [D4] |

The supplied evidence supports BETA having a lower advisory fee than ALPHA, but not a lower total ongoing modeled cost. Based on packet arithmetic, BETA's ongoing modeled cost is 12 bps, or USD 600 per year, higher than ALPHA before considering ALPHA's separate USD 200 one-time transaction cost [D2][D3][D4].

### Look-Through Exposure And Policy Checks

Comparison policy requires issuer maximum 40%, sector maximum 70%, illiquid maximum 20% using a 30-day horizon, and includes all classes including cash and sovereigns in sourced exposure arithmetic [D4].

| Check | ALPHA derived result | BETA derived result |
|---|---|---|
| Issuer maximum 40% | Issuer A 30%, issuer B 30%, GOV1 30%, CASH1 10%; within maximum [D2][D4] | Issuer A 60%, issuer C 20%, CASH1 20%; exceeds issuer maximum via issuer A [D3][D4] |
| Sector maximum 70% | Equity/technology 60%, fixed-income/sovereign 30%, cash 10%; within maximum [D2][D4] | Equity/technology 80%, cash 20%; exceeds sector maximum [D3][D4] |
| Illiquid maximum 20% using 30-day horizon | 0% appears over 30 days because EQ/BD are 2 days and cash is 0 days; within maximum [D2][D4] | FUND-Z is 90-day liquidity and 80% of proposal; exceeds illiquid maximum [D3][D4] |
| Annual modeled-cost limit 80 bps | 65 bps; within limit [D2][D4] | 77 bps; within limit [D3][D4] |

ALPHA matches the supplied model allocation exactly: EQ 60%, BD 30%, cash 10% [D1][D2]. BETA does not match the supplied model allocation and appears to create mandate/policy questions because FUND-Z is 80% of the proposal, the look-through equity/technology exposure is 80%, and the mandate record states a max position of 70% and an equity band of 50-70% [D1][D3]. The packet does not supply a waiver, exception, or alternative mandate basis.

## Contemplated Switch Evidence Questions

| Evidence question | Why it matters | Current packet status | Proposed owner |
|---|---|---|---|
| Is BETA FUND-Z revenue sharing present or absent? | Conflict inventory is incomplete and upstream artifact flags missing evidence. | Missing and unresolved; D6 says retain the issue when moving comparison into recommendation evidence [D3][D5][D6]. | Patel / supervision routing owner, with proposal desk support |
| What is the treatment for proprietary FUND-Z and the cheaper available share class? | Conflict inventory records both but lacks treatment information. | Missing [D5]. | Patel / supervision routing owner |
| What is the completed advisor rationale for ALPHA versus BETA and any contemplated switch? | Recommendation file says available alternatives include ALPHA/BETA but advisor rationale is incomplete. | Missing [D5]. | Advisor Chen |
| Has the trading-series review been received? | Recommendation file says it has not been received. | Missing [D5]. | Advisor Chen, routed to Patel |
| Was required disclosure LIB-ADV v6 delivered before the September 17 review? | Supplied profile required LIB-ADV v6 before review, but recorded delivery is September 18 and no evidence is dated as already delivered today. | Gap / timing issue [D5]. | Advisor Chen and supervision routing owner Patel |
| Does BETA require an exception to comparison policy or mandate limits? | Derived checks show BETA exceeds issuer, sector, and illiquid comparison limits; it may also conflict with mandate max position and equity band. | No exception or waiver supplied [D1][D3][D4]. | Committee secretary / Patel |
| Is the mandate approval record authenticated? | D1 says selection/approval evidence is attributed, not authentication. | Authentication not supplied [D1]. | Committee secretary / reference MIN-33 owner |

## Committee Considerations

ALPHA is supported by the packet as matching the supplied model, staying within the comparison policy's concentration, sector, illiquidity, and modeled-cost thresholds, and having conflict flags asserted false in current proposal evidence [D1][D2][D4]. This is a source-grounded comparison point, not a return or suitability prediction.

BETA is supported by the packet as having lower advisory fees than ALPHA, but the full modeled ongoing cost is higher after product expense and custody fee are included [D2][D3][D4]. BETA also exceeds the supplied issuer, sector, and illiquidity comparison limits and has unresolved conflict evidence around proprietary status, revenue sharing, and cheaper share class availability [D3][D4][D5][D6].

For a committee action file, the current packet appears sufficient to document the comparison mechanics and open questions, but not sufficient to clear a switch recommendation. That conclusion is based on the recommendation file's missing rationale, missing trading-series review, incomplete conflict treatment, disclosure timing issue, and the upstream instruction not to label the recommendation cleared [D5][D6].
