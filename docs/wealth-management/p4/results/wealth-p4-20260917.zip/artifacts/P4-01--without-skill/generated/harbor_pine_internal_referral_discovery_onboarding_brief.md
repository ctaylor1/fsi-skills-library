# Harbor Pine Internal Referral, Discovery and Onboarding Brief

Review date: 2026-09-17  
Audience: Advisor Lee and authorized onboarding specialist Quinn  
Scope: Synthetic US advisory prospect/household review using only `source_packet.json`. No contact, system change, outside enrichment, or external verification performed.

## Source Posture

- Treat the prospect case as provisional: PROSPECT-AVENS-17 concerns adult A and partner B, but it is not an authenticated CRM identity. Operations has reserved household case HH-AVENS and recorded its association with PROSPECT-AVENS-17. [A1]
- Proposed service capacity is US advisory only; no brokerage or trust engagement is proposed in the packet. [A1]
- Source assertions are separated below from supplied-record statuses. Client-reported financial figures and planning statements are not statement-verified. [A4]
- No upstream artifacts beyond the supplied records are available. [A6]

## How the Prospective Case and Household Work Connect

PROSPECT-AVENS-17 is the provisional prospect case for A and B; HH-AVENS is the reserved household case for the inbound planning intake and is already associated to the prospect case in operations records. [A1] The household work should therefore organize joint discovery for both adults while onboarding separately tracks the proposed joint account AC-AVENS-JOINT, whose owners are A and B. [A5] Identity authentication, permissions, KYC, and consent completion remain onboarding responsibilities before any account opens. [A5][A6]

## Internal Referral Brief

### Referral and Case Context

- Referrer R says A sold a consulting practice and may want cash-flow planning. This is a referrer assertion only; A has not confirmed the sale amount or liquidity event, and no supporting documentation was supplied. [A2]
- A public business bio lists A as a founder, but permission to use the bio is limited to internal research only. [A2]
- The referrer supplied no documented authority to share B's information. Research permission, permission to share another person's data, and contact permission are separate requirements under the supplied policy. [A2][A6]
- A permitted internal review of the referral note and intake call. [A3]
- A granted email contact permission on 2026-09-14 for service information, but an active global all-channel marketing opt-out was entered on 2026-09-15 and no rescission record exists. [A3]
- B has granted no outreach permission. [A3]
- A referral arrangement lists a possible $500 payment after account opening, but compliance applicability and conflicts review are pending. Referrals do not override outreach or permission conditions. [A2][A6]

### Referral Risks and Required Handling

- Do not rely on referrer-supplied information about B for outreach or client-facing use unless B's authorization/permission is obtained and recorded. [A2][A3][A6]
- Do not draft or send outreach based on the referrer's request to "call immediately"; affirmative channel permission and no global/channel suppression are required, and those conditions are not met in the packet. [A3][A6]
- Route the possible referral payment and pending conflicts/compliance review before treating the referral arrangement as cleared. The packet does not name a specific compliance owner. [A2]

## Household Discovery Summary

### Supplied Intake Record Status

- A and B joined the inbound intake call on 2026-09-16. [A4]

### Client-Reported or Intake-Recorded, Not Document-Verified

- A reported annual salary of $150,000. [A4]
- A reported a bank deposit of about $80,000. [A4]
- A and B reported monthly spending of about $6,500, which annualizes to about $78,000 based on local calculation from the supplied monthly figure. [A4]
- A and B reported a mortgage of about $240,000. [A4]
- They said they have no other known liabilities, but no question covering all held-away assets was asked. [A4]
- The household reportedly has an existing will, but the dates, beneficiaries, and insurance coverage were not discussed. [A4]
- They want to discuss reducing work in roughly five years, but no retirement date or spending target was supplied. [A4]

### Unknowns and Discovery Gaps

Owner: Advisor Lee, per supplied policy. [A6]

- Confirm whether A actually sold the consulting practice, whether a liquidity event occurred, and the amount/timing if applicable. [A2]
- Collect B's income and broader household income details. [A4]
- Define planning objective for reducing work in roughly five years, including target date, desired work reduction, income needs, and sustainable spending target. [A4]
- Collect tax filing context. [A4]
- Inventory held-away assets, retirement accounts, cash, business interests, liabilities, and any guarantees; the intake did not ask a full held-away asset question. [A4]
- Review estate planning details: will dates, named fiduciaries, beneficiaries, titling intentions, and whether powers of attorney or health directives exist. [A4]
- Review insurance coverage and gaps. [A4]
- Confirm whether B authorizes use/discussion of B's personal information beyond the inbound call context. [A2][A3][A6]

## Onboarding Gap Handoff

Owner: Quinn for missing onboarding evidence, per supplied policy. [A6]

### Proposed Account Status

- Proposed account AC-AVENS-JOINT names A and B as owners; no additional authorized person is requested. [A5]
- No account has opened. [A5]
- Sanctions review is recorded complete with no unresolved issues under SAN-AVENS-4 covering both adults. This is a supplied onboarding-record status, not an independent sanctions recheck. [A5]
- Beneficial-ownership review is marked not required for this proposed natural-person joint registration, with rationale in profile HP-INTAKE v3. [A6]

### Received or Recorded

- A's identity record has been received. [A5]
- Joint application and ownership authority evidence are received. [A5]
- A's privacy and electronic-delivery consents are recorded. [A5]
- B's privacy consent is recorded. [A5]

### Missing or Pending

- B's identity record is pending. [A5][A6]
- Current address record for B is missing. [A5][A6]
- B's electronic-delivery consent is pending. [A5][A6]
- KYC review is pending with the authorized owner. [A5][A6]
- Account opening cannot be treated as complete until each owner has current identity/address evidence, required consents, owner-completed KYC, sanctions review, joint application, and ownership authority evidence under HP-INTAKE v3. [A6]

## Outreach Draft Status

Client-facing outreach draft: Not prepared.

The records do not support an outreach draft as of 2026-09-17. A has email contact permission for service information, but the active global all-channel marketing opt-out has no rescission record; B has no outreach permission. The supplied policy requires affirmative channel permission and no global or channel suppression, and referrals do not override those conditions. [A3][A6]

Next owner: Privacy owner should confirm suppression status if the team believes a permitted service communication may exist outside the marketing-outreach rule. Advisor Lee should not rely on the referrer's request to call immediately. [A3][A6]

## Working Notes for Human Review

- This brief does not authenticate A or B and does not verify the underlying financial facts; it summarizes supplied records only. [A1][A4]
- The most useful advisor follow-up is discovery completion around liquidity event, retirement/work-reduction goal, income, tax context, assets/liabilities, estate details, and insurance. [A2][A4][A6]
- The most useful onboarding follow-up is B identity/address/e-delivery plus completion of pending KYC before any account opening. [A5][A6]
