# Harbor Pine Internal Referral, Discovery and Onboarding Brief

Audience: Advisor Lee and authorized onboarding specialist Quinn  
Review date: 2026-09-17  
Subject: PROSPECT-AVENS-17 / HH-AVENS / AC-AVENS-JOINT  
Prepared from supplied synthetic packet only. No contact, delivery, account action, external lookup or system change has occurred.

## Source Posture

This draft distinguishes packet-supplied records from verified facts. I did not independently authenticate any source. Firm-owned records, permission exports and supplied policy are treated as packet records for internal review; client and referrer statements remain assertions.

| Source | Packet role | Key use |
| --- | --- | --- |
| A1 | Firm operations intake cover | Provisional prospect/household linkage, proposed advisory capacity, data-use scope |
| A2 | Referral desk note | Referrer statements, referral economics, sharing-authority gaps |
| A3 | Privacy permission and suppression export | A's internal-review/email permission, active global opt-out, B outreach gap |
| A4 | Advisor intake call summary | Client-reported household facts, goals and uncollected areas |
| A5 | Onboarding register | Proposed joint account evidence, identity/consent/review statuses |
| A6 | Harbor Pine supplied policy HP-INTAKE v3 | Onboarding checklist, outreach prerequisites, owners and boundaries |

## How The Prospect Case And Household Work Connect

Operations recorded PROSPECT-AVENS-17 as a provisional prospect case for adult A and partner B, and reserved HH-AVENS for the inbound planning intake; the association is recorded but not an authenticated CRM identity or completed identity verification. Proposed capacity is US advisory only, with no brokerage or trust engagement. [A1]

The workstreams are linked but not interchangeable:

- Prospect/referral work determines what internal referral context can be used and whether any outreach draft is supportable. It does not qualify the prospect, verify identity or open an account. [A1][A2][A3][A6]
- Household discovery summarizes the inbound call for HH-AVENS, preserving client-reported facts and gaps for Advisor Lee follow-up. It does not verify account balances, ownership, tax status, estate documents or suitability. [A4][A6]
- Onboarding gap work applies the HP-INTAKE v3 checklist to the proposed joint account AC-AVENS-JOINT and routes missing evidence to Quinn. It does not clear KYC, sanctions, account opening or client delivery. [A5][A6]

## Internal Referral Brief

### Case And Permitted Use

- Case: PROSPECT-AVENS-17, provisional; adult A and partner B are associated with reserved household case HH-AVENS for inbound planning intake. Identity verification remains with onboarding. [A1]
- Firm capacity: proposed US advisory engagement; no brokerage or trust engagement supplied. [A1]
- Research purpose: service discussion using only A2-A5; no outside enrichment requested. [A1]
- Policy boundary: research permission, permission to share another person's data and contact permission are separate; referrals do not override outreach conditions. [A6]

### Referral Context

- Referrer R says A sold a consulting practice and may want cash-flow planning. This is a referrer assertion, not client-confirmed fact; A has not confirmed the sale amount or a liquidity event. [A2]
- A public business bio lists A as a founder, but packet permission limits the bio to internal research only. [A2]
- The referrer supplied no documented authority to share B's information. [A2]
- A referral arrangement lists a possible $500 payment after account opening; compliance applicability and conflicts review are pending. [A2]

### Service-Discussion Topics For Advisor Review

These are questions for a human conversation, not recommendations or conclusions.

- Cash-flow planning: Should Advisor Lee ask A to confirm whether a consulting-practice sale or other liquidity event occurred, including amount, timing and whether proceeds are held personally, jointly or elsewhere? Supported by referrer assertion and explicit non-confirmation. [A2]
- Work-reduction planning: A and B said they want to discuss reducing work in roughly five years, but no retirement date or spending target was supplied. Advisor Lee should collect target timing, income expectations, spending target and priority. [A4]
- Household balance sheet: The intake call captured some client-reported assets/liabilities but did not ask a question covering all held-away assets. Advisor Lee should collect full asset inventory and statement-backed values before any planning analysis. [A4]
- Estate/protection context: A and B reported an existing will, but will dates, beneficiaries and insurance coverage were not discussed. Advisor Lee should collect document dates, beneficiary designations and protection coverage or route to specialists as appropriate. [A4]

### Contact And Outreach Controls

- A permitted internal review of the referral note and intake call and granted email contact permission on 2026-09-14 for service information. [A3]
- A has an active all-channel marketing opt-out entered 2026-09-15, with no rescission record. The email-channel export says no channel-specific block, but HP-INTAKE v3 requires no global or channel suppression for outreach drafting. [A3][A6]
- B has granted no outreach permission. [A3]
- The referrer's request that the team call immediately is not contact permission and does not override suppression or channel controls. [A3][A6]

### Referral Brief Status

Status: needs data / outreach body withheld.

Reasons:

- Active global all-channel marketing opt-out for A. Owner: privacy owner / Advisor Lee to request current permission-control guidance before any contact decision. [A3][A6]
- No outreach permission for B. Owner: Advisor Lee / privacy owner if B is to be contacted or included in outreach. [A3]
- No documented authority for referrer to share B's information. Owner: referral desk / compliance privacy reviewer. [A2][A6]
- Referral compensation applicability and conflicts review are pending. Owner: compliance / conflicts reviewer. [A2]

## Household Discovery Summary

### Household And Members

- Household: HH-AVENS, reserved for the inbound planning intake and associated with provisional prospect case PROSPECT-AVENS-17. This is a case association, not authenticated identity verification. [A1]
- Members: adult A and partner B joined the inbound call. Relationship label "partner" is sourced to the operations/intake records and does not establish legal authority, account authority or ownership outside supplied onboarding records. [A1][A4]
- Engagement status: prospective US advisory planning intake. [A1]

### Client-Reported Financial Facts

- A reported annual salary of approximately $150,000. No supporting statements were received. [A4]
- A reported a bank deposit of approximately $80,000. No supporting statements were received. [A4]
- B's income was not collected. [A4]
- A and B reported monthly spending of approximately $6,500. Locally annualized for orientation only: about $78,000 per year; this remains client-reported and unverified. [A4]
- A and B reported a mortgage of approximately $240,000. No statements were received. [A4]
- A and B said they have no other known liabilities, but no question covering all held-away assets was asked. [A4]

### Goals And Planning Context

- A and B want to discuss reducing work in roughly five years. They did not supply a retirement date, spending target or quantified goal amount. [A4]
- They reported having an existing will, but dates, beneficiaries and estate-document details were not collected. [A4]
- Insurance coverage was not discussed. [A4]
- Tax filing context was not collected. [A4]

### Discovery Coverage And Gaps

| Area | Status | Evidence / gap | Next owner |
| --- | --- | --- | --- |
| Assets | Partial / not complete | A reported about $80,000 bank deposit; no statements received; no full held-away asset question asked. [A4] | Advisor Lee |
| Liabilities | Partial | Mortgage about $240,000 and no other known liabilities reported; no documentary verification supplied. [A4] | Advisor Lee |
| Income | Partial | A salary collected; B income not collected. [A4] | Advisor Lee |
| Expenses | Partial | Monthly spending about $6,500 reported; no spending target for work-reduction planning. [A4] | Advisor Lee |
| Tax context | Not collected | Tax filing context not collected. [A4] | Advisor Lee / tax specialist if needed |
| Family/household | Partial | Adult A and partner B joined call; legal relationship/authority not established by discovery. [A1][A4] | Advisor Lee / onboarding as needed |
| Estate | Partial | Existing will reported; dates and beneficiaries not discussed. [A4] | Advisor Lee / estate specialist if needed |
| Protection | Not collected | Insurance coverage was not discussed. [A4] | Advisor Lee / protection specialist if needed |

## Onboarding Gap Handoff

### Proposed Relationship And Account

- Proposed account: AC-AVENS-JOINT, a joint account naming A and B as owners, with no additional authorized person requested. [A5]
- Firm policy HP-INTAKE v3 applies to this synthetic US advisory profile and requires current identity/address evidence for each owner, joint application, recorded ownership authority, privacy and electronic-delivery consents for each owner, owner-completed KYC and sanctions review. [A6]
- Beneficial-ownership review is marked not required for this proposed natural-person joint registration under HP-INTAKE v3. This is a supplied policy/profile assertion, not a legal conclusion by this draft. [A6]
- No account has opened. [A5]

### Supplied Evidence

- A's identity record has been received. [A5]
- Joint application and ownership authority evidence are received. [A5]
- A's privacy and electronic-delivery consents are recorded. [A5]
- B's privacy consent is recorded. [A5]
- Sanctions review is recorded completed with no unresolved issues, reference SAN-AVENS-4, covering both adults. [A5]

### Gaps For Quinn / Authorized Onboarding Review

| Gap | Affected record | Owner / next step |
| --- | --- | --- |
| B's identity record is pending. [A5][A6] | B owner evidence for AC-AVENS-JOINT | Quinn |
| Current address record for B is missing. [A5][A6] | B owner evidence for AC-AVENS-JOINT | Quinn |
| B's electronic-delivery consent is pending. [A5][A6] | B consent evidence | Quinn |
| KYC review is pending with the authorized owner. [A5][A6] | AC-AVENS-JOINT / both owners as required by policy | Authorized KYC owner; Quinn to track |
| Identity verification remains with onboarding. [A1][A5] | Household/case identity basis | Quinn / authorized onboarding reviewer |

### Onboarding Status

Status: needs data. The supplied register is useful for human review but does not support account opening or a "ready to open" conclusion because required B evidence and KYC owner review remain pending. [A5][A6]

## Separate Outreach Draft Status

Client-facing outreach body: withheld / not prepared.

The records do not support an outreach draft for use because A has an active global all-channel marketing opt-out with no rescission record, B has no outreach permission, referral-related sharing authority for B is missing, and referral compensation/conflicts review is pending. HP-INTAKE v3 requires affirmative channel permission and no global or channel suppression; referrals do not override those conditions. [A2][A3][A6]

Internal note for advisor review only: before any future outreach text is drafted, the responsible owners should resolve current suppression status, B contact permission, B data-sharing authority, and referral compensation/conflict applicability, then re-check controls as of the actual review date. [A2][A3][A6]

## Consolidated Missing Evidence And Owners

| Missing / unresolved item | Why it matters | Proposed owner |
| --- | --- | --- |
| Current suppression resolution for A's active global opt-out | Blocks outreach drafting under HP-INTAKE v3. [A3][A6] | Privacy owner / Advisor Lee |
| Outreach permission for B | B cannot be contacted or included in outreach without documented permission. [A3][A6] | Advisor Lee / privacy owner |
| Referrer authority to share B's information | Referrer supplied no documented authority for B data. [A2][A6] | Referral desk / privacy reviewer |
| Referral compensation applicability and conflicts review | Possible $500 post-opening payment and pending conflicts/compliance review. [A2] | Compliance / conflicts reviewer |
| Confirmation of any consulting-practice sale and amount/timing | Referrer assertion only; A has not confirmed amount or liquidity event. [A2] | Advisor Lee |
| B income | Not collected in discovery. [A4] | Advisor Lee |
| Full held-away asset inventory and statements | No full held-away asset question asked; reported amounts unverified. [A4] | Advisor Lee |
| Work-reduction target date/spending target | Goal is directional only. [A4] | Advisor Lee |
| Tax filing context | Not collected. [A4] | Advisor Lee |
| Will dates, beneficiaries and estate-document inventory | Existing will reported but details not discussed. [A4] | Advisor Lee / estate specialist |
| Insurance/protection coverage | Not discussed. [A4] | Advisor Lee / protection specialist |
| B identity record | Required onboarding evidence pending. [A5][A6] | Quinn |
| B current address record | Required onboarding evidence missing. [A5][A6] | Quinn |
| B electronic-delivery consent | Required consent pending. [A5][A6] | Quinn |
| KYC review completion | Required owner-completed review pending. [A5][A6] | Authorized KYC owner / Quinn tracking |

## Human Review Boundary

This draft is for internal review by Advisor Lee and authorized onboarding specialist Quinn. It is not client-facing advice, a contact authorization, a KYC/sanctions decision, referral-compensation approval, relationship acceptance, investment recommendation, account-opening approval or system-of-record update. [A1][A5][A6]
