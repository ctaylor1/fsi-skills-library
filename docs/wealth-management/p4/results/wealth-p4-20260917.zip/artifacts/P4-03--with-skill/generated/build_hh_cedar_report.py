#!/usr/bin/env python3
"""Build the HH-CEDAR human-review memo from local validated artifacts."""

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def money(value):
    if value is None:
        return "n/a"
    return f"${value:,.2f}"


def pct(value):
    return f"{value:.0f}%"


def scenario_table(retirement):
    lines = [
        "| Scenario | Terminal balance | First spending shortfall | Total spending shortfall | First asset depletion | Total modeled tax |",
        "| --- | ---: | --- | ---: | --- | ---: |",
    ]
    for scenario in retirement["result"]["scenarios"]:
        summary = scenario["summary"]
        lines.append(
            "| {label} | {terminal} | {short_age} | {shortfall} | {deplete_age} | {tax} |".format(
                label=scenario["label"],
                terminal=money(summary["terminal_portfolio"]),
                short_age=summary["first_spending_shortfall_age"] or "None",
                shortfall=money(summary["total_spending_shortfall"]),
                deplete_age=summary["first_asset_depletion_age"] or "None",
                tax=money(summary["total_modeled_tax"]),
            )
        )
    return "\n".join(lines)


def annual_tables(retirement):
    sections = []
    for scenario in retirement["result"]["scenarios"]:
        lines = [
            f"### {scenario['label']} [{', '.join(scenario['source_ids'])}]",
            "",
            "| Age | Opening portfolio | Net spending | Net income | Gross withdrawals | Withdrawal tax | Net withdrawals | Investment return | Closing portfolio | Shortfall |",
            "| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
        ]
        for row in scenario["annual_rows"]:
            lines.append(
                "| {age} | {beginning} | {spending} | {income} | {gross} | {wtax} | {netw} | {ret} | {ending} | {shortfall} |".format(
                    age=row["age"],
                    beginning=money(row["beginning_portfolio"]),
                    spending=money(row["net_spending_need"]),
                    income=money(row["net_income"]),
                    gross=money(row["gross_withdrawals"]),
                    wtax=money(row["withdrawal_tax"]),
                    netw=money(row["net_withdrawals"]),
                    ret=money(row["investment_return"]),
                    ending=money(row["ending_portfolio"]),
                    shortfall=money(row["spending_shortfall"]),
                )
            )
        lines.extend(
            [
                "",
                "Account subledger:",
                "",
                "| Age | Account | Beginning | Gross withdrawal | Withdrawal tax | Net withdrawal | Return rate | Return | Ending |",
                "| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
            ]
        )
        for row in scenario["annual_rows"]:
            for acct in row["accounts"]:
                lines.append(
                    "| {age} | {acct} | {beginning} | {gross} | {tax} | {net} | {rate} | {gain} | {ending} |".format(
                        age=row["age"],
                        acct=acct["account_id"],
                        beginning=money(acct["beginning_balance"]),
                        gross=money(acct["gross_withdrawal"]),
                        tax=money(acct["withdrawal_tax"]),
                        net=money(acct["net_withdrawal"]),
                        rate=pct(acct["return_rate"] * 100),
                        gain=money(acct["investment_return"]),
                        ending=money(acct["ending_balance"]),
                    )
                )
        sections.append("\n".join(lines))
    return "\n\n".join(sections)


def findings_list(artifact):
    if not artifact["findings"]:
        return "None."
    return "\n".join(
        f"- `{finding['code']}` at `{finding.get('path', 'n/a')}`: {finding['message']}"
        for finding in artifact["findings"]
    )


def source_registry(artifact):
    return "\n".join(
        f"- [{source['source_id']}] {source['reference']} Owner: {source['owner']}."
        for source in artifact["sources"]
    )


def main():
    retirement = json.loads((ROOT / "retirement_cashflow_artifact.json").read_text())
    ips = json.loads((ROOT / "ips_revision_artifact.json").read_text())
    ips_input = json.loads((ROOT / "ips_request.json").read_text())
    allocation = ips_input["mandate"]["allocation"]
    allocation_total = sum(row["target_pct"] for row in allocation)

    report = f"""# HH-CEDAR Two-Year Retirement Cash-Flow Illustration and IPS Revision Memo

Review date: 2026-09-17. Audience: advisor, planner and supervisory reviewer. Draft only; not delivered; no system changes or external actions taken.

## Executive Answer

Under the supplied two-year assumptions, the stated USD 60,000 annual net spending is funded in both modeled scenarios with no spending shortfall and no asset depletion. This is a calculation result from the local retirement model, using the supplied opening balances, pension schedule, withdrawal order, tax proxies and return assumptions [C1, C2, C3, C6].

This does not make the IPS revision ready for signature. The IPS artifact remains `needs-data` because revision lineage, liquidity reserve, risk governing constraint, benchmark selection, account-tax coverage, approvals and other mandate controls are incomplete under the supplied packet [C1, C4, C5, C6].

Retirement artifact: `{retirement['artifact_id']}`; status `{retirement['status']}`. IPS artifact: `{ips['artifact_id']}`; status `{ips['status']}`.

## Source Assertions Used

- HH-CEDAR is supplied as a US advisory engagement in USD; client C is age 65 in the first complete annual interval beginning 2026-09-17 and age 66 in the second row. HP-IPS v4 revision 2 is supplied, but no prior artifact ID, approval or effective IPS date is provided [C1].
- Opening balances are DEF-C $200,000 tax-deferred with 20% effective withdrawal-tax proxy and ROTH-C $100,000 tax-free with 0% proxy. Withdrawal order is DEF-C then ROTH-C; no contributions occur [C2].
- Supplied annual net spending is $60,000 with 0% spending inflation. Gross pension is $30,000 per year, active ages 65 through 66, taxed at a 20% income-tax proxy. Base return is 0%; stress return is -10% per year on every account after withdrawals [C3].
- The human-owned mandate draft states listed equity 55%, high-quality fixed income 35%, and cash 5%, with benchmark selection pending and ROTH-C omitted from the IPS tax-treatment register [C4].
- The risk handoff supplies six risk dimensions and an unresolved liquidity issue: emergency reserve and near-term liquidity need have not been quantified. Dana is asked to document the governing constraint after review [C5].
- The control register requires complete annual intervals, cent-rounded withdrawals/tax, returns after withdrawals, allocation total of 100%, complete account-tax coverage, prior-artifact linkage for revisions after 1, and pending client/advisor/supervisor approvals. It also excludes RMDs, statutory tax brackets/basis, benefit eligibility, survivor transitions and long-term-care shocks [C6].

## Verified Local Calculations

{scenario_table(retirement)}

Interpretation for planning: the supplied scenario funds the stated spending for ages 65 and 66. The base case ends with $210,000.00; the stress case ends with $166,050.00. These are deterministic arithmetic outputs, not a probability of success, not tax advice and not a benefit-entitlement determination [C3, C6].

{annual_tables(retirement)}

## Model Limits Preserved

- Opening balances start at the review date; there is no unmodeled accumulation period [C1, C6].
- Flat tax proxies are supplied scenario assumptions, not statutory calculations or distribution-eligibility conclusions [C2, C3, C6].
- RMDs, tax brackets, basis, capital gains, benefit eligibility, Roth conversions, survivor changes and long-term-care shocks are not modeled [C3, C6].
- Healthcare is included only through the supplied spending amount; the packet does not quantify separate long-term-care or reserve needs [C3, C5, C6].
- Surplus, if any, is not reinvested; no surplus appears in these rows [C3].

## IPS Revision Readiness

Not ready for signature. The draft can be reviewed, but the mandate is not signature-ready under the packet and IPS assembly controls [C1, C4, C5, C6].

Key blocking items:

- Revision 2 lacks the required prior IPS artifact ID [C1, C6].
- The emergency reserve and near-term liquidity need remain unquantified, and the IPS reserve amount is missing [C4, C5].
- Dana has not documented the governing constraint after reviewing all six risk dimensions [C5].
- Account tax-treatment coverage is incomplete: DEF-C is documented, but ROTH-C is omitted from the IPS tax-treatment register [C4, C6].
- Allocation targets supplied in the mandate total {allocation_total:.1f}%, not 100%, and benchmarks are pending [C4, C6].
- Client, advisor and supervisor approvals are not supplied; the packet records no effective IPS date [C1, C6].
- Decision authority, return objective, portfolio benchmark, rebalancing threshold, tax/cost constraints and exception owner remain undocumented in the draft record.

## Handoff Owners

| Item | Next owner | Evidence needed |
| --- | --- | --- |
| Prior IPS artifact linkage | Advisor Dana, with supervisor Rowan review | Prior artifact ID for revision 2 or corrected revision lineage [C1, C6] |
| Emergency reserve and liquidity need | Advisor Dana and planner Sol | Quantified reserve amount and near-term liquidity need; resolve RP-CEDAR-4 issue [C4, C5] |
| Governing risk constraint | Advisor Dana | Human-attributed governing constraint after review of all six dimensions [C5] |
| ROTH-C IPS tax treatment | Advisor/planner, with tax-review input if needed | Tax-treatment register covering both DEF-C and ROTH-C without relying on statutory assumptions not in packet [C2, C4, C6] |
| Allocation and benchmarks | Advisor/portfolio construction owner | Allocation targets summing to 100% and named benchmarks, or documented revision to mandate [C4, C6] |
| Rebalancing and monitoring details | Advisor Dana; supervisor Rowan review | Threshold value, tax/cost constraints, exception owner and portfolio benchmark [C4, C6] |
| Approvals and effective date | Client C, advisor Dana, supervisor Rowan | Explicit approval records and effective date after review; typed names/template version are not approval [C1, C6] |

## Workflow Findings

Retirement findings:

{findings_list(retirement)}

IPS findings:

{findings_list(ips)}

## Source Registry

{source_registry(retirement)}
"""

    (ROOT / "HH-CEDAR_retirement_cashflow_and_IPS_revision_memo.md").write_text(report)


if __name__ == "__main__":
    main()
