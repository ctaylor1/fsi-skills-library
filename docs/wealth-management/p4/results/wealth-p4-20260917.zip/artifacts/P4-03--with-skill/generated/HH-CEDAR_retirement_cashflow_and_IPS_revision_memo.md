# HH-CEDAR Two-Year Retirement Cash-Flow Illustration and IPS Revision Memo

Review date: 2026-09-17. Audience: advisor, planner and supervisory reviewer. Draft only; not delivered; no system changes or external actions taken.

## Executive Answer

Under the supplied two-year assumptions, the stated USD 60,000 annual net spending is funded in both modeled scenarios with no spending shortfall and no asset depletion. This is a calculation result from the local retirement model, using the supplied opening balances, pension schedule, withdrawal order, tax proxies and return assumptions [C1, C2, C3, C6].

This does not make the IPS revision ready for signature. The IPS artifact remains `needs-data` because revision lineage, liquidity reserve, risk governing constraint, benchmark selection, account-tax coverage, approvals and other mandate controls are incomplete under the supplied packet [C1, C4, C5, C6].

Retirement artifact: `retirement-income-scenario-modeler-70a4d146c411b8f08271`; status `needs-data`. IPS artifact: `investment-policy-statement-builder-48f0c0044dc575010538`; status `needs-data`.

## Source Assertions Used

- HH-CEDAR is supplied as a US advisory engagement in USD; client C is age 65 in the first complete annual interval beginning 2026-09-17 and age 66 in the second row. HP-IPS v4 revision 2 is supplied, but no prior artifact ID, approval or effective IPS date is provided [C1].
- Opening balances are DEF-C $200,000 tax-deferred with 20% effective withdrawal-tax proxy and ROTH-C $100,000 tax-free with 0% proxy. Withdrawal order is DEF-C then ROTH-C; no contributions occur [C2].
- Supplied annual net spending is $60,000 with 0% spending inflation. Gross pension is $30,000 per year, active ages 65 through 66, taxed at a 20% income-tax proxy. Base return is 0%; stress return is -10% per year on every account after withdrawals [C3].
- The human-owned mandate draft states listed equity 55%, high-quality fixed income 35%, and cash 5%, with benchmark selection pending and ROTH-C omitted from the IPS tax-treatment register [C4].
- The risk handoff supplies six risk dimensions and an unresolved liquidity issue: emergency reserve and near-term liquidity need have not been quantified. Dana is asked to document the governing constraint after review [C5].
- The control register requires complete annual intervals, cent-rounded withdrawals/tax, returns after withdrawals, allocation total of 100%, complete account-tax coverage, prior-artifact linkage for revisions after 1, and pending client/advisor/supervisor approvals. It also excludes RMDs, statutory tax brackets/basis, benefit eligibility, survivor transitions and long-term-care shocks [C6].

## Verified Local Calculations

| Scenario | Terminal balance | First spending shortfall | Total spending shortfall | First asset depletion | Total modeled tax |
| --- | ---: | --- | ---: | --- | ---: |
| Base: 0% annual returns and 0% spending inflation | $210,000.00 | None | $0.00 | None | $30,000.00 |
| Stress: -10% annual returns on every account, other inputs unchanged | $166,050.00 | None | $0.00 | None | $30,000.00 |

Interpretation for planning: the supplied scenario funds the stated spending for ages 65 and 66. The base case ends with $210,000.00; the stress case ends with $166,050.00. These are deterministic arithmetic outputs, not a probability of success, not tax advice and not a benefit-entitlement determination [C3, C6].

### Base: 0% annual returns and 0% spending inflation [C3]

| Age | Opening portfolio | Net spending | Net income | Gross withdrawals | Withdrawal tax | Net withdrawals | Investment return | Closing portfolio | Shortfall |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 65 | $300,000.00 | $60,000.00 | $24,000.00 | $45,000.00 | $9,000.00 | $36,000.00 | $0.00 | $255,000.00 | $0.00 |
| 66 | $255,000.00 | $60,000.00 | $24,000.00 | $45,000.00 | $9,000.00 | $36,000.00 | $0.00 | $210,000.00 | $0.00 |

Account subledger:

| Age | Account | Beginning | Gross withdrawal | Withdrawal tax | Net withdrawal | Return rate | Return | Ending |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 65 | DEF-C | $200,000.00 | $45,000.00 | $9,000.00 | $36,000.00 | 0% | $0.00 | $155,000.00 |
| 65 | ROTH-C | $100,000.00 | $0.00 | $0.00 | $0.00 | 0% | $0.00 | $100,000.00 |
| 66 | DEF-C | $155,000.00 | $45,000.00 | $9,000.00 | $36,000.00 | 0% | $0.00 | $110,000.00 |
| 66 | ROTH-C | $100,000.00 | $0.00 | $0.00 | $0.00 | 0% | $0.00 | $100,000.00 |

### Stress: -10% annual returns on every account, other inputs unchanged [C3]

| Age | Opening portfolio | Net spending | Net income | Gross withdrawals | Withdrawal tax | Net withdrawals | Investment return | Closing portfolio | Shortfall |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 65 | $300,000.00 | $60,000.00 | $24,000.00 | $45,000.00 | $9,000.00 | $36,000.00 | $-25,500.00 | $229,500.00 | $0.00 |
| 66 | $229,500.00 | $60,000.00 | $24,000.00 | $45,000.00 | $9,000.00 | $36,000.00 | $-18,450.00 | $166,050.00 | $0.00 |

Account subledger:

| Age | Account | Beginning | Gross withdrawal | Withdrawal tax | Net withdrawal | Return rate | Return | Ending |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 65 | DEF-C | $200,000.00 | $45,000.00 | $9,000.00 | $36,000.00 | -10% | $-15,500.00 | $139,500.00 |
| 65 | ROTH-C | $100,000.00 | $0.00 | $0.00 | $0.00 | -10% | $-10,000.00 | $90,000.00 |
| 66 | DEF-C | $139,500.00 | $45,000.00 | $9,000.00 | $36,000.00 | -10% | $-9,450.00 | $85,050.00 |
| 66 | ROTH-C | $90,000.00 | $0.00 | $0.00 | $0.00 | -10% | $-9,000.00 | $81,000.00 |

## Model Limits Preserved

- Opening balances start at the review date; there is no unmodeled accumulation period [C1, C6].
- Flat tax proxies are supplied scenario assumptions, not statutory calculations or distribution-eligibility conclusions [C2, C3, C6].
- RMDs, tax brackets, basis, capital gains, benefit eligibility, Roth conversions, survivor changes and long-term-care shocks are not modeled [C3, C6].
- Healthcare is included only through the supplied spending amount; the packet does not quantify separate long-term-care or reserve needs [C3, C5, C6].
- Surplus, if any, is not reinvested; no surplus appears in these rows [C3].

## IPS Revision Readiness

Not ready for signature. The draft can be reviewed, but the mandate is not signature-ready under the packet and IPS assembly controls [C1, C4, C5, C6].

Key blocking items:

- Revision 2 lacks the required prior IPS artifact ID [C1, C6].
- The emergency reserve and near-term liquidity need remain unquantified, and the IPS reserve amount is missing [C4, C5].
- Dana has not documented the governing constraint after reviewing all six risk dimensions [C5].
- Account tax-treatment coverage is incomplete: DEF-C is documented, but ROTH-C is omitted from the IPS tax-treatment register [C4, C6].
- Allocation targets supplied in the mandate total 95.0%, not 100%, and benchmarks are pending [C4, C6].
- Client, advisor and supervisor approvals are not supplied; the packet records no effective IPS date [C1, C6].
- Decision authority, return objective, portfolio benchmark, rebalancing threshold, tax/cost constraints and exception owner remain undocumented in the draft record.

## Handoff Owners

| Item | Next owner | Evidence needed |
| --- | --- | --- |
| Prior IPS artifact linkage | Advisor Dana, with supervisor Rowan review | Prior artifact ID for revision 2 or corrected revision lineage [C1, C6] |
| Emergency reserve and liquidity need | Advisor Dana and planner Sol | Quantified reserve amount and near-term liquidity need; resolve RP-CEDAR-4 issue [C4, C5] |
| Governing risk constraint | Advisor Dana | Human-attributed governing constraint after review of all six dimensions [C5] |
| ROTH-C IPS tax treatment | Advisor/planner, with tax-review input if needed | Tax-treatment register covering both DEF-C and ROTH-C without relying on statutory assumptions not in packet [C2, C4, C6] |
| Allocation and benchmarks | Advisor/portfolio construction owner | Allocation targets summing to 100% and named benchmarks, or documented revision to mandate [C4, C6] |
| Rebalancing and monitoring details | Advisor Dana; supervisor Rowan review | Threshold value, tax/cost constraints, exception owner and portfolio benchmark [C4, C6] |
| Approvals and effective date | Client C, advisor Dana, supervisor Rowan | Explicit approval records and effective date after review; typed names/template version are not approval [C1, C6] |

## Workflow Findings

Retirement findings:

- `upstream-unresolved` at `upstream_issues[0]`: Upstream liquidity-not-quantified from RP-CEDAR-4: Emergency reserve and near-term liquidity need have not been quantified.

IPS findings:

- `upstream-unresolved` at `upstream_issues[0]`: Upstream liquidity-not-quantified from RP-CEDAR-4: Emergency reserve and near-term liquidity need have not been quantified.
- `revision-lineage-gap` at `supersedes_artifact_id`: A refresh revision requires the prior IPS artifact ID
- `missing-evidence` at `mandate.governance.decision_authority`: Required text is absent
- `missing-evidence` at `mandate.objectives.return_objective`: Required text is absent
- `missing-evidence` at `mandate.risk_profile.governing_constraint`: Required text is absent
- `missing-evidence` at `mandate.rebalancing.tax_cost_constraints`: Required text is absent
- `missing-evidence` at `mandate.rebalancing.exception_owner`: Required text is absent
- `missing-evidence` at `mandate.monitoring.portfolio_benchmark`: Required text is absent
- `unresolved-risk-finding` at `mandate.risk_profile.unresolved_findings[0]`: Unresolved upstream risk finding must remain visible for human adjudication
- `missing-evidence` at `mandate.liquidity.reserve_amount`: Required number is absent
- `account-scope-mismatch` at `mandate.tax.account_treatments`: Tax treatment must cover exactly the mandate account scope
- `missing-evidence` at `mandate.allocation[0].benchmark`: Required text is absent
- `missing-evidence` at `mandate.allocation[1].benchmark`: Required text is absent
- `missing-evidence` at `mandate.allocation[2].benchmark`: Required text is absent
- `missing-evidence` at `mandate.rebalancing.threshold_percentage_points`: Required number is absent

## Source Registry

- [C1] Engagement and revision cover, advisor Dana, 2026-09-17; current through 2026-09-30 Owner: Dana.
- [C2] Account and tax-proxy worksheet, planner Sol, 2026-09-17; current through 2026-09-30 Owner: Sol.
- [C3] Spending and income assumptions, planner Sol, 2026-09-17; current through 2026-09-30 Owner: Sol.
- [C4] Human-owned mandate draft, Dana, 2026-09-16; current through 2026-09-30 Owner: Dana.
- [C5] Risk handoff RP-CEDAR-4, risk reviewer Sol, 2026-09-16; current through 2026-09-30 Owner: Sol.
- [C6] Review instructions and limitations register, control owner Rowan, 2026-09-17; current through 2026-12-31 Owner: Rowan.
