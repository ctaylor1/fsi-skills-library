Prepared the HH-CEDAR draft package.

Main memo: [HH-CEDAR_retirement_cashflow_and_IPS_revision_memo.md](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-wek4zu88/work/HH-CEDAR_retirement_cashflow_and_IPS_revision_memo.md)

Supporting local artifacts:
- [retirement_request.json](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-wek4zu88/work/retirement_request.json)
- [retirement_cashflow_artifact.json](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-wek4zu88/work/retirement_cashflow_artifact.json)
- [ips_request.json](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-wek4zu88/work/ips_request.json)
- [ips_revision_artifact.json](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-wek4zu88/work/ips_revision_artifact.json)

Key answer: the supplied two-year spending scenario funds the stated $60,000 annual net spending in both base and stress cases, with no modeled spending shortfall or asset depletion. Terminal balances are $210,000 base and $166,050 stress.

IPS answer: not ready for signature. The memo preserves the missing evidence and next owners: prior IPS artifact ID, quantified reserve/liquidity need, governing risk constraint, ROTH-C tax-treatment coverage, benchmarks, allocation total correction, rebalancing details, approvals and effective date.

Verification: both generated workflow artifacts passed their local output validators with `0 error(s)`. The shell emitted sandbox-related `/tmp/xcrun_db` cache warnings, but the validators completed successfully.