# Internal Draft: HH-JADE Liquidity-Options Memo

Review date: 2026-09-17  
Audience: advisory team / lending specialist review  
Calculation artifact: `wealth-lending-liquidity-reviewer-0f1ffe1e55e58169b684`  
Status: needs data / human review required. No funding strategy selected, no application submitted, no trade, transfer, pledge, disbursement, meeting or client communication occurred.

## Source Posture and Objective

Source assertions, not independently verified: K5 asserts HH-JADE needs a $30,000 home-repair payment by 2026-09-25, not for a securities purchase, with $20,000 current unencumbered cash, a $10,000 protected reserve and a $1,000 monthly debt budget before all modeled facility service. K6 asserts current loan terms, collateral values, quote validity and stress assumptions; K6 also states no current source authenticates a loan approval or permits drawing. [K5][K6]

Calculated from supplied assertions: the local lending/liquidity input and output validators returned no errors. The artifact remains `needs-data` because approval/draw authority is unresolved, liquidation proceeds arrive after the need date, S-J funding arrives after the need date, and S-J stress creates a borrowing-capacity gap. [K5][K6]

## Independent Alternatives

Alternatives are shown independently and are not additive. The figures do not allocate a strategy or recommend borrowing, liquidation or use of reserves.

| Alternative | Known net funds | Availability | Gap to $30,000 need | 12-month modeled cost basis | Material tradeoff / evidence |
| --- | ---: | --- | ---: | ---: | --- |
| Cash above protected reserve | $10,000.00 | current | $20,000.00 | not estimated | Uses only cash above the supplied protected reserve; reserve basis not separately verified. [K5] |
| Supplied liquidation illustration | $30,300.00 | 2026-09-26 | $0.00 amount gap, but late | tax reserve supplied only; no tax calculation | Gross $32,000 less $200 fees and $1,500 supplied tax reserve; proceeds arrive one day after need date; no realized sale. [K5] |
| U-J unsecured facility | $29,700.00 | 2026-09-24 | $300.00 | $300.00 financing cost over 12 months | $30,000 draw less $300 withheld upfront fee; no approval/draw permission authenticated. [K6] |
| S-J SBLOC | $30,000.00 | 2026-09-28 | $0.00 amount gap, but late | $2,520.00 base; $3,720.00 stress | Funding date is three days after need; on-demand and ongoing-maintenance features apply; no approval/draw permission authenticated. [K6] |

## Loan and Stress Detail

U-J supplied terms: $30,000 draw, no existing balance, $30,000 limit, $300 upfront fee withheld, 0% fixed nominal rate, no floor/cap, 30-month amortization, funding 2026-09-24, use recorded-permitted, no collateral and not on-demand. [K6]

Calculated U-J 12-month view: net new proceeds $29,700; opening principal $30,000; monthly service $1,000; no monthly budget shortfall against the supplied $1,000 budget; $12,000 principal repaid by month 12; ending principal $18,000; horizon financing cost $300. Stress does not change the fixed 0% rate. [K5][K6]

S-J supplied terms: $30,000 draw on a facility with $10,000 existing balance and $60,000 total limit; 6% floating nominal rate with 2% floor and 12% cap; $10 monthly fee; interest-only 24 months; funding 2026-09-28; on-demand; ongoing maintenance; maturity funding supplied as $0. Collateral SEC-J is asserted at $100,000 value, $20,000 reserved elsewhere, eligible, with 60% advance rate and 2026-09-17 valuation. [K6]

Calculated S-J base case: opening principal $40,000; borrowing base/effective capacity $48,000; debt over capacity $0; monthly service $210; no monthly budget shortfall against the supplied $1,000 budget; 12-month horizon financing cost $2,520; ending principal $40,000. [K5][K6]

Calculated S-J STRESS-K case: shocked rate 9%; borrowing base/effective capacity $30,000; debt over capacity $10,000, shown only as an illustrative maintenance paydown amount with no cure instruction; monthly service $310; no monthly budget shortfall against the supplied $1,000 budget; 12-month horizon financing cost $3,720; ending principal $40,000. [K5][K6]

## Missing Evidence and Next Owners

Wren / lending specialist: provide or confirm actual credit approval, draw authority and applicable lender disclosures before any reliance on U-J or S-J availability. Current packet says no source authenticates approval or permits drawing. [K6]

Uma / advisor: confirm whether the 2026-09-25 need date is hard and whether late alternatives remain relevant for review; liquidation is available 2026-09-26 and S-J funding is 2026-09-28. [K5][K6]

Tax reviewer: review the liquidation tax lots and tax assumptions. The memo uses only the supplied $1,500 tax reserve and does not calculate tax. [K5]

Planning/advisory reviewer: verify the protected reserve, cash-flow budget and whether the $1,000 monthly debt budget remains appropriate under each facility’s service convention. [K5]

Collateral/data owner or lending specialist: verify collateral ownership, encumbrance, eligibility, valuation and maintenance mechanics before treating S-J capacity as available. K6 supplies value, reserved value, eligibility and advance rate, but the artifact does not authenticate availability or approval. [K6]

## Method and Boundaries

Monthly projections use the supplied nominal annual rate divided by 12, rounded monthly to cents. Horizon is 12 months. Financing cost includes interest, recurring fees and upfront fee; it excludes repaid principal. The memo does not estimate opportunity cost, investment return, APR, legal eligibility, tax treatment, underwriting probability or a recommended funding mix.
