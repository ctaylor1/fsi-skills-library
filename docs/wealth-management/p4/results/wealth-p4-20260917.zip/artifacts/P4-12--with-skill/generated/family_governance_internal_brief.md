# Facilitator Family-Governance Preparation Brief

Review as of 2026-09-17. Synthetic records only. Prepared from `source_packet.json` only. Internal facilitator review draft; no delivery, scheduling, legal determination, trust action or system change.

## Scope, Audience and Boundary

Packet assertion: FAMILY-LINDEN is a US advisory family-group engagement using collection marker `family:FAMILY-LINDEN`; L-A and L-B map to HH-L1, L-C maps to HH-L2, and professional facilitator F-PRO has no household membership [L1].

Packet assertion: requested family audience is L-A, L-B and L-C. Public policy, member labels, public discussion roles and sources L2/L3 are permitted to all three for this discussion; L4 is permitted only to L-A/F-PRO and is not authorized for L-B/L-C [L1, L4].

Boundary for facilitator: a family discussion, vote, role label or follow-up is not legal authority, trust authority, trustee appointment, beneficiary entitlement or permission to share trust records [L2, L3, L5]. The full internal packet and this internal brief are not family-visible [L1, L4].

## Discussion Topics and Process Observations

| Topic | Source assertion | Process observation, not a decision |
| --- | --- | --- |
| Education workshop ED-L | Question: whether to hold a joint financial-literacy workshop. Duration 20 minutes. Eligible L-A/L-B/L-C under majority-of-all-eligible rule with quorum 2. L-A supports, L-B opposes and prefers separate sessions, L-C has no recorded position [L2]. | Verified from supplied positions: quorum evidence appears to be 2 recorded participants, but only 1 of 3 eligible members supports. Majority of all eligible is not met. Preserve L-B's stated preference and L-C's missing position; do not state consensus [L2]. |
| Trust question TR-Q | Question: whether L-B should replace a trustee. Duration 25 minutes. Classified as a legal-authority question. All three supplied written positions support discussing it; counsel is asked to review [L2]. | The family can discuss the question and route it for professional review. The discussion does not replace trust instruments, counsel review, appointment evidence or joint-action requirements [L2, L5]. |
| Restricted internal planning item | L-A reported an unresolved personal guarantee; amount and effect unknown. Source says this topic, title, ID, contents, existence/count and source reference are not authorized to L-B/L-C [L4]. | Internal-only. Do not mention in the family draft or family discussion materials. Next owner: F-PRO/private adviser to maintain restricted handling and resolve scope through authorized channels [L4]. |

## Succession Preparation

Packet assertion: ROLE-CHAIR is a family-discussion chair role for convening education sessions, not trustee/legal authority. Current holder is L-A. L-B confirmed interest on 2026-09-16 for a proposed 2027-01-15 transition [L3].

Packet assertion: required criteria are prior facilitation and confidentiality orientation. Prior facilitation is documented by F-PRO from two sessions; confidentiality orientation evidence is unknown [L3].

Preparation observation: L-B has attributed interest and one documented criterion, but the succession preparation record is incomplete because confidentiality orientation evidence is unknown. This does not appoint L-B, assess personal capacity, or establish any trust role [L3].

Next owner: F-PRO to obtain or schedule documented confidentiality orientation evidence before presenting readiness as evidence-complete [L3].

## Education and Meeting Plan

Packet assertion: proposed group workshop linked to ED-L is 20 minutes, participants L-A/L-B/L-C, facilitator F-PRO. L-C separately requested individual learning, and the group proposal has not been reconciled with that preference [L3].

Verified timing from supplied minutes:

| Component | Minutes | Audience status | Sources |
| --- | ---:| --- | --- |
| ED-L discussion | 20 | Family-visible candidate | [L2] |
| TR-Q discussion | 25 | Family-visible candidate | [L2] |
| Group workshop activity | 20 | Family-visible candidate | [L3] |
| Restricted internal planning | 15 | Internal-only, not family-visible | [L4] |

Calculated public family agenda total is 65 minutes against a 75-minute budget, leaving 10 minutes. If the restricted internal planning item were combined into the same time block, known minutes would be 80 and exceed the budget by 5 minutes. Facilitator should keep the restricted item outside the family-facing agenda or explicitly adjust internal time [L2, L3, L4].

Next owner: F-PRO to reconcile L-C's individual-learning request with the proposed group workshop and decide whether ED-L should become joint, separate, or hybrid preparation [L3].

## Follow-Ups and Open Evidence

| Item | Status | Next owner | Evidence |
| --- | --- | --- | --- |
| Counsel question on TR-Q / trustee replacement topic | Agreed, not completed; due 2026-09-21 | F-PRO to route only the trust/legal question and minimum necessary context to counsel/trust team | [L3] |
| ED-L position record | L-C has no recorded position; L-B opposes joint format | F-PRO to obtain L-C's position and preserve L-B's stated preference | [L2] |
| ROLE-CHAIR succession criterion | Confidentiality orientation evidence unknown | F-PRO | [L3] |
| Restricted guarantee scope | Amount and effect unknown; unresolved origin PRIVATE-L-7 / `guarantee-scope-unknown` | F-PRO/private adviser, under restricted access only | [L4] |

## Handoff to Trust / Legal Review

Minimum evidence to hand off: TR-Q asks whether L-B should replace a trustee; all three family members support discussing the question; counsel review was requested through FU-L due 2026-09-21 [L2, L3].

Do not hand off the full family packet by default. Do not include L4 or any trust ledger/distribution data in family-facing materials. The trust team must use the trust-capacity records and governing-document evidence, not a family discussion result, to review authority questions [L1, L4, L5].
