# Family Discussion Draft

Review candidate as of 2026-09-17. Synthetic records only. Facilitator confidentiality review required before any use. Nothing has been sent or scheduled.

## Proposed Discussion

1. Education workshop

   Discuss whether the family wants a joint financial-literacy workshop. L-A supports a joint workshop, L-B prefers separate sessions, and L-C's position has not yet been recorded [L2]. The proposed group workshop would include L-A, L-B and L-C with F-PRO facilitating [L3].

2. Succession preparation for the family discussion chair

   Discuss preparation for the family discussion chair role, which is limited to convening education sessions and is not a trustee or legal-authority role [L3]. L-B has confirmed interest in a possible 2027-01-15 transition, prior facilitation is documented, and confidentiality-orientation evidence still needs to be completed or documented [L3].

3. Trust-related question for professional review

   Discuss whether to ask counsel/trust reviewers about the trustee-replacement question. The family discussion can frame the question, but it does not appoint or remove a trustee, establish document powers, approve a distribution, or create legal authority [L2, L3].

## Proposed Timing

| Item | Minutes |
| --- | ---:|
| Education workshop discussion | 20 |
| Trust-related question | 25 |
| Group workshop activity | 20 |

Known proposed time is 65 minutes against the 75-minute meeting budget [L2, L3].

## Draft Follow-Up

F-PRO owns the counsel question on the trust-related topic, accepted for follow-up and due 2026-09-21 [L3].
