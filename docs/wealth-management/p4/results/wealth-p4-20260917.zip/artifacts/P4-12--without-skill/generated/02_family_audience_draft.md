# Family Discussion Draft

Review date: 2026-09-17  
Audience: L-A, L-B and L-C, for human review before circulation  
Facilitator: F-PRO

This draft is for the family discussion only. It is not a trustee action, legal instruction or trust-administration record.

Statements about attendance, topics, roles and timing are packet-supplied assertions cited to authorized family-discussion records. Items labeled as "possible family output" are draft facilitator prompts, not verified outcomes.

## Purpose

The September 24 discussion is expected to cover education planning, the family education-chair succession question and a trust-related question for counsel review. L-A, L-B and L-C have each indicated willingness to attend, and F-PRO will facilitate. [L1]

## Discussion Guardrails

- The family discussion can record preferences and questions, but a family vote does not create document powers or replace legal review. [L2]
- The family education chair role is a discussion role for convening education sessions. It is not trustee authority or other legal authority. [L3]
- The trust question should be framed as a question for counsel and the relevant trust process, not as an action taken by this meeting. [L2]

## Proposed Agenda

### Education Planning

Topic: whether to hold a joint financial-literacy workshop. The policy record allocates 20 minutes for this topic. [L2]

Recorded starting points:

- L-A supports a joint workshop. [L2]
- L-B prefers separate sessions. [L2]
- L-C has no recorded position on the joint workshop and has separately requested individual learning. [L2, L3]

Possible family output: agree whether to continue with a joint session, separate sessions or a combined approach that respects L-C's individual-learning request.

### Education-Chair Succession

The current family discussion chair for education sessions is L-A. L-B has confirmed interest in a proposed transition on January 15, 2027. [L3]

The recorded criteria are prior facilitation and confidentiality orientation. Prior facilitation is documented; confidentiality-orientation evidence is still unknown. [L3]

Possible family output: confirm the desired transition path and identify what evidence or orientation should be completed before the transition date.

### Trust Question For Counsel

The family has asked to discuss whether L-B should replace a trustee. This is a legal-authority question, and counsel review has been requested. [L2]

Possible family output: list questions or preferences for counsel. The meeting should not describe itself as appointing, removing or replacing a trustee. [L2]

## Draft Next Steps

- F-PRO to record the family discussion outcomes that are within family-governance scope. [L1, L2]
- F-PRO to follow up on the counsel question for the trust topic by the recorded September 21 due date. [L3]
- F-PRO to confirm whether L-B's confidentiality orientation evidence exists or needs to be completed before the proposed role transition. [L3]
