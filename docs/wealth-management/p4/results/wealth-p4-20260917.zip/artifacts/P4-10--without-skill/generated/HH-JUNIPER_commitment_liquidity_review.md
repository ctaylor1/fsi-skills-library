# HH-JUNIPER Private-Market Commitment and Liquidity Review

Draft for advisor review. Review date: 2026-09-17. Scope is PM-J / Fund F-J account-specific commitment and liquidity review using only the supplied packet. This is not a subscription, eligibility, redemption, or transfer decision.

## Executive View

PM-J has an immediate funding issue. Supplied settled cash is USD 40,000, with USD 10,000 protected reserve, leaving USD 30,000 available if the reserve is maintained. Current payable is USD 55,000, made up of unpaid CALL-J1 of USD 50,000 due October 1 and outside-commitment FEE-J1 of USD 5,000 due October 2. The calculated shortfall is USD 25,000 before relying on unsettled DIST-J1. [J4][J5]

If the USD 20,000 DIST-J1 expected September 25 is received before the October 1-2 obligations and the protected reserve remains intact, available cash would be USD 50,000, still USD 5,000 short of the current payable. DIST-J1 was not received and was not included in settled cash as of the review record. [J5]

Through November 30, the supplied obligations and forecasts total USD 85,000: USD 50,000 CALL-J1, USD 5,000 FEE-J1, and USD 30,000 active incremental call forecast due November 1. Against settled cash plus expected DIST-J1 less the protected reserve, the calculated shortfall through November 30 is USD 35,000. [J4][J5]

## Commitment Position

| Item | Amount | Treatment |
|---|---:|---|
| Operative commitment | USD 300,000 | Supplied administrator statement. [J4] |
| Complete since-inception settled inside-commitment call effects | USD 120,000 | Cumulative inventory with supporting movement records; do not add again to current cash. [J4] |
| Complete settled recallable distribution effects | USD 10,000 | Cumulative inventory with supporting movement records; do not add again to current cash. [J4] |
| New unpaid CALL-J1 | USD 50,000 | All inside commitment; due October 1; none settled. [J4] |
| Administrator-reported uncalled | USD 140,000 | Use administrator mapping; arithmetic ties to 300,000 - 120,000 + 10,000 - 50,000. [J4] |
| Outside-commitment FEE-J1 | USD 5,000 | Due October 2; outside commitment. [J4] |
| Administrator-reported call/fee cash payable | USD 55,000 | CALL-J1 plus FEE-J1. [J4] |

## Cash and Liquidity Bridge

| Liquidity item | Amount | Notes |
|---|---:|---|
| Current settled cash | USD 40,000 | Current cash already includes historical settled calls/distributions. [J5] |
| Protected reserve | USD 10,000 | Reserve to preserve unless reviewed otherwise. [J5] |
| Available cash after reserve | USD 30,000 | Calculated from supplied cash less reserve. [J5] |
| Current payable due October 1-2 | USD 55,000 | CALL-J1 plus FEE-J1. [J4] |
| Immediate shortfall after reserve | USD 25,000 | Calculated USD 55,000 payable less USD 30,000 available cash. [J4][J5] |
| If reserve is used | USD 15,000 shortfall | Calculated USD 55,000 payable less USD 40,000 settled cash; reserve use is not approved in the packet. [J4][J5] |
| DIST-J1 expected September 25 | USD 20,000 | Unsettled, not received, not included in settled cash. [J5] |
| Shortfall if DIST-J1 received and reserve maintained | USD 5,000 | Calculated USD 55,000 payable less USD 50,000 cash available after reserve. [J4][J5] |
| Active incremental call forecast due November 1 | USD 30,000 | Does not replace CALL-J1. [J5] |
| Through-November obligations / forecasts | USD 85,000 | CALL-J1 + FEE-J1 + November forecast. [J4][J5] |
| Through-November shortfall after cash, DIST-J1, and reserve | USD 35,000 | Calculated USD 85,000 less USD 50,000. [J4][J5] |

## Liquidity Under Review

The packet supplies a USD 55,000 liquidity amount under review, a notice deadline of September 10, a request scenario dated September 17, and expected settlement on December 15. HH-JUNIPER needs USD 55,000 on October 1. Gates may delay access, and the packet states these are scenario terms, not assured redemption rights. [J3]

The supplied liquidity scenario does not appear usable for the October 1 need based on the packet dates. The packet does not provide authority to assume earlier settlement, waiver of notice deadlines, or absence of gates/suspensions. [J3]

## Valuation, Eligibility, and Diligence Gaps Affecting Review

- Reported NAV is USD 210,000 as of June 30, 2026; the policy maximum age is 60 days at review, no refreshed valuation is supplied, and later cash movements are not an approved current-NAV roll-forward. [J6]
- Required fund/account eligibility review is pending with counsel despite a manager checkbox saying "eligible." [J6]
- Required document list includes the offering memorandum and subscription record; only the memorandum has been received. [J6]
- Manager diligence artifact DD-M-J-3 and its unresolved independent-assurance-missing concern are imported. [J6]
- Declared inventory coverage is complete for arithmetic through the dated funding horizon of November 30, but eligibility, valuation, and diligence gaps remain separate. [J6]

## Funding Risks and Draft Implications

The PM-J funding plan is not covered by settled cash if the protected reserve remains in place. Even receipt of DIST-J1 before October 1 would leave a USD 5,000 gap against current payable. The packet also prohibits assuming other accounts may fund PM-J without separately reviewed transfer authority. [J4][J5]

The December 15 expected settlement date for the USD 55,000 liquidity amount under review does not match the October 1 household need, and gates may delay access. This should be treated as a liquidity mismatch unless the manager-review owner and administrator supply evidence of earlier liquidity or another approved funding source. [J3]

## Questions for Administrator

1. Has DIST-J1 of USD 20,000 been received since the September 17 review record, and if so, is it settled cash available for CALL-J1/FEE-J1 funding? [J5]
2. Confirm whether the protected reserve of USD 10,000 must remain untouched for the October 1-2 payable analysis. [J5]
3. Confirm that the administrator-reported uncalled amount of USD 140,000 is after reflecting CALL-J1 of USD 50,000, consistent with the supplied mapping. [J4]
4. Confirm whether any additional unpaid calls, fees, distributions, or cash obligations exist through November 30 beyond the supplied records. The packet says all notices, obligations, and forecasts through November 30 were supplied. [J5]
5. Confirm whether any reviewed transfer authority exists to fund PM-J from another account; absent that, no other account should be assumed as a funding source. [J5]
6. Provide the missing subscription record and any refreshed valuation / administrator-approved NAV update if available. [J6]

## Questions for Manager-Review Owner

1. Can the September 17 liquidity request scenario settle before October 1, or is December 15 the earliest expected settlement under supplied terms? [J3]
2. Does the September 10 notice deadline mean the September 17 request is outside the relevant notice window, and what is the documented effect for HH-JUNIPER? [J3]
3. Are any gates or suspensions currently active, or are they only permitted under documents? [J2][J3]
4. Should the 90-day liquidity profile and possible gates/suspensions be escalated as a policy exception against the supplied 60-day liquidity criterion? [J1][J2]
5. Does the unresolved missing independent assurance concern affect the advisor's ability to rely on manager-supplied liquidity information for this funding review? [J2][J6]

## Draft Advisor Note

As of the supplied review date, PM-J appears short of the October 1-2 payable using settled cash while maintaining the protected reserve. The household's USD 55,000 October 1 need is not solved by the supplied private-market liquidity scenario because expected settlement is December 15 and gates may delay access. The administrator should confirm receipt status of DIST-J1, reserve treatment, and any approved transfer authority; the manager-review owner should confirm liquidity mechanics, gate status, and exception handling. [J3][J4][J5][J6]
