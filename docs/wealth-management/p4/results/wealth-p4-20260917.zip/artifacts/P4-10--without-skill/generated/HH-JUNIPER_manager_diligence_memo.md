# HH-JUNIPER Investor-Side Manager Diligence Memo

Draft for advisor review. Review date: 2026-09-17. Scope is investor-side diligence support for HH-JUNIPER regarding Manager M-J / Strategy S-J. This is not a manager DDQ response, subscription recommendation, eligibility decision, or approval.

## Executive View

Based only on the supplied packet, Manager M-J / Strategy S-J does not currently clear all supplied investor-side review criteria for HH-JUNIPER. The most material open items are the unresolved lack of an independent annual assurance report and the reported liquidity profile of 90 days with possible gates/suspensions, versus a supplied 60-day liquidity criterion. [J1][J2]

Several dimensions appear within the supplied criteria, but they remain source assertions rather than independently verified facts unless noted below: manager-reported leverage is 0.7 versus a maximum of 1.0; firm-record ongoing base fees are 125 bps versus a maximum of 150 bps; and the evidence inventory age is reported at 30 days versus a maximum of 90 days. [J1][J2]

Account-specific funding creates a separate concern: PM-J has USD 40,000 settled cash and a USD 10,000 protected reserve, leaving USD 30,000 available if the reserve is maintained. Current unpaid call/fee payable is USD 55,000 due October 1-2, producing a calculated USD 25,000 near-term shortfall before relying on any unsettled distribution. [J4][J5]

## Source Grounding and Fact Treatment

Source assertions from the packet:

- Policy criteria supplied for this investor-side review require each of the following: leverage maximum 1.0; independent annual assurance report for operations; ongoing base-cost maximum 150 bps; documented liquidity maximum 60 days; observed evidence age maximum 90 days; 30-day monitoring interval. The packet states this policy is investor-side and is not a universal approval rule. [J1]
- Manager-reported leverage is 0.7, observed September 10. [J2]
- The manager explicitly responded that an independent annual assurance report is not available, and no independent report was supplied. The unresolved diligence concern is coded `independent-assurance-missing`. [J2]
- Firm-record ongoing base fees are 125 bps, observed September 16. [J2]
- Manager-reported liquidity is 90 days, with possible gate/suspension marked true. [J2]
- Evidence inventory observed age is 30 days and was reviewed September 17. [J2]
- Required eligibility review is pending with counsel despite a manager checkbox saying "eligible"; the subscription record is missing while the offering memorandum has been received. [J6]
- Reported NAV is USD 210,000 as of June 30, 2026; policy max age is 60 days at review, and no refreshed valuation is supplied. Later cash movements are not an approved current-NAV roll-forward. [J6]

Locally checked arithmetic from supplied figures:

- Base fee illustration: on a separate illustrative USD 200,000 investment, management fee at 100 bps plus other fee at 25 bps equals USD 2,500. Gross return at 10% equals USD 20,000; hurdle at 4% equals USD 8,000. With base fees reducing the incentive base above the hurdle, incentive base is USD 9,500 and the 20% incentive fee is USD 1,900. Total illustrated fees are USD 4,400 and net gain is USD 15,600, or 7.8% of the illustrative investment. This is a supplied illustration, not an account return or assured outcome. [J3]
- For PM-J, current payable of USD 55,000 equals CALL-J1 of USD 50,000 plus FEE-J1 of USD 5,000. Available cash after maintaining the USD 10,000 reserve is USD 30,000, creating a USD 25,000 shortfall against current payable. [J4][J5]

## Criteria Status

| Dimension | Supplied criterion | Supplied evidence | Draft status |
|---|---:|---|---|
| Leverage | Maximum 1.0 | Manager-reported leverage 0.7 observed September 10 | Appears within criterion, subject to source assertion status. [J1][J2] |
| Operations | Independently documented annual assurance report required | Manager says report is not available; no independent report supplied; unresolved concern imported | Does not meet supplied evidence requirement. [J1][J2][J6] |
| Ongoing base cost | Maximum 150 bps | Firm-record ongoing base fees 125 bps observed September 16 | Appears within criterion, subject to source assertion status. [J1][J2] |
| Liquidity | Documented days maximum 60 | Manager-reported liquidity 90 days; possible gate/suspension true | Does not meet supplied liquidity criterion. [J1][J2] |
| Evidence age | Maximum 90 days | Evidence inventory observed age 30 days | Appears within criterion. [J1][J2] |

## Investor-Side Implications for HH-JUNIPER

The manager diligence evidence is not ready for a clean investor-side "criteria met" memo because operations and liquidity have unresolved exceptions. The operations exception is especially important because the policy requires independent evidence, and the packet says no independent annual assurance report was supplied. [J1][J2]

The liquidity profile is also misaligned with the account's near-term funding needs. The packet supplies a USD 55,000 liquidity amount under review, a September 17 request scenario, and an expected settlement of December 15, while HH-JUNIPER needs USD 55,000 on October 1. Gates may delay access. These dates are supplied scenario terms, not assured redemption rights. [J3]

Eligibility and valuation should be treated as separate unresolved handoffs rather than manager diligence conclusions. The packet says eligibility review is pending with counsel, the subscription record is missing, and the June 30 NAV is older than the 60-day policy maximum at the September 17 review date. [J6]

## Missing Evidence / Open Items

- Independent annual assurance report or acceptable independent operations evidence is missing; current source record says it is unavailable. Owner for follow-up: manager-review owner. [J2]
- Liquidity documentation supporting 60 days or less is not supplied; current evidence states 90 days plus possible gate/suspension. Owner for follow-up: manager-review owner. [J1][J2]
- No refreshed valuation is supplied after June 30, 2026, and later cash movements are not approved as a current-NAV roll-forward. Owner for follow-up: administrator / operations handoff owner. [J6]
- Subscription record is missing, and eligibility review remains pending with counsel despite a manager checkbox saying eligible. Owner for follow-up: administrator / counsel handoff owner. [J6]
- No evidence in the packet resolves whether expected December 15 liquidity can be accelerated or whether gates/suspensions apply to HH-JUNIPER's scenario. Owner for follow-up: manager-review owner with administrator confirmation of account-level mechanics. [J2][J3]

## Questions for Manager-Review Owner

1. Can the manager-review owner confirm whether the lack of an independent annual assurance report is an automatic exception under DD-J v3, or whether any alternative independent operations evidence may satisfy the policy? [J1][J2]
2. Is the 90-day liquidity term the controlling term for HH-JUNIPER's contemplated exposure, and do gates/suspensions currently apply or only remain possible under fund documents? [J2][J3]
3. Is there any source-grounded basis to reconcile the 90-day manager-reported liquidity with the 60-day investor-side criterion, or should this be recorded as a policy exception? [J1][J2]
4. Should the unresolved `independent-assurance-missing` concern block further advisor presentation, or may it be presented as an exception requiring approval outside this memo? [J2][J6]
5. Are the 125 bps firm-record ongoing base fees complete for the policy base-cost test, or are any additional ongoing fund expenses excluded from that observation? [J1][J2]

## Questions for Administrator / Operations Owner

1. Please confirm the PM-J payable mapping: CALL-J1 USD 50,000 inside commitment due October 1 plus FEE-J1 USD 5,000 outside commitment due October 2 equals USD 55,000 cash payable. [J4]
2. Please confirm whether DIST-J1 of USD 20,000 expected September 25 has been received before any funding instruction is made; the packet says it was not received and not included in settled cash as of review. [J5]
3. Please provide the missing subscription record or confirm that it is unavailable for this review cycle. [J6]
4. Please provide a refreshed valuation or administrator-approved NAV update, if available; the supplied NAV is June 30 and exceeds the 60-day age policy at review. [J6]
5. Please confirm whether any transfer authority exists to fund PM-J from another account; the packet says no other accounts may fund PM-J without separately reviewed transfer authority. [J5]

## Draft Advisor Note

For HH-JUNIPER, the supplied manager evidence supports only a qualified investor-side diligence view. Leverage, base fees, and evidence age appear within the supplied thresholds, but operations and liquidity do not currently meet the stated criteria. The missing independent annual assurance report is unresolved, and manager-reported liquidity is 90 days with possible gates/suspensions versus a 60-day criterion. Separately, PM-J has a near-term funding gap against the October 1-2 call and fee payable if the protected reserve is maintained. This draft should be reviewed by the manager-review owner and administrator before advisor use. [J1][J2][J4][J5][J6]
