Done. I created two local draft artifacts:

- [HH-HEATH_internal_evidence_review_pack.md](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-ic6_prnd/work/HH-HEATH_internal_evidence_review_pack.md:1)
- [HH-HEATH_unsent_client_email_draft.md](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-ic6_prnd/work/HH-HEATH_unsent_client_email_draft.md:1)

The internal pack clearly separates Stage 1 pre-meeting evidence from Stage 2 post-meeting outcomes, includes the advisor-only issue note, proposed CRM fields, owned next steps, a missing-evidence register, and a source map with H1-H6 citations.

The client email is marked unsent, limited to H-A/H-B, uses only the approved follow-up substance, and avoids the restricted H4/private-note content. I also verified there was no H4/H3 restricted or legacy-performance language left in the client draft after cleanup.

No network access, external contact, or system update was performed.