# HH-FERN Protection-Needs Worksheet

Draft for human review. Audience: authorized advisor and protection specialist, with estate counsel copied as needed. Review date: 2026-09-17. Records are synthetic. This worksheet uses only `source_packet.json` and does not provide product recommendations, legal advice, tax advice, claims advice, underwriting guidance, or coverage interpretation.

## Calculation Basis

All scenarios are separate alternative events, not a concurrent joint-event model. [F5] The assumptions are USD, level and undiscounted; no inflation, discounting, probability, claims analysis, or coverage interpretation is requested. [F4] Designated resources exclude the insurance benefits already stated in the packet. [F6]

The RES-CASH amount of USD 50,000 is explicitly available separately for survivor and disability scenarios, but it is the same cash reserve, not two assets. [F6] Because scenarios are independent, this worksheet applies the USD 50,000 reserve separately in the survivor and disability rows and does not aggregate those uses across scenarios.

## Summary of Calculated Mismatches

| Scenario | Supplied need basis | Supplied applicable benefits/resources | Calculated net mismatch |
|---|---:|---:|---:|
| Survivor | USD 620,000 | USD 350,000 | USD 270,000 gap |
| Disability | USD 120,000 | USD 134,000 | USD 14,000 surplus before timing/friction review |
| Long-term care | USD 270,000 | USD 150,000 | USD 120,000 gap |
| Liability | USD 550,000 | USD 420,000 | USD 130,000 gap |

## Scenario 1: Survivor

Supplied assumptions: annual spending USD 90,000, annual survivor income USD 45,000, support period 10 years, debt payoff USD 150,000, one-time costs USD 20,000, and applicable life benefit USD 300,000. [F4] RES-CASH USD 50,000 is available for this scenario. [F6]

Calculation:

| Component | Amount |
|---|---:|
| Annual spending less survivor income: (90,000 - 45,000) x 10 years | USD 450,000 |
| Debt payoff | USD 150,000 |
| One-time costs | USD 20,000 |
| Total stated need | USD 620,000 |
| Applicable life benefit | USD 300,000 |
| Designated RES-CASH | USD 50,000 |
| Total stated benefits/resources | USD 350,000 |
| Calculated mismatch | USD 270,000 gap |

Questions / next owner:

| Question | Proposed owner |
|---|---|
| Confirm that the 10-year survivor support period and USD 45,000 annual survivor income are still the intended assumptions for meeting discussion. | Protection specialist |
| Confirm whether debt payoff and one-time costs are additive to annual spending need, as assumed in the worksheet. | Protection specialist/advisor |
| Identify whether any other resources are intentionally designated for survivor analysis; the packet lists no other designated resources but does not assert none exist. [F6] | Advisor |

## Scenario 2: Disability

Supplied assumptions: monthly spending USD 7,500, other income USD 2,500, duration 24 months, waiting period 3 months, and applicable monthly benefit USD 4,000. [F4] RES-CASH USD 50,000 is available for this scenario. [F6]

Calculation convention used for draft: the 24-month duration is treated as the total disability scenario period, and the monthly benefit is treated as payable for 21 months after the 3-month waiting period. This is a calculation assumption for meeting review, not a coverage interpretation.

| Component | Amount |
|---|---:|
| Monthly spending less other income: 7,500 - 2,500 | USD 5,000 |
| Total stated need over 24 months | USD 120,000 |
| Applicable monthly benefit: 4,000 x 21 months | USD 84,000 |
| Designated RES-CASH | USD 50,000 |
| Total stated benefits/resources | USD 134,000 |
| Calculated mismatch | USD 14,000 surplus |

Questions / next owner:

| Question | Proposed owner |
|---|---|
| Confirm whether the 24-month duration includes the 3-month waiting period or begins after it. | Protection specialist |
| Confirm whether the USD 4,000 monthly benefit should be modeled as available for exactly 21 months under these assumptions, without interpreting policy terms. | Protection specialist |
| Confirm whether timing matters for the first 3 months, since the arithmetic shows an overall surplus but may still have pre-benefit cash-flow pressure. | Protection specialist/advisor |
| Identify whether any other disability resources are intentionally designated; the packet lists no other designated resources but does not assert none exist. [F6] | Advisor |

## Scenario 3: Long-Term Care

Supplied assumptions: monthly care cost USD 9,000, duration 30 months, waiting period 3 months, applicable monthly benefit USD 6,000, benefit-month limit 24, and lifetime benefit cap USD 120,000. [F5] RES-LTC USD 30,000 is separately available for this scenario. [F6]

Calculation convention used for draft: gross care need is 30 months of care cost. Benefit is limited to the lesser of 24 months x USD 6,000 and the USD 120,000 lifetime cap; the cap binds.

| Component | Amount |
|---|---:|
| Gross care cost: 9,000 x 30 months | USD 270,000 |
| Benefit before cap: 6,000 x 24 months | USD 144,000 |
| Lifetime benefit cap | USD 120,000 |
| Applicable benefit used | USD 120,000 |
| Designated RES-LTC | USD 30,000 |
| Total stated benefits/resources | USD 150,000 |
| Calculated mismatch | USD 120,000 gap |

Questions / next owner:

| Question | Proposed owner |
|---|---|
| Confirm whether the waiting period affects timing only or changes the count of benefit-payable months under the supplied assumptions. | Protection specialist |
| Confirm that the USD 120,000 lifetime cap is intended to override the higher USD 144,000 monthly-benefit-times-limit result. | Protection specialist |
| Identify whether any other LTC resources are intentionally designated; the packet lists no other designated resources but does not assert none exist. [F6] | Advisor |

## Scenario 4: Liability

Supplied assumptions: projected loss USD 500,000 plus defense costs USD 50,000, applicable primary amount USD 100,000, applicable umbrella amount USD 300,000, and supplied applicability already reflects defense treatment. [F5] RES-LIAB USD 20,000 is separately available for this scenario. [F6]

Calculation:

| Component | Amount |
|---|---:|
| Projected loss | USD 500,000 |
| Defense costs | USD 50,000 |
| Total stated need | USD 550,000 |
| Applicable primary amount | USD 100,000 |
| Applicable umbrella amount | USD 300,000 |
| Designated RES-LIAB | USD 20,000 |
| Total stated benefits/resources | USD 420,000 |
| Calculated mismatch | USD 130,000 gap |

Questions / next owner:

| Question | Proposed owner |
|---|---|
| Confirm that defense cost treatment is already embedded in the supplied applicability figures and should not be reinterpreted. [F5] | Protection specialist |
| Confirm whether the projected loss and defense costs are additive for meeting discussion. | Protection specialist |
| Identify whether any other liability resources are intentionally designated; the packet lists no other designated resources but does not assert none exist. [F6] | Advisor |

## Missing Evidence and Review Limits

| Item | Packet status | Proposed owner |
|---|---|---|
| Policy contracts, riders, exclusions, claim definitions, tax treatment, and underwriting status | Not supplied; packet says no claims or coverage interpretation is requested. [F4] | Protection specialist |
| Confirmation of whether assumptions remain current after 2026-09-17 | Not supplied beyond current-through dates in sources. [F4], [F5], [F6] | Advisor/protection specialist |
| Other household resources outside designated resources | No other resources are designated; packet does not assert none exist. [F6] | Advisor |
| Interaction with estate-control issues | Estate gaps are described separately; no upstream unresolved artifact supplied apart from those estate gaps. [F6] | Advisor and estate counsel |
