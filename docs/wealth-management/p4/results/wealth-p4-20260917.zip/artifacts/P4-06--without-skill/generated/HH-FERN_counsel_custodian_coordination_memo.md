# HH-FERN Counsel/Custodian Coordination Memo

Draft for human review. Audience: authorized advisor, estate counsel, custodian liaison, and protection specialist. Review date: 2026-09-17. Records are synthetic. This memo uses only `source_packet.json` and does not provide legal drafting, legal conclusions, tax advice, coverage interpretation, or product recommendations.

## Scope and Evidence Standard

The packet contains source assertions from advisor/counsel coordination records and custodian liaison records. No original will, trust, power-of-attorney, healthcare directive, account agreement, beneficiary form, or custodian confirmation document was independently reviewed here. Treat the items below as coordination issues for verification, not as verified legal facts.

Estate review policy EW-F v1 requires current will, trust, power-of-attorney, healthcare-directive evidence, and primary/contingent schedules for the IRA comparison; it also states that differences should be literal record comparisons for counsel, not legal conclusions. [F3]

## Supplied Source Assertions

1. AdultF-A intends IRA-F to name spouseF-B as 100% primary beneficiary and childrenF-C/F-D as 50% each contingent. [F1]
2. Custodian liaison record states IRA-F currently has former spouseF-X as 100% primary beneficiary and childrenF-C/F-D as 60%/40% contingent, with one unique current designation DES-F3 recorded. [F2]
3. AdultF-A says BANK-F is intended to be owned by trustTR-F, but no transfer was requested; the current recorded BANK-F owner is F-A individually. [F1]
4. Custodian liaison record states BANK-F registration remains individual F-A, has no governing-document links, and no separate beneficiary designation was collected. [F2]
5. WillW-F v2 and trustTR-F v1 are listed as current, executed in 2024, and signed copies are in counsel's register. [F1]
6. A power-of-attorney is listed with unknown current status, and the healthcare directive was not collected. [F1]
7. No source states whether a will, trust, or account form legally controls any asset or designation. [F2]

## Concrete Mismatches for Meeting

### IRA-F Beneficiary Schedule

Source-stated intent: spouseF-B 100% primary; childrenF-C and F-D 50% each contingent. [F1]

Custodian-stated current record: former spouseF-X 100% primary; childrenF-C 60% and F-D 40% contingent; current designation DES-F3. [F2]

Coordination mismatch:

| Field | Source-stated intent | Custodian-stated current record | Mismatch |
|---|---:|---:|---|
| Primary beneficiary | spouseF-B 100% [F1] | former spouseF-X 100% [F2] | Primary person differs |
| Contingent F-C | 50% [F1] | 60% [F2] | Percentage differs |
| Contingent F-D | 50% [F1] | 40% [F2] | Percentage differs |
| Current designation identifier | Not supplied in intent record [F1] | DES-F3 [F2] | Need form/document verification |

Questions / next owner:

| Question | Proposed owner |
|---|---|
| Can custodian liaison provide the current IRA-F beneficiary designation image/form or equivalent confirmation for DES-F3? | Custodian liaison |
| Can counsel/advisor confirm whether AdultF-A's stated IRA-F intent remains current as of the meeting date? | Advisor with counsel present |
| If intent remains spouseF-B primary and children equal contingent, what custodian process and required authorization would be needed to align records? | Custodian liaison and advisor |
| Are there any divorce, spousal-consent, plan, IRA, or account-specific documents that affect who controls the designation? | Estate counsel |

### BANK-F Ownership / Governing Document Link

Source-stated intent: BANK-F should be owned by trustTR-F; no transfer was requested. [F1] Estate review policy also states the owner/document intention for BANK-F is TR-F, while beneficiary intention for the bank account remains uncollected. [F3]

Custodian-stated current record: BANK-F remains registered to F-A individually, has no governing-document links, and has no separate beneficiary designation collected. [F2]

Coordination mismatch:

| Field | Source-stated intent | Custodian-stated current record | Mismatch |
|---|---|---|---|
| Owner / registration | trustTR-F intended [F1], [F3] | F-A individually [F1], [F2] | Registration does not match stated intent |
| Transfer request | No transfer requested [F1] | No transfer evidence supplied [F2] | Process/action gap |
| Governing-document link | TR-F intended [F3] | No governing-document links [F2] | Link absent in custodian record |
| Bank beneficiary intention | Uncollected [F3] | No separate beneficiary designation collected [F2] | Intent and form status unknown |

Questions / next owner:

| Question | Proposed owner |
|---|---|
| Does counsel confirm trustTR-F ownership is still intended for BANK-F after reviewing WillW-F v2 and trustTR-F v1? | Estate counsel |
| What evidence is required to determine whether BANK-F should be retitled, linked, or otherwise coordinated with trustTR-F? | Estate counsel and custodian liaison |
| Does BANK-F support a beneficiary/POD/TOD designation, and has any such intent been gathered from AdultF-A? | Custodian liaison and advisor |
| Is there an account agreement, trust certification, transfer form, or internal registration requirement needed before any ownership change could be requested? | Custodian liaison |

### Core Estate Evidence Gaps

| Missing or unresolved item | Packet status | Why it matters for coordination | Proposed owner |
|---|---|---|---|
| Signed WillW-F v2 | Listed current, executed in 2024, signed copy in counsel's register [F1] | Required by review policy; not independently reviewed here [F3] | Estate counsel |
| Signed trustTR-F v1 | Listed current, executed in 2024, signed copy in counsel's register [F1] | Required by review policy; central to BANK-F stated ownership intent [F3] | Estate counsel |
| Power-of-attorney | Listed, current status unknown [F1] | Required by review policy [F3] | Estate counsel |
| Healthcare directive | Not collected [F1] | Required by review policy [F3] | Estate counsel/advisor |
| IRA-F primary/contingent source form | Custodian record summarized; underlying form not supplied [F2] | Needed to verify literal designation schedule and DES-F3 | Custodian liaison |
| BANK-F account form / ownership evidence | Registration summarized as F-A individual; no governing-document links [F2] | Needed to verify whether registration can or should be coordinated with TR-F | Custodian liaison |
| Legal control analysis | No source states whether a will, trust, or account form legally controls [F2] | Prevents legal conclusion from packet alone | Estate counsel |

## Meeting Agenda Draft

1. Confirm whether AdultF-A's stated IRA-F beneficiary intent remains spouseF-B 100% primary and childrenF-C/F-D 50% each contingent. [F1]
2. Compare that intent against custodian's current IRA-F record showing former spouseF-X 100% primary and childrenF-C/F-D 60%/40% contingent under DES-F3. [F2]
3. Determine what evidence and authorization are needed before any IRA-F record update can be requested.
4. Confirm whether trustTR-F ownership remains the intended treatment for BANK-F, given current individual registration and no transfer request. [F1], [F2], [F3]
5. Assign owners for missing estate evidence: signed will, signed trust, power-of-attorney current status, healthcare directive, IRA designation form, and BANK-F account/registration documentation. [F1], [F2], [F3]

## Non-Conclusions / Guardrails

This memo does not conclude who legally owns any asset, who is legally entitled to receive any asset, whether any document is valid, or whether a designation should be changed. The packet expressly states that no source identifies whether a will, trust, or account form legally controls. [F2]
