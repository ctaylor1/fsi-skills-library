Done. I prepared two source-grounded draft files:

- [HH-FERN_counsel_custodian_coordination_memo.md](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-1cnrr2pp/work/HH-FERN_counsel_custodian_coordination_memo.md)
- [HH-FERN_protection_needs_worksheet.md](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-1cnrr2pp/work/HH-FERN_protection_needs_worksheet.md)

I kept the estate memo focused on concrete counsel/custodian mismatches: IRA-F beneficiary intent vs current custodian record, and BANK-F trust-ownership intent vs individual registration/no document link. The worksheet keeps survivor, disability, LTC, and liability scenarios independent, cites F4-F6, and preserves timing/coverage ambiguities as meeting questions rather than interpretations.

Verification: read `source_packet.json` and `prompt.txt`, ran local arithmetic for the protection scenarios, and did a citation/wording pass. No network access, contacts, or system changes.