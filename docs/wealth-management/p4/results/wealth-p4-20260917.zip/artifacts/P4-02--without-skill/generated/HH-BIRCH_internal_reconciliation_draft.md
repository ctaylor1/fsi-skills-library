# HH-BIRCH Internal Reconciliation, Risk-Dimension Review, and Initial Goal-Funding Draft

Review date: 2026-09-17  
Audience: Advisor / planning team, for human review before client discussion  
Scope: Synthetic records only; USD household analysis for B-A/B-B. No external verification, no contacts, no system changes, no investment selection, and no risk rating.

## Executive Readiness View

The packet supports a bounded planning conversation, but not a final reconciled plan. Safe discussion topics include the confirmed account inventory framework, the duplicated JOINT-BANK treatment, the held-away nature and household share of EXT-BROKER, the HOME/MORTGAGE values supplied for planning, monthly cash-flow components, and goal scenarios using the packet's explicit 0% return and 0% inflation assumptions. [B1][B2][B3][B5]

Items that must be resolved before final planning outputs or risk-capacity conclusions:

- LEGACY-ACCOUNT has two current September 16 values, USD90,000 and USD95,000, with no controlling source. Carry a USD5,000 range until the source owner reconciles it. [B3][B6]
- HELD-AWAY-PENSION is expected but has no value, statement, or ownership allocation in the packet. Exclude it from totals and carry the dependency into risk and planning analysis. [B1][B3][B6]
- The provisional capacity assessment uses USD600,000 of investable assets and USD60,000 assessed loss capacity, but it predates reconciliation and must be revisited. [B4][B6]
- GP-1 has USD50,000 and USD10,000 reserved, while the goal worksheets assign USD30,000 to school and USD20,000 to renovation. Clarify whether the reserved amount is unavailable to goals or simply earmarked within the pool. [B5]

## Source Assertions vs Packet-Verified Treatment

This draft treats source contents as assertions unless they can be reconciled internally from the packet. No independent household reference total was supplied. [B1]

Packet-verified / internally reconciled treatments:

- JOINT-BANK is counted once at USD120,000. The bank statement and aggregator record are duplicate observations of one account, not two accounts. [B2]
- EXT-BROKER is held away and has a gross value of USD300,000 with a signed household allocation of 40%; the household balance-sheet value used here is USD120,000. The allocation record is not transfer authorization. [B3]
- LEGACY-ACCOUNT remains a range of USD90,000 to USD95,000 because neither same-date snapshot is designated controlling. [B3][B6]
- HELD-AWAY-PENSION is listed in expected assets but is not valued in this draft. [B1][B3][B6]

## Household Balance-Sheet Reconciliation

All amounts are household-share USD unless noted.

| Item | Packet assertion | Treatment in draft | Amount | Source |
| --- | --- | --- | ---: | --- |
| JOINT-BANK | Same account observed by BK-1 and AG-9; owned by B-A/B-B; not held away; September 16 value | Count once because observations are duplicates | 120,000 | [B2] |
| EXT-BROKER | Held away; gross value USD300,000; owners B-A and OUTSIDE-C; signed household share 0.40 | Include household share only; not transferable based on allocation record | 120,000 | [B3] |
| HOME | Planning valuation dated September 16; household share 1.0 | Include as supplied planning value | 600,000 | [B2] |
| LEGACY-ACCOUNT | Two current September 16 snapshots: USD90,000 and USD95,000; share 1.0 | Carry unresolved range | 90,000 to 95,000 | [B3][B6] |
| HELD-AWAY-PENSION | Expected asset | Exclude pending statement/value/allocation | Unknown | [B1][B3][B6] |
| MORTGAGE | Positive liability; September 16 balance; household share 1.0 | Include as liability | (200,000) | [B2] |

Calculated from the packet:

- Total known assets excluding HELD-AWAY-PENSION: USD930,000 to USD935,000. [B2][B3]
- Net worth excluding HELD-AWAY-PENSION: USD730,000 to USD735,000 after the USD200,000 mortgage. [B2][B3]
- Known investable assets before pension and before final reconciliation appear to be USD330,000 to USD335,000 if limited to JOINT-BANK, EXT-BROKER household share, and LEGACY-ACCOUNT. This is an internal planning range, not a final risk-capacity base. [B2][B3][B6]

## Risk-Dimension Review

No common ordinal risk category has been assigned in the packet, and this draft does not assign one. [B4]

Dimensions supported by the packet:

- Willingness: B-A recorded willingness to accept at most a 20% loss using questionnaire Q-W2 v2, administered by Imani under method record QA-22. The packet does not provide a corresponding B-B risk interview. [B4]
- Capacity: Professional assessment CA-4 provisionally uses USD600,000 investable assets and USD60,000 assessed loss capacity, but it predates reconciliation and needs confirmation. [B4][B6]
- Liquidity: USD40,000 available versus USD70,000 required within six months, creating a USD30,000 liquidity shortfall on the supplied evidence. [B4]
- Time horizon and lockup: Proposed exposure horizon is 24 months; the offered instrument has a 36-month lockup, a 12-month mismatch before considering any other liquidity needs. [B4]
- Scenario loss: The offered instrument has a supplied loss scenario of USD90,000, which exceeds the provisional USD60,000 assessed loss capacity by USD30,000. [B4]
- Experience/preferences: B-A has no private-credit experience, is experienced in listed equities, and requests no leverage. [B4]

Risk discussion boundary for advisor: These facts can be used to frame suitability questions and data gaps. They should not be used to recommend the offered instrument, select investments, or assign a household risk rating before reconciliation and capacity review are updated. [B4][B6]

## Initial Goal-Funding Analysis

Source assumptions: after-tax monthly income USD12,000; non-debt living expense USD7,000; reserve contribution USD500; zero-interest family loan payment USD1,000 monthly with no extra payment; goal returns 0%; inflation 0%; at-risk threshold 0.90; extension search 12 months. [B5]

Calculated cash flow:

- Monthly surplus before goal contributions: USD3,500.
- Assigned monthly goal contributions: USD2,500.
- Monthly surplus after assigned goal contributions: USD1,000.

Timing assumption for this draft: Target date is September 17, 2027, with month-end contributions. Assuming contributions from September 30, 2026 through August 31, 2027, there are 12 month-end contributions before the target. The packet does not explicitly define first/last contribution dates, so confirm this with the planning owner. [B5]

| Goal | Target | Assigned starting amount | Monthly contribution | Projected at target | Surplus / deficit | Funded ratio |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| G-SCHOOL | 50,000 | 30,000 | 1,500 | 48,000 | (2,000) | 0.96 |
| G-HOME | 30,000 | 20,000 | 1,000 | 32,000 | 2,000 | 1.07 |

Initial read: Under the supplied 0% return/inflation illustration and the 12-contribution timing assumption, G-SCHOOL is short by USD2,000 but remains above the supplied 0.90 at-risk threshold; G-HOME appears fully funded with USD2,000 surplus. This conclusion depends on the GP-1 reserve interpretation and contribution timing. [B5]

Important unresolved goal-pool point: GP-1 is stated as USD50,000 with USD10,000 reserved, yet the two goals are assigned the full USD50,000 combined. If the reserved USD10,000 is not available for these goals, the goal analysis must be rerun and the shortfall allocation cannot be inferred from the packet. [B5]

## What Can Safely Enter the Planning Conversation

Safe with caveats:

- Account inventory and ownership facts that are explicitly supplied, including JOINT-BANK, EXT-BROKER, HOME, LEGACY-ACCOUNT, HELD-AWAY-PENSION, and MORTGAGE. [B1][B2][B3]
- JOINT-BANK counted once at USD120,000, despite two records. [B2]
- EXT-BROKER household share value of USD120,000, with held-away and non-transfer caveats. [B3]
- Balance-sheet range excluding pension: net worth USD730,000 to USD735,000. [B2][B3]
- Cash-flow inputs and goal worksheet assumptions as scenario facts, not forecasts. [B5]
- Risk-dimension questions around liquidity, horizon/lockup, loss capacity, experience, and no-leverage preference. [B4]

Do not treat as resolved:

- Final legacy account value. [B3][B6]
- Pension value or ownership share. [B1][B3][B6]
- Final investable-asset base or loss capacity. [B4][B6]
- Final goal funding if GP-1's USD10,000 reserve is unavailable to goals. [B5]
- Household-level risk conclusion if only B-A's questionnaire is in the packet. [B4]

## Route / Handoff Plan

| Work item | Next owner | Action needed | Dependency / source |
| --- | --- | --- | --- |
| LEGACY-ACCOUNT value conflict | Source owner / custody operations, coordinated by planner Imani | Identify controlling September 16 value or provide reconciliation memo | Required for final balance sheet and dependent analyses [B3][B6] |
| HELD-AWAY-PENSION missing evidence | Planner Imani / advisor support | Obtain statement, value date, ownership/allocation, and whether held away | Required before final net worth or capacity analysis [B1][B3][B6] |
| Capacity assessment refresh | Planner Imani / risk-review owner | Recalculate investable base and assessed loss capacity after reconciliation | CA-4 predates reconciliation [B4][B6] |
| Risk-profile completeness | Advisor / planner Imani | Confirm whether B-B must complete risk questionnaire or consent workflow for household decisioning | Packet only records B-A willingness [B4] |
| Goal-pool reserve | Planning owner | Confirm whether GP-1's USD10,000 reserve is unavailable, earmarked, or already included in assignments | Required before final goal funding [B5] |
| Contribution timing | Planning owner / advisor | Confirm first and last month-end contributions before September 17, 2027 targets | Initial math assumes 12 contributions [B5] |
| Offered instrument discussion boundary | Advisor / supervisory review as applicable | Treat loss, lockup, horizon, liquidity, experience, and no-leverage facts as questions/gaps, not as a recommendation | No investment selection or risk rating in this draft [B4][B6] |

## Concise Client-Discussion Agenda

1. Confirm the household inventory: JOINT-BANK, EXT-BROKER, HOME, LEGACY-ACCOUNT, HELD-AWAY-PENSION, and MORTGAGE. [B1]
2. Explain the current balance-sheet range and unresolved items: legacy value conflict and missing pension evidence. [B3][B6]
3. Confirm cash flow: income, living expenses, reserve contribution, family-loan payment, and planned goal contributions. [B5]
4. Review GP-1 and goal priorities: whether the USD10,000 reserved amount can fund school/renovation, and whether contribution timing is correct. [B5]
5. Discuss risk dimensions without assigning a rating: liquidity gap, 24-month horizon versus 36-month lockup, supplied USD90,000 loss scenario, B-A's recorded willingness, experience, and no-leverage preference. [B4]
6. Agree on follow-ups and owners before any final planning conclusions: legacy reconciliation, pension documentation, refreshed capacity assessment, and any needed B-B risk documentation. [B4][B6]

## Calculation Notes

- EXT-BROKER household value: USD300,000 x 40% = USD120,000. [B3]
- Known assets excluding pension: USD120,000 JOINT-BANK + USD120,000 EXT-BROKER + USD600,000 HOME + USD90,000 to USD95,000 LEGACY = USD930,000 to USD935,000. [B2][B3]
- Net worth excluding pension: USD930,000 to USD935,000 less USD200,000 mortgage = USD730,000 to USD735,000. [B2][B3]
- Monthly cash flow after assigned goals: USD12,000 income - USD7,000 living expense - USD500 reserve contribution - USD1,000 family-loan payment - USD2,500 goal contributions = USD1,000. [B5]
- G-SCHOOL projected funding: USD30,000 + 12 x USD1,500 = USD48,000. [B5]
- G-HOME projected funding: USD20,000 + 12 x USD1,000 = USD32,000. [B5]
