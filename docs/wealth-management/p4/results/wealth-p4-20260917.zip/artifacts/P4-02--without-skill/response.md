Prepared the internal draft here: [HH-BIRCH_internal_reconciliation_draft.md](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-8cn4m_rn/work/HH-BIRCH_internal_reconciliation_draft.md:1)

Key outputs:
- Net worth range excluding missing pension: `USD730,000 to USD735,000`.
- Must-resolve items: LEGACY-ACCOUNT value conflict, missing HELD-AWAY-PENSION evidence, stale capacity assessment, GP-1 reserve ambiguity.
- Risk review is framed dimensionally only: no risk rating, no investment selection.
- Goal analysis uses the packet’s 0% return/inflation assumptions and flags the contribution timing and reserve dependency.

I also validated `source_packet.json` parses and ran local calculations. `git status` was not available because this workspace is not a git repository.