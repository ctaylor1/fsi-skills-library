# HH-GROVE July-August Managed Account Performance - Internal Draft

Review date: 2026-09-17  
Audience: advisor / performance owner review  
Scope: managed performance accounts PERF-A and PERF-B only. This draft does not include the separate BILL-A/B advisory billing group and is not a statement. [G1][G5]

Artifact: `wealth-performance-report-builder-cef359efc5613bdcc2dd`  
Input hash: `cef359efc5613bdcc2ddb2ab7c03b91ed885cc3ab2a0ec72e3d2dedf921c1c91`  
Calculator status: `review-ready`; human review still required.

## Source Assertions Used

G1 asserts the engagement is US advisory, USD, and limited to PERF-A and PERF-B for July 1 through August 31, 2026. It also asserts that all flows are valued at the listed boundaries, fees are at each subperiod end, the method is flow-boundary cumulative TWR, and the return tolerance is 1 bp. [G1]

G2 supplies the July ledger: PERF-A opened at $100,000, closed at $110,000, and had $100 of end fees; PERF-B opened at $50,000, closed at $55,000, and had $50 of end fees. All external and internal flow fields are asserted as zero. [G2]

G3 supplies the August ledger: PERF-A opened at $110,000, had a $20,000 external start flow and a $10,000 internal start outflow, closed at $126,000, and had $120 of end fees. PERF-B opened at $55,000, had a $10,000 internal start inflow, closed at $68,250, and had $65 of end fees. The $10,000 transfer is asserted to be between these two accounts, not a client deposit or withdrawal. [G3]

G4 supplies the official reference ending value of $194,250, official net cumulative return of 15.5%, and approved benchmark B-G v1 with July return of 8% and August return of 4%. [G4]

## Verified Calculation

The local calculator validated the input and output with no errors.

July household capital was $150,000 and July ending value was $165,000, with no flows. Net return was 10.000000%; adding the $150 of end fees for gross return gives 10.100000%. [G2]

August household capital was $185,000: $165,000 opening value plus $20,000 net external start flow, with the internal transfer offsetting at the household level. Ending value was $194,250 and end fees were $185. Net return was 5.000000%; gross return was 5.100000%. [G3]

Cumulative managed-scope net return was 15.500000%, calculated by linking July and August net factors: 1.10 x 1.05 - 1. Cumulative gross return was 15.715100%, calculated by linking the gross factors: 1.101 x 1.051 - 1. Observed fees across the period were $335 and observed net external flows were $20,000. [G1][G2][G3]

The calculated ending value of $194,250 matches the official reference exactly, and the calculated net return of 15.500000% matches the official 15.5% within the supplied 1 bp tolerance. [G4]

The benchmark return was 12.320000%, calculated as 1.08 x 1.04 - 1. Net performance less benchmark was +3.180000 percentage points. [G4]

Account-level cumulative returns:

| Account | Net return | Gross return | Status |
| --- | ---: | ---: | --- |
| PERF-A | 15.500000% | 15.715100% | Calculated |
| PERF-B | 15.500000% | 15.715100% | Calculated |

Household-level performance:

| Measure | Result |
| --- | ---: |
| Ending value | $194,250.00 |
| Net cumulative return | 15.500000% |
| Gross cumulative return | 15.715100% |
| Benchmark cumulative return | 12.320000% |
| Net less benchmark | +3.180000 percentage points |
| Observed fees | $335.00 |
| Observed net external flows | $20,000.00 |

## Missing Evidence, Exceptions, and Owner Question

No missing boundary valuation, flow, fee, continuity, official tie-out, or benchmark coverage issue was detected by the local calculator from the supplied records. This is a calculation-readiness result, not professional approval.

Question for Jordan / performance owner: Please confirm that B-G v1 remains the final approved benchmark for this exact managed-account scope, PERF-A and PERF-B only, before any reviewed performance is reused in a client-review pack. [G1][G4]

## Evidence and Review Record

Sources reviewed: G1, G2, G3, and G4. Source records are synthetic and establish traceability for this draft, not source truth or approval.

No action was taken, no statement was prepared or sent, and no annualization, attribution, money-weighted return, or GIPS assertion is made. [G1]
