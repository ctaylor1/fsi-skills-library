# HH-GROVE July Advisory Billing - Internal Draft

Review date: 2026-09-17  
Audience: advisor / billing owner review  
Scope: separate advisory billing group BILL-A and BILL-B only. This draft does not include managed performance accounts PERF-A/PERF-B and is not a statement. [G5]

Artifact: `advisory-fee-reviewer-653efc2306d4d4c218e8`  
Input hash: `653efc2306d4d4c218e8bfb85c18b0e17b630891847a2e36aca315238ddea7a3`  
Calculator status: `needs-data` due to an assessed-versus-expected fee variance.

## Source Assertions Used

G5 asserts the July billing group contains BILL-A and BILL-B only, not the two performance accounts. It also asserts July 1 through July 31, 2026 is one constant valuation segment using actual/365 day count, a marginal schedule of 100 bps on the first $1,000,000 and 50 bps above that, no period minimum, and no minimum at zero. [G5]

G5 asserts BILL-A has $900,000 of eligible investments and $100,000 of cash explicitly excluded under the agreement, for a reported total of $1,000,000. G5 also asserts BILL-B has $300,000 of eligible investments and a reported total of $300,000. No unknown fee eligibility or other exclusion is reported. [G5]

G6 asserts the assessed-charge register is complete, with a $650 BILL-A charge and a $250 BILL-B charge. It also asserts a $50 agreement-supported credit applies after the minimum and has not already been netted in the assessed charges. [G6]

G6 asserts Kai completed a conflict review on September 16 under reference CF-G2 and recorded no identified items. This is an attributed source assertion, not legal assurance. [G6]

## Verified Calculation

The local calculator validated the input and output with no schema or reconstruction errors.

Billable household assets were $1,200,000: $900,000 from BILL-A plus $300,000 from BILL-B. The excluded BILL-A cash was not billable because the agreement source explicitly excludes it. [G5]

Annual marginal fee was $11,000: $1,000,000 at 100 bps equals $10,000, plus $200,000 at 50 bps equals $1,000. [G5]

The July inclusive period has 31 days. Using actual/365, the unadjusted period fee was $934.25 after rounding once: $11,000 x 31 / 365. The period minimum was $0.00. Applying the $50 credit after the minimum produced an expected household fee of $884.25. [G5][G6]

Assessed charges totaled $900.00: $650.00 for BILL-A plus $250.00 for BILL-B. Assessed less expected equals +$15.75, so the draft remains `needs-data` pending billing-owner reconciliation. [G6]

Billing calculation summary:

| Measure | Result |
| --- | ---: |
| BILL-A reported total | $1,000,000.00 |
| BILL-A billable assets | $900,000.00 |
| BILL-B reported total | $300,000.00 |
| BILL-B billable assets | $300,000.00 |
| Household billable assets | $1,200,000.00 |
| Annual marginal fee | $11,000.00 |
| Unadjusted July fee | $934.25 |
| Minimum fee | $0.00 |
| Credit / adjustment | -$50.00 |
| Expected household fee | $884.25 |
| Assessed charges | $900.00 |
| Assessed less expected | +$15.75 |

## Exceptions, Missing Evidence, and Owner Question

Exception: The assessed register is complete according to G6, and assessed charges exceed the recalculated expected household fee by $15.75. The calculator finding is `fee-variance`; no refund, invoice posting, or system change is authorized. [G6]

Question for Kai / billing owner: Please adjudicate the $15.75 variance. If another July billing rule, proration convention, allocation rule, or adjustment applies, provide the cited agreement or billing record; otherwise confirm whether the assessed charges need correction. [G5][G6]

No missing asset eligibility, valuation tie-out, account-coverage, billing-register-completeness, or conflict-review attribution issue was detected from the supplied records. This does not validate how the household fee was allocated between BILL-A and BILL-B. [G5][G6]

## Evidence and Review Record

Sources reviewed: G5 and G6. Source records are synthetic and establish traceability for this draft, not source truth or approval.

No action was taken, no charge or refund was posted, no statement was prepared or sent, and no compliance or legal conclusion is made.
