Prepared two separate internal drafts:

- [Performance draft](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-kaz4b2gi/work/reports/hh_grove_july_august_performance_internal_draft.md)
- [Billing draft](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-kaz4b2gi/work/reports/hh_grove_july_advisory_billing_internal_draft.md)

I also saved the normalized inputs and validated calculator outputs under `artifacts/`.

Verification completed:
- Performance input/output validators: no errors
- Billing input/output validators: no errors
- Performance result: `review-ready`, net cumulative return `15.500000%`, benchmark spread `+3.180000` percentage points
- Billing result: `needs-data`, assessed charges exceed recalculated expected fee by `$15.75`

No statement was sent, no system was changed, and the two account scopes were kept separate.