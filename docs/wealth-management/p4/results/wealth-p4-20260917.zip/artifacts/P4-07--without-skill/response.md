Done. I prepared two separate internal draft reports plus a reproducible calculation script:

- [Performance draft](</private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-hf00oa_2/work/hh_grove_performance_jul_aug_2026_draft.md:1>) for PERF-A/PERF-B only.
- [Billing draft](</private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-hf00oa_2/work/hh_grove_billing_july_2026_draft.md:1>) for BILL-A/BILL-B only.
- [Calculation script](</private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-hf00oa_2/work/hh_grove_calculations.py:1>) with the local arithmetic.

Key outputs:
- Performance: net cumulative return `15.5000%`, matching the official reference; benchmark cumulative `12.3200%`; net excess `3.1800` percentage points.
- Billing: agreement-based expected invoice after credit `$884.25`; assessed-register amount after credit `$850.00`; difference `-$34.25`, flagged for Kai.

I kept the scopes separate, cited source IDs in the drafts, preserved missing evidence/unknowns, and did not contact anyone or change any system.