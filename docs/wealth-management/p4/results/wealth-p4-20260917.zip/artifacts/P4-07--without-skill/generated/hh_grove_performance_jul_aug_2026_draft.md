# HH-GROVE Internal Performance Draft

Review date: 2026-09-17
Audience: Advisor / internal performance review
Scope: Managed performance accounts PERF-A and PERF-B only. This draft does not cover the separate BILL-A/BILL-B advisory billing group.

## Source Assertions Used

- The supplied engagement method says the managed performance scope is PERF-A and PERF-B only, USD, July 1 through August 31, 2026, using flow-boundary time-weighted net and gross cumulative returns, not annualized or money-weighted returns. It also says fees occur at each subperiod end, ending values already deduct fees, internal flows offset across the two-account scope, and no attribution or GIPS assertion is requested. [G1]
- The July ledger says PERF-A opened at $100,000 and closed at $110,000 with $100 in end fees, and PERF-B opened at $50,000 and closed at $55,000 with $50 in end fees. It also says external and internal flows at start and end were zero for both accounts, with no missing boundary or midperiod flow reported. [G2]
- The August ledger says PERF-A opened at $110,000, had a $20,000 external start flow and a -$10,000 internal start flow, ended at $126,000, and had $120 in end fees. It says PERF-B opened at $55,000, had no external start flow and a +$10,000 internal start flow, ended at $68,250, and had $65 in end fees. It also says the transfer was between the two accounts and not a client withdrawal or deposit. [G3]
- The official performance reference gives managed ending value of $194,250 and net cumulative return of 15.5%. It identifies benchmark B-G v1 as applicable to this managed scope, with July return of 8% and August return of 4%, and says the client requested a cumulative comparison with no annualization. [G4]

## Verified Calculations

July managed opening value was $150,000 and July managed ending value was $165,000. Because the July source reports no flows, July net return is $165,000 / $150,000 - 1 = 10.0000%. Gross return adds back the $150 of end fees: ($165,000 + $150) / $150,000 - 1 = 10.1000%. [G1][G2]

August managed opening value was $165,000. The $20,000 external start flow increases August capital, while the -$10,000 and +$10,000 internal transfer nets to zero at this two-account managed scope. August capital is therefore $185,000. August net return is $194,250 / $185,000 - 1 = 5.0000%. Gross return adds back $185 of end fees: ($194,250 + $185) / $185,000 - 1 = 5.1000%. [G1][G3]

Time-weighted cumulative net return for July through August is (1 + 10.0000%) x (1 + 5.0000%) - 1 = 15.5000%. This reconciles to the official performance reference of 15.5% and the $194,250 managed ending value. [G1][G3][G4]

Time-weighted cumulative gross return for July through August is (1 + 10.1000%) x (1 + 5.1000%) - 1 = 15.7151%. This is a calculation from supplied ledger values and fees; no independent official gross cumulative reference was supplied. [G1][G2][G3]

Benchmark cumulative return is (1 + 8.0000%) x (1 + 4.0000%) - 1 = 12.3200%. Managed net performance exceeded the benchmark by 3.1800 percentage points for the cumulative period. [G4]

## Draft Advisor Explanation

For the managed HH-GROVE performance scope, the July-August net cumulative return is 15.5%, matching the official reference. July return was 10.0% because the two accounts rose from $150,000 to $165,000 with no reported flows. August return was 5.0% because the two-account scope began August at $165,000, received a $20,000 external start flow, and ended at $194,250. The August internal transfer between PERF-A and PERF-B nets to zero for this combined managed scope and is not treated as a client deposit or withdrawal.

Against benchmark B-G v1, which the supplied official record identifies as applicable, the managed net cumulative return of 15.5% compares with a benchmark cumulative return of 12.32%, or +3.18 percentage points. The gross cumulative return calculated from the supplied fees is 15.7151%, but the packet provides an official net return reference only.

## Missing Evidence, Questions, and Next Owner

- Performance owner: Jordan. [G1][G4]
- Question for Jordan: Should the draft show the calculated gross cumulative return of 15.7151% when the official independent reference supplied only the net cumulative return, or should the advisor-facing discussion stay to net return plus benchmark comparison?
- Missing evidence: no account-level attribution, GIPS assertion, or official gross cumulative reference was supplied. The method source says no attribution or GIPS assertion was requested. [G1]
- No statement should be sent from this draft.
