# HH-GROVE Internal Advisory Billing Draft

Review date: 2026-09-17
Audience: Advisor / internal billing review
Scope: July advisory billing for billing group BILL-A and BILL-B only. This draft does not cover managed performance accounts PERF-A and PERF-B.

## Source Assertions Used

- The supplied billing agreement says the separate billing group contains BILL-A and BILL-B only, not the two performance accounts. It says July 1 through July 31 inclusive uses one constant valuation segment, actual/365 day basis, and marginal tiers of 100 bps on the first $1,000,000 and 50 bps above, with a final unbounded tier. It also says the period minimum is zero and does not apply at zero. [G5]
- The supplied asset scope says BILL-A has $900,000 of eligible investments plus $100,000 of cash explicitly excluded under the agreement, with reported total of $1,000,000. BILL-B has $300,000 of eligible investments. It reports no unknown fee eligibility or other exclusions. [G5]
- The supplied invoice and credit record says the complete assessed-charge register is BILL-A $650 and BILL-B $250. It says an agreement-supported $50 credit is applied after the minimum to calculate the expected invoice and has not already been netted in assessed charges. It also says Kai's September 16 conflict review identified no items under review reference CF-G2, but this is an attributed record and not legal assurance. Kai must adjudicate any difference, and no refund or invoice posting is authorized. [G6]

## Verified Calculations

Eligible billing assets are $1,200,000: BILL-A $900,000 eligible investments plus BILL-B $300,000 eligible investments. BILL-A's $100,000 cash is excluded under the agreement and is not included in this fee base. [G5]

The annual tiered advisory fee on $1,200,000 is $11,000: 100 bps on the first $1,000,000 equals $10,000, and 50 bps on the remaining $200,000 equals $1,000. [G5]

The July gross expected charge is $11,000 x 31 / 365 = $934.25 on an actual/365 basis for July 1 through July 31 inclusive. The $50 agreement-supported credit is applied after the minimum, so the expected invoice after credit is $934.25 - $50.00 = $884.25. [G5][G6]

The assessed-charge register totals $900.00 before credit: BILL-A $650 plus BILL-B $250. Because the source says the $50 credit has not already been netted in those assessed charges, the assessed amount after credit would be $850.00. [G6]

The assessed charges are $34.25 lower than the agreement-based calculation, both before and after applying the $50 credit: $900.00 - $934.25 = -$34.25, and $850.00 - $884.25 = -$34.25. [G5][G6]

## Draft Advisor Explanation

For the separate HH-GROVE July advisory billing group, the agreement-based calculation uses BILL-A and BILL-B only. It excludes BILL-A's $100,000 cash and includes $1,200,000 of eligible investments. Applying the stated marginal annual rates gives an annual fee of $11,000. Prorating that amount for 31 days on an actual/365 basis gives a gross July expected charge of $934.25. After the $50 agreement-supported credit, the expected invoice would be $884.25.

The supplied assessed-charge register totals $900 before the credit and $850 after applying the same credit. That is $34.25 below the agreement-based calculation. The packet does not provide enough evidence to decide whether this is an assessment error, a missing billing rule, a timing issue, or another billing-owner adjustment.

## Missing Evidence, Questions, and Next Owner

- Billing owner: Kai. [G5][G6]
- Question for Kai: Please adjudicate the $34.25 difference between the agreement-based July expected invoice of $884.25 and the assessed-register post-credit amount of $850.00. Is there a missing billing rule or adjustment, or should the assessed charges be corrected?
- Missing evidence: no unresolved upstream artifact is supplied, and the conflict review is an attributed record rather than legal assurance. The packet does not provide a separate allocation rule for applying marginal tiers across BILL-A and BILL-B, so this draft calculates the group-level expected invoice only. [G6]
- No refund, invoice posting, client contact, or statement should be initiated from this draft. [G6]
