from decimal import Decimal, ROUND_HALF_UP, getcontext

getcontext().prec = 28


def pct(value: Decimal) -> str:
    return f"{(value * Decimal('100')).quantize(Decimal('0.0001'))}%"


def money(value: Decimal) -> str:
    cents = value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    if cents < 0:
        return f"-${abs(cents):,.2f}"
    return f"${cents:,.2f}"


def main() -> None:
    # HH-GROVE performance scope: PERF-A and PERF-B only.
    july_open = Decimal("100000") + Decimal("50000")
    july_end = Decimal("110000") + Decimal("55000")
    july_fees = Decimal("100") + Decimal("50")

    august_open = july_end
    august_external_start = Decimal("20000")
    august_internal_start_net = Decimal("-10000") + Decimal("10000")
    august_capital = august_open + august_external_start + august_internal_start_net
    august_end = Decimal("126000") + Decimal("68250")
    august_fees = Decimal("120") + Decimal("65")

    net_july = july_end / july_open - 1
    gross_july = (july_end + july_fees) / july_open - 1
    net_august = august_end / august_capital - 1
    gross_august = (august_end + august_fees) / august_capital - 1
    net_cumulative = (1 + net_july) * (1 + net_august) - 1
    gross_cumulative = (1 + gross_july) * (1 + gross_august) - 1
    benchmark_cumulative = Decimal("1.08") * Decimal("1.04") - 1

    print("HH-GROVE managed performance, PERF-A/PERF-B")
    print(f"July net: {pct(net_july)}")
    print(f"July gross: {pct(gross_july)}")
    print(f"August capital: {money(august_capital)}")
    print(f"August net: {pct(net_august)}")
    print(f"August gross: {pct(gross_august)}")
    print(f"Net cumulative: {pct(net_cumulative)}")
    print(f"Gross cumulative: {pct(gross_cumulative)}")
    print(f"Benchmark cumulative: {pct(benchmark_cumulative)}")
    print(f"Net excess return: {pct(net_cumulative - benchmark_cumulative)}")
    print()

    # HH-GROVE billing scope: BILL-A and BILL-B only.
    eligible_assets = Decimal("900000") + Decimal("300000")
    annual_fee = Decimal("1000000") * Decimal("0.0100")
    annual_fee += (eligible_assets - Decimal("1000000")) * Decimal("0.0050")
    period_fee = annual_fee * Decimal("31") / Decimal("365")
    assessed_charges = Decimal("650") + Decimal("250")
    credit = Decimal("50")
    expected_invoice = period_fee - credit
    assessed_after_credit = assessed_charges - credit
    difference = assessed_after_credit - expected_invoice

    print("HH-GROVE July advisory billing, BILL-A/BILL-B")
    print(f"Eligible assets: {money(eligible_assets)}")
    print(f"Annual tiered fee: {money(annual_fee)}")
    print(f"July gross expected charge: {money(period_fee)}")
    print(f"Agreement-supported credit: {money(credit)}")
    print(f"Expected invoice after credit: {money(expected_invoice)}")
    print(f"Assessed charges after credit: {money(assessed_after_credit)}")
    print(f"Difference, assessed less expected: {money(difference)}")


if __name__ == "__main__":
    main()
