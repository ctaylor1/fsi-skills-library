Prepared the draft review here: [hh-elm_transition_review_draft.md](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-ayp_mymz/work/hh-elm_transition_review_draft.md:1)

Key takeaways captured in the draft:

- Proposed trades are not operationally clean due to a USD 2,010 interim cash deficit: NEW-Y buy settles 2026-09-18, LOSS-X sale settles 2026-09-21.
- After both proposed settlements, cash calculates to USD 980 and proposed positions are 40 LOSS-X / 150 NEW-Y.
- Proposed LOSS-X sale calculates to a USD 1,200 supplied long-term loss before tax adjustments.
- Tax handoff flags the spouse IRA 20-share LOSS-X reinvestment, missing held-away spouse statement, incomplete forward-window review, and unresolved NEW-Y substantial-identity question.

I used only `source_packet.json`, kept source assertions separate from calculated facts, and cited source IDs throughout.