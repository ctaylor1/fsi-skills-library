# HH-ELM Proposed Transition Review Draft

Review date: 2026-09-17  
Audience: advisor, trading reviewer, tax liaison  
Scope: proposed transactions only; no fills, no trade submission, no tax return conclusion, no external contact or system change.

## Executive Draft Conclusion

The proposed HH-ELM transition for taxable account TAX-ELM appears directionally consistent with the supplied target weights after both proposed trades settle, but it has an unresolved settlement sequencing problem: the NEW-Y buy settles on 2026-09-18 while the LOSS-X sale proceeds do not settle until 2026-09-21, and the packet supplies no credit facility, prefunding, pending deposit or settlement guarantee. The calculated interim cash deficit is USD 2,010. This issue is already logged as unresolved and owned by Ellis for settlement evidence. [E1][E2][E5]

Tax liaison review is also required before treating the proposed LOSS-X sale as an available tax loss. The proposed sale would realize a supplied long-term USD 1,200 loss from lot LX1 before wash-sale or other tax adjustments. However, the spouse IRA-ELM purchased 20 shares of LOSS-X on 2026-09-10, future orders have not been fully reviewed, a held-away spouse account statement has not been obtained, and no human decision has been supplied on whether NEW-Y is substantially identical to LOSS-X. [E2][E3][E4]

## Source Assertions Relied On

| Area | Supplied source assertion |
|---|---|
| Account snapshot | TAX-ELM is a USD taxable advisory account with USD 1,000 settled cash, 100 shares of LOSS-X at USD 50, reported market value USD 5,000, and total portfolio USD 6,000. [E1] |
| Lot inventory | LOSS-X has one taxable lot, LX1, acquired 2024-01-02, 100 shares, total basis USD 7,000; holdings/lots are described as complete. [E1] |
| Target/policy | TARGET-E2 v2 assigns LOSS-X 40%, NEW-Y 50%, cash 10%; buy/sell are permitted for both supplied securities; quantity increment is 1; fixed fee is USD 10 per trade; transaction-cost reserve is USD 20. [E1] |
| Proposed trades | Proposed instruction is validate mode with specified lots, trade date 2026-09-17: sell 60 LOSS-X at USD 50 from LX1 with USD 10 fee, settlement 2026-09-21; buy 150 NEW-Y at USD 20 with USD 10 fee, settlement 2026-09-18. [E2] |
| Settlement policy | Same-day netting is supplied; no credit facility, prefunding or pending deposit is supplied. [E2] |
| Replacement activity | Applicable accounts reviewed are TAX-ELM and spouse IRA-ELM; IRA-ELM executed a 20-share LOSS-X dividend reinvestment on 2026-09-10; no other executed or proposed replacement purchases appear in reviewed history 2026-08-18 through 2026-09-17. [E3] |
| Tax scenario | LOSS-X unit basis is USD 70, unit price is USD 50, tax term is explicitly long, and supplied potential-equivalence group GX contains LOSS-X only. [E4] |
| Open issues | Transition issue TRANSITION-ELM-2 is unresolved: "Buy settles before the proposed sale; no bridge funding evidence supplied." Ellis owns settlement evidence; Francis owns cross-account and forward-window completion. [E5] |

## Verified Calculations From Packet Data

| Item | Calculation | Result |
|---|---:|---:|
| Starting settled cash | Supplied | USD 1,000 [E1] |
| LOSS-X sale gross proceeds | 60 x USD 50 | USD 3,000 [E2] |
| LOSS-X sale net cash on 2026-09-21 | USD 3,000 - USD 10 fee | USD 2,990 [E2] |
| NEW-Y buy cash required on 2026-09-18 | 150 x USD 20 + USD 10 fee | USD 3,010 [E2] |
| Cash after 2026-09-18 buy before sale settlement | USD 1,000 - USD 3,010 | USD -2,010 [E1][E2] |
| Cash after both proposed trades settle | USD 1,000 - USD 3,010 + USD 2,990 | USD 980 [E1][E2] |
| Proposed ending LOSS-X position | 100 - 60 | 40 shares [E1][E2] |
| Proposed ending NEW-Y position | 0 + 150 | 150 shares [E2] |
| Proposed gross quote value after trades | 40 x USD 50 + 150 x USD 20 + USD 980 cash | USD 5,980 [E1][E2] |
| Proposed realized tax result before tax adjustments | 60 x (USD 50 - USD 70) | USD 1,200 loss, supplied long-term [E2][E4] |
| Remaining LX1 basis if specified-lot sale is accepted | 40 x USD 70 | USD 2,800 [E1][E2][E4] |

## Cash, Position, Lot and Policy Review

### Proposed Cash

Final cash after both proposed settlements calculates to USD 980. This is above the supplied minimum cash of USD 0 and above the target cash dollar amount implied by the original USD 6,000 portfolio and 10% cash target, but the interim 2026-09-18 buy settlement creates a USD 2,010 funding gap unless bridging evidence is supplied. [E1][E2][E5]

The proposed fixed fees total USD 20, matching the explicit USD 20 transaction-cost reserve. No proportional fee is supplied. [E1][E2]

### Proposed Positions

Using post-trade quote values net of the proposed fees, proposed ending weights calculate to approximately LOSS-X 33.44%, NEW-Y 50.17%, and cash 16.39% on USD 5,980. Compared with target weights of LOSS-X 40%, NEW-Y 50%, and cash 10%, the calculated drifts are approximately -6.56 percentage points, +0.17 percentage points, and +6.39 percentage points, respectively. These are within the supplied 20 percentage point drift tolerance. [E1][E2]

The proposed order gross values are USD 3,000 for the LOSS-X sale and USD 3,000 for the NEW-Y buy, each below the supplied USD 10,000 maximum order value. The proposed quantity increments are whole shares, consistent with the supplied quantity increment of 1. [E1][E2]

The proposed sale is 60 of 100 current LOSS-X shares. This equals 60% of the current LOSS-X share position; the packet supplies "sell turnover 60%" but does not further define the denominator for turnover review. [E1][E2]

### Proposed Lot Impact

The instruction specifies selling 60 LOSS-X shares from taxable lot LX1. LX1 is supplied as 100 shares acquired 2024-01-02 with USD 7,000 total basis, and the tax scenario supplies USD 70 unit basis and USD 50 unit price. Before tax adjustments, the proposed 60-share sale calculates to a USD 1,200 long-term loss. If the specified-lot sale is accepted as proposed, 40 LOSS-X shares remain in LX1 with calculated remaining basis of USD 2,800. [E1][E2][E4]

This is a proposed transaction, not a fill. The packet supplies no execution authority. [E2]

## Settlement Review

The settlement sequence is not currently supportable from the packet. The proposed NEW-Y buy settles 2026-09-18 and requires USD 3,010, while the proposed LOSS-X sale settles 2026-09-21 and contributes USD 2,990. Starting settled cash is only USD 1,000. The packet expressly states that no credit facility, prefunding or pending deposit is supplied, and the issue log states that no bridge funding evidence is supplied. [E1][E2][E5]

Trading-review draft status: hold for settlement evidence or revised sequencing. Next owner: Ellis, per issue log. [E5]

## Tax-Aware Handoff

### Loss and Gain Facts for Tax Professional

The proposed LOSS-X sale produces a calculated USD 1,200 loss before tax adjustments, based on 60 shares sold at USD 50 against supplied USD 70 unit basis. The tax term is supplied as long; no law-based term inference is requested. No positive gain is produced by the proposed sale in the supplied scenario. [E2][E4]

The packet supplies illustrative positive-gain rates of 20% long and 35% short, a USD 5,000 gain budget, a USD 1,000 tax-reserve budget, and a maximum quote age of 2 days. Because the proposed sale calculates as a loss before tax adjustments, this draft does not apply those positive-gain rates or budgets to produce a tax reserve conclusion. [E2][E4]

No tax-loss benefit, deductible amount or basis adjustment has been determined in the packet. Those conclusions should remain with the tax professional. [E4]

### Replacement-Purchase Facts Requiring Tax Review

The spouse IRA-ELM purchased 20 LOSS-X shares through dividend reinvestment on 2026-09-10. That purchase is within 30 days before the proposed 2026-09-17 sale date and involves the same security, LOSS-X. The packet identifies TAX-ELM and spouse IRA-ELM as applicable accounts reviewed, but it also states that a held-away spouse account statement has not been obtained and future orders have not been fully reviewed. [E2][E3][E4]

NEW-Y is proposed for purchase on 2026-09-17 with settlement 2026-09-18, but the packet supplies no NEW-Y equivalence mapping, and the human reviewer has not decided whether NEW-Y is substantially identical to LOSS-X. The supplied potential-equivalence group GX contains LOSS-X only. This fact pattern should be escalated to the tax professional before relying on the proposed LOSS-X loss. [E2][E3][E4]

Tax liaison draft status: incomplete for wash-sale and related replacement-purchase clearance. Next owner: Francis for cross-account and forward-window completion, per issue log. [E5]

## Missing Evidence and Next Owners

| Missing or unresolved item | Why it matters | Next owner |
|---|---|---|
| Bridge funding, prefunding, credit facility, pending deposit or revised trade sequencing | Buy settlement on 2026-09-18 creates a calculated USD 2,010 cash deficit before the sale settles on 2026-09-21. [E1][E2][E5] | Ellis [E5] |
| Held-away spouse account statement | Packet states this has not been obtained; replacement-purchase review is therefore incomplete. [E3] | Francis [E5] |
| Forward-window review after 2026-09-17 | Future orders have not been fully reviewed; potential replacement purchases after the proposed sale may affect tax treatment. [E3] | Francis [E5] |
| Tax professional determination on IRA-ELM LOSS-X reinvestment impact | Spouse IRA-ELM bought 20 LOSS-X shares on 2026-09-10 before the proposed LOSS-X loss sale. [E2][E3][E4] | Tax professional via Francis |
| Tax professional determination on whether NEW-Y is substantially identical to LOSS-X | NEW-Y equivalence mapping is not supplied and no human decision has been made. [E3][E4] | Tax professional via Francis |
| Execution authority / trade approval evidence | Proposed instruction is validate mode and no execution authority is included. [E2] | Advisor / trading reviewer |

## Draft Review Disposition

Do not treat this draft as approval to trade. For advisor and trading review, the proposal needs settlement support or revised sequencing before it is operationally clean. For tax liaison review, the proposal needs tax-professional analysis of the 2026-09-10 spouse IRA LOSS-X purchase, any missing held-away spouse activity, the post-sale forward window, and the unresolved NEW-Y substantial-identity question before the proposed LOSS-X loss is relied upon. [E2][E3][E4][E5]
