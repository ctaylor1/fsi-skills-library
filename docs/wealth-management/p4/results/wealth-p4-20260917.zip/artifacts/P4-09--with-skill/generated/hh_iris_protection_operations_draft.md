# HH-IRIS Protection Review and Operations Draft

Audience: authorized protection reviewer and operations only. Synthetic records. Review as of 2026-09-17. Draft only: no diagnosis, account restriction, hold, filing, contact, submission, money movement or system change has occurred.

## 1. Protection Review First

Artifact: `senior-investor-protection-screener-ba3e9fb666045258b7fc`  
Input hash: `ba3e9fb666045258b7fc59db1aa9c146008e575479eb830a0fadb6c989225a13`  
Status: `needs-data`; human review required; action taken: false; delivery: not delivered.

### Source-asserted context

- HH-IRIS is a US brokerage relationship. AdultI-A is age 72 and owns individual account AC-IRIS. The account record asserts USD 25,000 settled cash and an empty supplied holdings schedule. RelativeI-N is not recorded as an owner or authorized person. Trusted-contact information was offered and declined on 2026-09-10. No impairment determination was supplied. [I1]
- DIST-18 is an unsubmitted proposed USD 18,000 cash distribution to masked new external payee PAY-NEW for "urgent family assistance"; the requested tax instruction reference is missing; signed authority is missing; destination confirmations conflict. [I2]
- Bounded 30-day history from 2026-08-19 through 2026-09-17 is asserted complete. Executed debits in that lookback were USD 1,000 on 2026-09-02, USD 1,200 on 2026-09-08 and USD 800 on 2026-09-10, all to PAY-REG. DIST-18 is active proposed activity, not executed or pending settlement. TR-10 is a separate proposed service request and is not recorded as executed. A beneficiary-change request occurred 2026-09-15; legal validity was not assessed. [I4]
- Observed call notes state RelativeI-N repeatedly answered questions directed to AdultI-A, and AdultI-A said, "I was told this must happen today and not to tell the rest of the family." Analyst flags recorded: third-party influence=true, urgency=true, secrecy=true. Confusion, recall and repetition observations were not assessed. No one diagnosed incapacity or established exploitation. [I5]
- SCR-I v4 is the supplied brokerage US screening configuration: 30-day lookback, k=3 population standard deviations, minimum baseline 3, new-payee threshold USD 5,000, recent executed-outflow threshold USD 10,000 over 7 days, account-change window 30 days, trusted-contact recency 365 days. The source states third-party or communication concerns independently warrant escalation to the authorized reviewer and that trusted-contact gap is administrative and excluded from concern counts. [I6]

### Locally calculated screening results

- Unusual disbursement fired. The validated local artifact calculated pre-focal executed debit baseline n=3, mean USD 1,000, population stdev about USD 163.30 and threshold about USD 1,489.90; the proposed USD 18,000 DIST-18 debit exceeds that threshold. This is a comparison to bounded history, not proof the request executed. [I2][I4][I6]
- New external payee fired. PAY-NEW is absent from the supplied pre-focal lookback baseline, which only shows PAY-REG. This is not a lifetime novelty claim. [I2][I4][I6]
- Account or beneficiary change fired because a sourced beneficiary-change request dated 2026-09-15 is within the configured 30-day window and coincides with the proposed focal debit. Validity of that beneficiary request was not assessed. [I4][I6]
- Third-party influence fired based on analyst-recorded third-party influence=true and RelativeI-N answering questions directed to AdultI-A. [I5][I6]
- Communication red flags fired based on urgency and secrecy observations. [I5][I6]
- Trusted-contact gap fired as an administrative observation because trusted-contact information was declined, but the supplied configuration excludes this from concern counts. [I1][I6]
- Rapid liquidation was assessed absent in the local artifact because recent executed debit activity did not meet the configured executed-outflow threshold. Proposed activity was excluded from executed-outflow totals. [I4][I6]
- Capacity concern indicators were not evaluable because confusion, recall and repeated-question observations were not assessed. No incapacity diagnosis or exploitation determination is made. [I5]

Suggested disposition from the validated protection artifact: Escalate to the authorized protection reviewer. This is a review priority only, not a decision to restrict the account, place a hold, contact a trusted contact, file a report or clear the request.

### Protection gaps and next owners

- Authorized protection reviewer/supervisor: review the source-linked concern pack and decide any firm-policy steps, if any. This draft does not make that decision. [I5][I6]
- Ori or appropriate observation owner: supply whether confusion, recall, repeated questions, new caregiver/POA, refusal of family involvement and scam narrative flags were assessed. [I5]
- Noor or account-record owner: confirm whether any later trusted-contact or authority/account records exist; the packet only supplies the declined trusted-contact record and no impairment determination. [I1]
- Priya/control owner: confirm SCR-I v4 applicability for this brokerage US review; the packet labels it an attributed configuration, not a legal Rule 2165 applicability or hold determination. [I6]

## 2. Operations Package for Service Requests

Operations status: draft package, needs-data. Neither DIST-18 nor TR-10 has been submitted. Received evidence is not authenticated approval or authority.

### Supplied service policy

OPS-I v2, owner Noor, is effective 2026-09-01 through 2026-12-31 for brokerage US. For transfers/distributions, the supplied profile requires identity, authority and destination records; distributions additionally require tax instructions. Required records must be received and consistent. A conflicting callback condition, if supplied, is not waived merely because it is outside the required list. Available cash must be checked across concurrent requests. No instruction conveys hold or transfer authority to the preparer. [I3]

Machine-validation note: the local service-packager input was left partial because the packet only supplied requirements for transfer/distribution, while the validator requires a complete four-service policy map covering transfer, distribution, authority and beneficiary. I did not invent unused authority/beneficiary policy requirements. The validator reported: `policy.service_requirements must explicitly map all four service types to nonempty unique requirement lists`.

### Request package

| Request | Source-asserted instruction | Source-asserted evidence state | Draft operations status |
| --- | --- | --- | --- |
| DIST-18 | AdultI-A requests proposed USD 18,000 cash distribution from AC-IRIS to masked new external payee PAY-NEW for "urgent family assistance." [I2] | Identity received; signed authority missing; tax instruction reference missing; destination has two conflicting confirmations; callback-review condition conflicting and not cleared. [I2][I3][I5][I6] | Needs-data; draft-not-submitted; unresolved protection review and destination conflict carried forward. |
| TR-10 | AdultI-A requests proposed partial USD 10,000 cash transfer from AC-IRIS to masked destination DEST-I in AdultI-A's name. [I2] | Identity received; signed authority received; destination evidence received. No source records TR-10 as executed. [I2][I4] | Individually evidence-complete under the supplied transfer requirements, subject to operations verification and aggregate funding/protection-review issues; draft-not-submitted. |

### Aggregate funding

- Source assertion: AC-IRIS has USD 25,000 available settled cash. [I1]
- Source assertions: DIST-18 requests USD 18,000 and TR-10 requests USD 10,000. [I2]
- Local calculation: USD 18,000 + USD 10,000 = USD 28,000 aggregate requested cash. Compared with USD 25,000 supplied available cash, concurrent requests exceed cash by USD 3,000. Each request is below available cash individually; the shortfall is aggregate. No sequencing, funding source, liquidation, settlement timing or waiver is inferred. [I1][I2][I3]
- Source assertion: supplied holdings schedule is empty; there are no in-kind requests in this package. [I1][I2]

### Unresolved operations conditions

- DIST-18 authority: missing signed authority record. Owner: operations/custody evidence owner. [I2][I3]
- DIST-18 tax instructions: missing requested tax instruction reference. Owner: operations/tax-withholding evidence owner. [I2][I3]
- DIST-18 destination: conflicting destination confirmations and unresolved destination disagreement. Owner: operations/custody destination-review owner; upstream issue `SERVICE-I-18/destination-conflict` remains unresolved. [I2][I5][I6]
- DIST-18 callback review: conflicting extra condition is not cleared; under OPS-I v2, a supplied conflicting callback condition is not waived solely because it is outside the required list. Owner: operations condition owner. [I2][I3]
- Aggregate cash: combined proposed cash requests exceed supplied settled cash by USD 3,000. Owner: operations funding reviewer; no instruction order or funding assumption should be applied from this draft. [I1][I2][I3]
- Upstream protection issue: validated protection artifact suggested Escalate and remains needs-data. Owner: authorized protection reviewer before operations reliance on DIST-18 and any linked decisions. [I4][I5][I6]

## Source Registry

- I1: Engagement, party and account record, operations Noor, 2026-09-17; current through 2026-09-30.
- I2: Service requests received 2026-09-17, operations Noor; current through 2026-09-30.
- I3: Supplied service profile OPS-I v2, owner Noor, effective 2026-09-01 through 2026-12-31.
- I4: Complete bounded transaction history, protection analyst Ori, 2026-09-17; valid through 2026-09-17.
- I5: Observed call notes, Ori, 2026-09-17; current through 2026-09-30.
- I6: Screening configuration SCR-I v4, control owner Priya, effective 2026-09-01 through 2026-12-31.
