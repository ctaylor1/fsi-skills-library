Prepared the review package here:

[hh_iris_protection_operations_draft.md](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-_2k0a9xz/work/hh_iris_protection_operations_draft.md:1)

Supporting local artifacts:
- [protection_input_hh_iris.json](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-_2k0a9xz/work/protection_input_hh_iris.json:1)
- [protection_artifact_hh_iris.json](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-_2k0a9xz/work/protection_artifact_hh_iris.json:1)
- [service_package_input_hh_iris_partial.json](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-_2k0a9xz/work/service_package_input_hh_iris_partial.json:1)

Validation/results:
- Protection input validation: `0 error(s)`, `7 data finding(s)`.
- Protection output validation: `0 error(s)`.
- Protection artifact status: `needs-data`; suggested disposition: `Escalate`.
- Operations service-packager validation was intentionally left incomplete: the packet only supplied transfer/distribution policy requirements, while the tool requires a full four-service policy map. I preserved that as a gap instead of inventing authority/beneficiary policy fields.
- Aggregate funding calculated locally: USD 28,000 requested vs USD 25,000 supplied settled cash, creating a USD 3,000 aggregate shortfall.