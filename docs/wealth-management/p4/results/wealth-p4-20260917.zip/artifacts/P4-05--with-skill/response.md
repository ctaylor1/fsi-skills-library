Done. I prepared the draft report and supporting local artifacts.

Main draft:
[HH-ELM_transition_tax_handoff_draft.md](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-bu0jgaq5/work/HH-ELM_transition_tax_handoff_draft.md)

Supporting files:
- [transition_review_input.json](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-bu0jgaq5/work/transition_review_input.json)
- [transition_review_artifact.json](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-bu0jgaq5/work/transition_review_artifact.json)
- [tax_review_input.json](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-bu0jgaq5/work/tax_review_input.json)
- [tax_review_artifact.json](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-bu0jgaq5/work/tax_review_artifact.json)

Validation passed for both structured inputs and outputs. The draft preserves `needs-data` status, highlights the settlement deficit, identifies the proposed taxable loss and IRA replacement-purchase exposure, and assigns missing evidence to Ellis, Francis, the advisor/product data owner, and the tax professional as appropriate.