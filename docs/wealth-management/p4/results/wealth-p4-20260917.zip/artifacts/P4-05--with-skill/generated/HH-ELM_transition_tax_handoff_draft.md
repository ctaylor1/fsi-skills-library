# HH-ELM Proposed Transition and Tax-Aware Handoff Draft

Audience: advisor, trading reviewer, tax liaison  
Review date: 2026-09-17  
Scope: proposed transactions only; no fills, orders, delivery, tax filing, basis update or system change occurred.  
Packet used: `source_packet.json` only. Calculations are deterministic draft calculations from the cited packet records, not independent source authentication.

## Draft Status

Both local draft artifacts are `needs-data`.

- Transition artifact: `portfolio-rebalancing-assistant-fc570d5454b2553bda1e`, input hash `fc570d5454b2553bda1e11a19b18a15d84ad625283b3e155c3dc4d2cd82fac51`.
- Tax artifact: `tax-aware-investment-reviewer-d48ae7017d6418204c3a`, input hash `d48ae7017d6418204c3a5a2403bc31418001a090250104bc54b974de90bb229c`.
- Primary blockers: proposed buy settles before proposed sale proceeds are available, and no bridge funding evidence is supplied; household replacement-purchase review is incomplete for held-away and forward-window coverage. [E5] [E3]

## Source Assertions

- Account and transition policy record asserts a US advisory, USD taxable account `TAX-ELM`, settled cash of USD 1,000, 100 shares of `LOSS-X` at USD 50, reported market value USD 5,000, total portfolio USD 6,000, one taxable lot `LX1` with total basis USD 7,000, complete holdings/lots, target weights of `LOSS-X` 40%, `NEW-Y` 50%, and cash 10%, plus supplied planning limits and USD 10 fixed fee per trade. [E1]
- Proposed instruction sheet asserts validate mode, specified lot sale of 60 `LOSS-X` from `LX1` at USD 50 with USD 10 fee settling 2026-09-21, and purchase of 150 `NEW-Y` at USD 20 with USD 10 fee settling 2026-09-18. It also asserts no execution authority is included. [E2]
- Replacement activity inventory asserts applicable reviewed accounts are `TAX-ELM` and spouse `IRA-ELM`; spouse IRA executed a dividend reinvestment purchasing 20 `LOSS-X` on 2026-09-10, acquisition lot `IRA-NEW`; no other executed or proposed replacement purchases appeared in the reviewed 2026-08-18 through 2026-09-17 history for those accounts. It also asserts a held-away spouse account statement has not been obtained and future orders have not been fully reviewed. [E3]
- Tax scenario asserts `LOSS-X` unit basis USD 70, unit price USD 50, tax term explicitly long, potential-equivalence group `GX` contains `LOSS-X` only, and no reviewer decision has been made on whether `NEW-Y` is substantially identical. It also supplies illustrative rates and budgets and states no tax-loss benefit, deductible amount or basis adjustment has been determined. [E4]
- Issue log asserts unresolved origin artifact `TRANSITION-ELM-2`, code `settlement-sequence`: "Buy settles before the proposed sale; no bridge funding evidence supplied." [E5]

## Verified Draft Calculations

These are arithmetic checks from the packet, not verification that the source assertions are true.

### Cash and Settlement

| Date | Opening settled cash | Buys | Sells | Fees | Closing settled cash | Review note |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| 2026-09-18 | USD 1,000 | USD 3,000 | USD 0 | USD 10 | USD -2,010 | Negative projected settled cash before sale proceeds. [E1] [E2] [E5] |
| 2026-09-21 | USD -2,010 | USD 0 | USD 3,000 | USD 10 | USD 980 | Final projected cash is positive, but it does not cure the earlier settlement deficit. [E2] [E5] |

Trading reviewer draft conclusion: do not treat the proposed sequence as settlement-ready without bridge funding, revised settlement sequencing or other firm-approved funding evidence. Owner: Ellis/trading reviewer. [E5]

### Position and Policy Review

| Item | Pre | Proposed post | Target / limit | Draft check |
| --- | ---: | ---: | ---: | --- |
| Pre-transition NAV | USD 6,000 | n/a | Reported total USD 6,000 | Reconciles from USD 1,000 cash plus USD 5,000 `LOSS-X`. [E1] |
| Transaction fees | n/a | USD 20 | Reserve USD 20 | Equals supplied reserve; no excess in draft arithmetic. [E1] [E2] |
| Post-fee NAV | n/a | USD 5,980 | n/a | Pre-NAV less USD 20 fees. [E1] [E2] |
| Final cash | USD 1,000 | USD 980 | Minimum cash USD 0; target cash 10% | Final cash passes minimum, but settlement path fails on 2026-09-18. [E1] [E2] |
| `LOSS-X` quantity/value/weight | 100 / USD 5,000 / 83.33% | 40 / USD 2,000 / 33.44% | Target 40%, drift tolerance 20 pp | Residual drift -6.56 pp, within supplied tolerance. [E1] [E2] |
| `NEW-Y` quantity/value/weight | 0 / USD 0 / 0% | 150 / USD 3,000 / 50.17% | Target 50%, max position 80% | Residual drift +0.17 pp and position weight within supplied limits. [E1] [E2] |
| Sell turnover | n/a | 50.00% | Max sell turnover 60% | Within supplied planning limit. [E1] [E2] |
| Order notional | n/a | USD 3,000 sell; USD 3,000 buy | Max order USD 10,000 | Each proposed order is within supplied planning limit. [E1] [E2] |

### Lot Review

| Lot | Proposed sale | Basis allocated | Gross gain/loss before sale fee | Tax-review gain/loss after sale fee |
| --- | ---: | ---: | ---: | ---: |
| `LX1` | 60 of 100 `LOSS-X` shares | USD 4,200 | USD -1,200 | USD -1,210 |

Basis calculation: 60/100 of USD 7,000 lot basis equals USD 4,200; gross proceeds are 60 x USD 50 = USD 3,000. The transition draft reports gross lot loss before fees of USD 1,200; the tax draft subtracts the USD 10 sale fee and reports USD 1,210 loss before wash-sale review. [E1] [E2] [E4]

## Tax-Aware Handoff

### Gains and Losses for Tax Professional Review

- Positive taxable gains from the proposed sale: USD 0; illustrative positive-gain reserve: USD 0; supplied positive-gain budget USD 5,000 and reserve budget USD 1,000 are not consumed by positive gains in this draft. [E2] [E4]
- Proposed taxable loss before wash-sale review: USD -1,210 after the supplied USD 10 sale fee. Deductible loss and basis adjustments are not determined. [E2] [E4]
- `LX1` is asserted as long-term by supplied tax scenario; no law-based holding-period inference was performed. [E4]

### Replacement-Purchase Facts Requiring Tax Professional

- Potential overlap identified: spouse `IRA-ELM` executed a dividend reinvestment purchase of 20 `LOSS-X` on 2026-09-10, inside the 30-day lookback window for the proposed 2026-09-17 `LOSS-X` loss sale. `LOSS-X` is in supplied potential-equivalence group `GX`; the purchase is in a tax-deferred IRA account. Tax professional must determine wash-sale treatment, IRA consequences, any disallowance and any basis effects. [E3] [E4]
- Proposed `NEW-Y` purchase of 150 shares on 2026-09-17 is in the same proposed transition, but no human-reviewed equivalence mapping is supplied for `NEW-Y`; the tax professional must decide whether `NEW-Y` is substantially identical or otherwise relevant to the loss-sale analysis. [E2] [E4]
- Reviewed replacement history is incomplete for household scope: the packet says a held-away spouse account statement has not been obtained. It also says future orders have not been fully reviewed. The forward 30-day window for a 2026-09-17 sale runs through 2026-10-17, so post-review purchases/orders remain unknown. [E3]
- The packet asserts no other executed or proposed replacement purchases in reviewed `TAX-ELM` and `IRA-ELM` history from 2026-08-18 through 2026-09-17, but that assertion is limited by the missing held-away spouse account and forward-order gaps. [E3]

### Asset Location and Classification Gaps

- Supplied location policy prefers fixed-income in tax-deferred accounts. The packet does not supply an asset class for `NEW-Y`, and the draft input preserved the sold-lot asset class as `unspecified`; therefore asset-location review is unassessed rather than cleared. Owner: advisor/product data owner for classifications; tax liaison for policy applicability. [E4]

## Missing Evidence and Next Owners

| Issue | Why it matters | Next owner |
| --- | --- | --- |
| Bridge funding, credit facility, pending deposit or revised settlement sequence | Buy settlement on 2026-09-18 creates projected settled cash of USD -2,010 before the sale settles on 2026-09-21. | Ellis / trading reviewer. [E5] |
| Execution authority and current-trade freshness | Packet states no execution authority is included; proposed transactions are not fills. Quotes/instructions are dated 2026-09-17 and E2 is valid through 2026-09-18. | Advisor and trading reviewer. [E2] |
| Held-away spouse account statement | Household replacement-purchase scope is incomplete. | Francis / tax liaison. [E3] |
| Forward orders and post-sale purchases through 2026-10-17 | Future 30-day replacement window is not fully reviewed. | Francis / tax liaison, with tax professional review. [E3] |
| `NEW-Y` substantial-identical/equivalence determination | Packet explicitly says no decision has been made for `NEW-Y`; proposed purchase occurs on proposed sale date. | Tax professional, supported by tax liaison. [E2] [E4] |
| IRA dividend reinvestment tax treatment | 20-share `LOSS-X` IRA purchase is a potential replacement exposure for a taxable loss sale. | Tax professional. [E3] [E4] |
| Deductible loss, basis adjustment and tax-return treatment | Packet states these have not been determined; draft calculations do not decide tax treatment. | Tax professional. [E4] |
| Asset class for `LOSS-X` and `NEW-Y`, if asset-location review is needed | Supplied location policy cannot be applied without sourced classifications. | Advisor/product data owner and tax liaison. [E4] |

## Review Posture

This draft is for internal human review. It does not approve a recommendation, authorize trading, establish source truth, deliver client communications, determine tax treatment or update any system of record.
