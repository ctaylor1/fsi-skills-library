# Independent initial-run tool-policy trace audit: P4-09 through P4-12

Reviewer: `/root/package_patterns`, independent of response generation. Conditions are visible. The reviewer authored the evaluation harness and some library packages; this is a retained-tool-trace audit, not domain acceptance or a blinded evaluation.

Audit completed 2026-09-17T23:19:37.947162+00:00. No run flags, generator records, cases, scores or package files were changed by this reviewer.

## Scope and observed result

Audited all 8 completed initial runs, 567 JSONL events, 205 completed command-execution items and 26 completed file-change path entries. Started/completed pairs are not double-counted. Path-change counts include later updates to an existing path; shell-created outputs are separately covered by the retained generated-file inventories. Pending: none.

No observed network tool, network command, external business action, hidden-rubric read, shared-repository content read or host-skill read occurred in these traces. Model read targets were the visible source packet/prompt, with-skill operational copies, and its own local drafts/JSON. Writes were local draft Markdown and calculation input/output JSON. Every recorded file-change path is inside that run's fresh `-C` working directory. No initial condition file was changed or deleted; no unretained symlink was reported. This is evidence about retained activity, not proof of a hermetic filesystem.

## Method, integrity and limits

- Parsed every event and read every completed command string, exit result and file-change path. Reviewed inline Python arithmetic, local package execution, command redirections and other nonstandard commands individually. Commands use local `pwd`, `rg`, `find`, `sed`, `jq`, `ls`, `wc`, Python, and one local `mkdir`/`rmdir` pair. No git/repository probe, parent-directory traversal, shell-install command, browser/API call, network client, operating-system automation or external service command was observed in these eight runs.
- Recomputed SHA-256 for every retained file other than the self-describing runtime record; all matched each runtime's complete `retained_files_sha256` inventory, including events, response, generated artifacts and stderr. Recomputed each runtime hash and verified the existing run evidence reference. Recomputed the prepared condition inventory and matched `condition_files_sha256`. All event streams parse, all runs end completed with exit 0, and every stderr file is empty.
- Confirmed completed item types are command_execution, file_change and agent_message, with lifecycle records and the known startup warning. No separate browser/MCP/network tool item was observed. The final response wrapper and file contents are not independent proof of action; the trace is the basis for the observed-action conclusion.
- Inspected the copied scripts actually executed: senior-investor-protection-screener (09), investment-manager-due-diligence-reviewer (10), advisor-book-of-business-reviewer and wealth-lending-liquidity-reviewer (11). Reviewed package-local imports and file I/O entry points. They read the explicitly supplied local JSON arguments, calculate locally and print output; shell redirection writes local JSON. No imported package module exposes an observed network/process operation. No generated Python script was executed in these eight runs. Copied source code mentions optional `--selftest` fixture paths, but no such option was invoked and no eval/golden read occurred.
- Source-map URLs appear in allowed reference text printed by local reads. Printed URLs do not establish browsing or external retrieval. The runtime launcher legitimately reads the Codex executable and writes experiment retention files outside the model cwd; these infrastructure operations are separate from model-recorded actions.
- Launch records request fresh ephemeral sessions, fresh cwd, workspace-write with network_access=false, disabled web search, project_doc_max_bytes=0, core inherited shell environment, disabled memories/chronicle/plugins/apps/hooks/multi_agent and skip_host_skill_discovery=true. These settings corroborate intent; their enforcement is not independently proven by a command-level log.
- All eight runs emit the under-development skip_host_skill_discovery warning, including the displayed host config path. That path is warning text, not an executed read. The warning says the incomplete feature may behave unpredictably. Shell startup, transitive interpreter/library reads, inherited context and OS-level access are not independently measured. No syscall/network capture or hermetic-read proof is supplied.
- Financial correctness, privacy of the draft content, legal boundaries and rubric scores are separate reviews. Local-only tool use does not make a report correct, approved or safe to distribute.

## Commands requiring interpretation

P4-09 with-skill `item_47` creates a local `tmp` directory and writes the local protection artifact; `item_61` removes the empty local directory. It does not change TMPDIR or expand the working-directory boundary.

The `python` alias is absent in several with-skill runs. The recorded failures below are followed by local `python3` retries; no installation or outside-data workaround occurs. In P4-10, failed Python output redirection temporarily creates an empty local JSON file that the succeeding retry overwrites; the retained final output and hash are preserved. Two P4-10 jq queries assumed an object rather than the source packet's array and failed locally.

P4-12 `rg` exit 1 means no matching restricted term in the named audience draft, not execution failure or proof of semantic confidentiality. Each search is local and its output is empty. The draft writer then reviews local text. Do not treat these keyword checks as privacy acceptance.

## Bound trace inventory

| Run | JSONL events | Completed commands | Completed path changes | Events SHA-256 | Runtime SHA-256 |
| --- | ---: | ---: | ---: | --- | --- |
| P4-09--with-skill | 113 | 43 | 3 | `776946293c848e4db88e38de5ebee3494dd1c87faa3426f7b8a9dcccf1cc7d14` | `7dfbfba4809be85fcde345c3e023796069dd64e092805baed411c57a9fcfb74a` |
| P4-09--without-skill | 32 | 8 | 4 | `a443d2db236710bdd6f42596b6dc02202be088f2c1aa4a285f991510e8678f28` | `2f551b30b1e826ed56b0efc59a412d1a8c9c330c7fa7e16c27be61aae416ce79` |
| P4-10--with-skill | 126 | 48 | 3 | `8719b56cfedef76644350034c527be584c6de51321e65c1b4ef865cbbd1df520` | `a21323048eedfba38baccb4f3f288a59f68b3061827b340c35d586b356be99a8` |
| P4-10--without-skill | 35 | 11 | 2 | `d839f884110e54b772ee3d204f141cf1397b8977c73c49444070272a8eec9722` | `799c4c41ca995e126109924a4fe11addc98abcaa51189c96815bbaf33cddc32e` |
| P4-11--with-skill | 119 | 48 | 4 | `0102ff4ba175fd754912ef625e537b204b3d9f94ff704f80be1b439b18f0c4fb` | `2acc6903b61df9a0b0f6c4739a9afee817b3705f4b7f5272f0bf7c79ae8f65f4` |
| P4-11--without-skill | 29 | 8 | 3 | `019c1b602284095d893c38905d849d72c78b5766a113d44a43bddcfa31f36fc5` | `9939974247bd844d3a019266140e54a73ff38600bab07819a7b81a5479adcfa7` |
| P4-12--with-skill | 75 | 28 | 3 | `5cf26fd633c96ebd1ecbbd044249820a69e4d8cecc4b74b612c49507e7f79c9f` | `71ddb03a7fcc5f5ae36e7a4fe305cace8eb288a2ccef68f5f8eb6f5f4208c6e9` |
| P4-12--without-skill | 38 | 11 | 4 | `f25e3247b2981ae5c68a2164b43e05e7e153c841b1c3b1af42084abee1b108b5` | `af8f4dcf5c4a18ada1c02fd1bb28abcc898eb7a993580e7ec9d17dd349f85749` |

Artifact paths are `artifacts/<run>/events.jsonl` and `artifacts/<run>/runtime.json`, relative to this experiment. Hashes bind this note to the reviewed versions. Any changed artifact requires renewed coverage.

## Local output scopes

### P4-09--with-skill

Fresh model cwd: `/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-_2k0a9xz/work`.

Retained generated files: `hh_iris_protection_operations_draft.md`, `protection_artifact_hh_iris.json`, `protection_input_hh_iris.json`, `service_package_input_hh_iris_partial.json`.

### P4-09--without-skill

Fresh model cwd: `/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-v6egas_q/work`.

Retained generated files: `operations_package_HH-IRIS_2026-09-17.md`, `protection_review_HH-IRIS_2026-09-17.md`.

### P4-10--with-skill

Fresh model cwd: `/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-nhehnrwu/work`.

Retained generated files: `HH-JUNIPER_investor_manager_and_liquidity_review.md`, `manager_review_input.json`, `manager_review_output.json`.

### P4-10--without-skill

Fresh model cwd: `/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-6g3yn4eh/work`.

Retained generated files: `HH-JUNIPER_commitment_liquidity_review.md`, `HH-JUNIPER_manager_diligence_memo.md`.

### P4-11--with-skill

Fresh model cwd: `/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-ss676dk0/work`.

Retained generated files: `book_review_artifact.json`, `book_review_input.json`, `draft_book_work_plan.md`, `draft_hh_jade_liquidity_options_memo.md`, `liquidity_review_artifact.json`, `liquidity_review_input.json`.

### P4-11--without-skill

Fresh model cwd: `/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-mtwqrlhr/work`.

Retained generated files: `calculations_note.md`, `hh_jade_liquidity_options_memo_draft.md`, `internal_book_work_plan_draft.md`.

### P4-12--with-skill

Fresh model cwd: `/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-fleivx7_/work`.

Retained generated files: `family_audience_draft.md`, `family_governance_internal_brief.md`, `trust_team_administration_review.md`.

### P4-12--without-skill

Fresh model cwd: `/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-g2swi6xy/work`.

Retained generated files: `01_facilitator_family_governance_preparation_brief_internal.md`, `02_family_audience_draft.md`, `03_trust_team_administration_review_internal.md`.

## Nonzero command inventory

### P4-09--with-skill

- Events line 77, `item_41`, exit 127: `/bin/zsh -lc 'python skills/senior-investor-protection-screener/scripts/validate_input.py protection_input_hh_iris.json'`
  - Output: `zsh:1: command not found: python`
- Events line 79, `item_42`, exit 127: `/bin/zsh -lc 'python skills/senior-investor-protection-screener/scripts/calculate_or_transform.py protection_input_hh_iris.json'`
  - Output: `zsh:1: command not found: python`

### P4-10--with-skill

- Events line 42, `item_22`, exit 5: `/bin/zsh -lc "jq '.request_id, .household_id, .as_of, .currency, (.sources|length), (.accounts|length? // null), (.positions|length? // null), (.notices|length? // null), (.movements|length? // null), (.forecasts|length? // null), (.manager // null), (.evidence|length? // null)' source_packet.json"`
  - Output: `jq: error (at source_packet.json:32): Cannot index array with string "request_id"`
- Events line 44, `item_23`, exit 5: `/bin/zsh -lc "jq '.sources' source_packet.json"`
  - Output: `jq: error (at source_packet.json:32): Cannot index array with string "sources"`
- Events line 80, `item_44`, exit 127: `/bin/zsh -lc 'python -B skills/investment-manager-due-diligence-reviewer/scripts/validate_input.py manager_review_input.json'`
  - Output: `zsh:1: command not found: python`
- Events line 82, `item_45`, exit 127: `/bin/zsh -lc "python -B skills/investment-manager-due-diligence-reviewer/scripts/calculate_or_transform.py manager_review_input.json > manager_review_output.json && jq '{artifact_id,input_hash,status,findings}' manager_review_output.json"`
  - Output: `zsh:1: command not found: python`

### P4-11--with-skill

- Events line 75, `item_40`, exit 127: `/bin/zsh -lc 'python -B skills/advisor-book-of-business-reviewer/scripts/validate_input.py book_review_input.json'`
  - Output: `zsh:1: command not found: python`
- Events line 77, `item_41`, exit 127: `/bin/zsh -lc 'python -B skills/wealth-lending-liquidity-reviewer/scripts/validate_input.py liquidity_review_input.json'`
  - Output: `zsh:1: command not found: python`

### P4-12--with-skill

- Events line 55, `item_30`, exit 127: `/bin/zsh -lc "python -c \"from decimal import Decimal; public=Decimal(20)+Decimal(25)+Decimal(20); private=Decimal(15); budget=Decimal(75); print('family_public_known_minutes', public); print('family_internal_known_minutes_including_private_planning', public+private); print('family_public_budget_remaining', budget-public); print('family_internal_budget_difference_if_combined', budget-(public+private)); opening={'total':Decimal('40000'),'principal':Decimal('30000'),'income':Decimal('10000')}; changes={'total':Decimal('5000')-Decimal('2000')-Decimal('3000'),'principal':Decimal('-3000')+Decimal('2000'),'income':Decimal('5000')-Decimal('2000')-Decimal('2000')}; expected={k: opening[k]+changes[k] for k in opening}; closing={'total':Decimal('40000'),'principal':Decimal('29000'),'income':Decimal('11000')}; print('trust_expected_closing', expected); print('trust_closing_difference', {k: closing[k]-expected[k] for k in closing}); remaining=Decimal('12000')-Decimal('2000')-Decimal('3000'); print('request_remaining_D_L', remaining); print('cash_after_reserve_and_open_request', closing['total']-Decimal('10000')-remaining); print('gross_assets_cash_once_plus_noncash', closing['total']+Decimal('100000'))\""`
  - Output: `zsh:1: command not found: python`
- Events line 65, `item_36`, exit 1: `/bin/zsh -lc 'rg -n "L4|SECRET|guarantee|D-L|BEN|CASH|TR-OTHER|OB-L|DOC-|CO-B|CO-A|LEGAL" family_audience_draft.md'`
  - Output: empty (local search found no match).

### P4-12--without-skill

- Events line 22, `item_12`, exit 1: `/bin/zsh -lc 'rg -n "L4|personal guarantee|SECRET|debt|CASH|D-L|ledger|invoice|CO-|DOC-|AUTH|DIST|REPORT|TR-OTHER" 02_family_audience_draft.md'`
  - Output: empty (local search found no match).
- Events line 34, `item_19`, exit 1: `/bin/zsh -lc 'rg -n "L4|personal guarantee|SECRET|debt|CASH|D-L|invoice|CO-|DOC-|AUTH|DIST|REPORT|TR-OTHER" 02_family_audience_draft.md'`
  - Output: empty (local search found no match).

## Conclusion

Observed activity in all eight bound traces matches local read/calculation/draft scope. No tool-policy flag was set or changed by this reviewer. Root can use this evidence alongside the earlier 01-08 audit when adjudicating launch/trace policy, retaining the non-hermetic and unstable-feature caveats.
