# Independent initial-run tool-policy trace audit: P4-01 through P4-08

Reviewer: `/root/wealth_planning_review`, independent of response generation.
Conditions are visible. Audit updated 2026-09-17T23:08:31.112440+00:00.
No run isolation flags or generator records were changed by this reviewer.

## Scope and observed result

Audited 16 completed initial runs, 1153 JSONL events,
413 completed command-execution items and 53 completed
file-change entries. Started/completed event pairs are not double-counted as tool calls.
The file-change count counts individual paths, including later updates to the same path.
Pending/not yet covered: none.

In the covered completed traces, I found no observed network tool, network command,
external business action, hidden-rubric read, repository-content read or host-skill read.
Read targets were the visible source packet/prompt, supplied local skill copies in the
with-skill condition, and files authored within the fresh work directory. Local writes
were draft reports, structured inputs/outputs and calculation/report scripts inside that
work directory. Every completed file-change path is inside its runtime `-C` directory.
There are no reported changes/deletions to initial condition files or unretained symlinks.
This is an observation of retained tool traces, not proof of a hermetic filesystem.

## Method and evidence limits

- Parsed every available covered event, checked all completed `command_execution`
  command strings, command exits and `file_change` paths. Reconciled event JSONL hashes
  to `runtime.json`; all covered hashes match and event_parse_errors is empty.
- Reviewed all arithmetic/inline Python and nonstandard commands separately from the
  repeated local `sed`, `rg`, `jq`, `wc`, directory listings and copied-skill CLIs.
  Searched complete commands for external URLs/network clients, host configuration,
  hidden/rubric paths, repository paths, parent traversal and operating-system automation.
  No such executed access was found. Source-map URLs printed from allowed files do not
  constitute browsing or external retrieval.
- Inspected retained generated Python used as commands: P4-03 with-skill's
  `build_hh_cedar_report.py` reads its own local artifacts/IPS input and writes the local
  report (imports json/pathlib); P4-07 without-skill's `hh_grove_calculations.py` imports
  decimal and performs local arithmetic. These have no observed network/process APIs.
- The trace item types are command_execution, file_change, agent_message, todo_list,
  the known startup warning, and lifecycle events. No browser/MCP/network API item was
  observed. A command-level log is not a syscall log; transitive interpreter/library reads,
  shell startup behavior and host enforcement are not independently measured here.
- Runtime launch records request fresh ephemeral sessions, a fresh working directory,
  workspace-write, network_access=false, web_search disabled, project_doc_max_bytes=0,
  core-only inherited shell environment, and disabled memories/chronicle/plugins/apps/
  hooks/multi_agent. They also request skip_host_skill_discovery=true. These requested
  settings are corroborating launch evidence, not independently proven enforcement.
- Every covered run emits: **Under-development features enabled:
  skip_host_skill_discovery**. The warning states incomplete features may behave
  unpredictably. The displayed `/Users/taylor/.codex/config.toml` is warning text;
  no model command opened that path. Do not convert this audit into an unqualified
  guarantee that no hidden host context could have been inherited.
- The infrastructure itself legitimately reads a model executable and writes retained
  experiment artifacts outside the fresh model cwd. Those launcher operations are
  distinct from the evaluated model's recorded command/file-change actions.

## Commands requiring explicit interpretation

P4-05 without-skill `item_3` and P4-07 without-skill `item_3` ran `git status --short`
in their temporary work directory. Both returned exit128, “not a git repository”.
This is an unnecessary repository-metadata probe and should be disclosed. The traces
show no repository-content read, successful repository discovery, `git -C` command,
path to the shared checkout or subsequent escape. Root should adjudicate these failed
housekeeping probes when setting tool-policy flags; this reviewer has not set them.

Missing `python` aliases caused some early commands to fail with exit127; the runs
retried with python3 locally. A `python ... | sed ...` pipeline can report shell exit0
while its output contains command-not-found; I checked command output rather than
assuming every zero exit meant its first program ran. Other bounded local errors were
a Python arithmetic syntax error, jq shape assumption, and a report-file check before
its local creation. No failed command was repaired by network install or outside data.

P4-05 with-skill sets TMPDIR to its own work/.tmp; P4-07 sets TMPDIR to a local tmp or
its PWD. These are local temporary-directory workarounds, not expanded write access.

## Bound trace inventory

| Run | JSONL events | Completed commands | Completed path changes | Events SHA-256 | Runtime SHA-256 |
| --- | ---: | ---: | ---: | --- | --- |
| P4-01--with-skill | 74 | 28 | 1 | `860da8837bc18925e4a374742829af627eb0e5dd9f4da40fe4078b791d882969` | `94e20494e35d5e855f498ba0e6228d49d8b1337815a5e0b5d896a3d6dd3c6b67` |
| P4-01--without-skill | 34 | 9 | 2 | `55396a34634d7f4e884e105a278f2b4c90521921fe9153806257721a7590957f` | `7495bfb031166f18c04595f444562633cdf8a3f9c2bddcf0df155dc1a74a3a8e` |
| P4-02--with-skill | 154 | 65 | 5 | `a89c43f9a870923c2ebf30ad74416cfdc5a54b40a4e2ab7b00b063f4de98506a` | `93deacfee64fbf12dbb0b6566ed656a63e70c2ff269c956a227a6edba0d75912` |
| P4-02--without-skill | 36 | 8 | 2 | `3b4dc97183ef24cfb09467e1711955cd80831e52db2386051f8035423b7cc171` | `003e81cc92ae859f583e191a993b672456601b1e75a49a54f3c88b308a2b60fb` |
| P4-03--with-skill | 97 | 38 | 3 | `a28ecc3397ab67a6aa80507ed40501de38d440ff8fee56bfd50f75ea65321a03` | `0bb62b85cbe9ac7de555c2fc85c5e13f9dfc713aedcdc6ece1825fb0a7d6b128` |
| P4-03--without-skill | 36 | 10 | 4 | `8b75021e2c8eb350e1d855cd42f7696172bd6c386a46109d62d3818060e5745e` | `3eca9d409779f5d4296a98fe1ab83cf100bd64ea5815d96ef697716ed8321846` |
| P4-04--with-skill | 124 | 45 | 8 | `471d7f83bbb7878c2217c1124ee885dac35a856042ddad988b0e31ffaf2f34b6` | `599c384af3267bb45a7bf3139ea139e5f6bb961300f1b1eda96feac94b1a7224` |
| P4-04--without-skill | 30 | 8 | 2 | `c05076d9df64dbae24be3357ebe4c2d272b3c105ae0552a03f4b479695bde13e` | `48b461acb9cd623b62858e26c3b1ca0e971673e03bb90de6da21389fe46e66d2` |
| P4-05--with-skill | 105 | 41 | 3 | `125cbddfd6169de6068e4d4ae2df24a836f47a46eb5fb55a63be982122fca858` | `3c413b573d65325be5fb73922a95cbad4596f13e9c8cbea276202b27457cd46c` |
| P4-05--without-skill | 45 | 12 | 3 | `f32ccf094f4522f297f4108d5bce171e023f8b4baf3f2adb150f6639490f8450` | `9d22b690882d46fdf8d8c84f09571b98544ed0691d2f3e6be3d97990cacc0c13` |
| P4-06--with-skill | 104 | 39 | 4 | `d658deb09935b355259882ffb23366a7772d220af2e1aca853030464cc2f29e0` | `95e897557a62c9686bad4ec2bcef93bf587165d3ec6f085a7598eb7f86aa997e` |
| P4-06--without-skill | 29 | 8 | 2 | `ee5e64fd6d4a9e57a89c22f7928f530a6c1cfe79bcf7393745600cb962970812` | `f96faf47877d8d40175f1525c1579b94d509d102eb9d909c650d10ce17b1c2c0` |
| P4-07--with-skill | 106 | 41 | 4 | `196d358a2df8d0d32219d068a955020a712c88b9d5317c70bea586edc17398d0` | `c3e2201d3a13f5890a70b1c0ef9a6a89a946c6dac69079a82b465c4f603ee1a5` |
| P4-07--without-skill | 49 | 15 | 4 | `908bc221b2da319cf0baaea6ee0ac851f5107c42313306db88050119424d2afe` | `9c764003b357adb74ee5b2963682d9b5f583f63f78f86c069d70a3c7d9501d5b` |
| P4-08--with-skill | 86 | 32 | 3 | `c54eefd34df43fb6969a74199713cfb9fbfe21a5da3d68a3761a826a3ad9e58c` | `fb56e24408c69f54144247270c8b7042b34803b5f712529a4ff85ee126f81194` |
| P4-08--without-skill | 44 | 14 | 3 | `b6f5252788860da3421883d66a6b3f295e5b30a6700a97bd81005937d29aaf58` | `7d3f349a88922b736c7ac8888efea22ef6f0a40077a0c04fc68a9119ee35ef3e` |

Paths are `artifacts/<run>/events.jsonl` and `artifacts/<run>/runtime.json` relative to
this experiment. Hashes bind this audit to the observed versions. If a pending run
finishes or any referenced file changes, its coverage must be refreshed before relying
on this note for that run.

## Nonzero command inventory

### P4-01--without-skill

- `item_7` exit 1: `/bin/zsh -lc "python3 -c 'salary=150000; monthly_spend=6500; print(\"annual_spending\", monthly_spend*12); print(\"spending_to_salary_ratio\", round(monthly_spend*12/salary, 4)); print(\"bank_deposit\", 80000); print(\"mortgage\", 240000))'"`

### P4-02--with-skill

- `item_52` exit 127: `/bin/zsh -lc 'python skills/household-wealth-data-reconciler/scripts/validate_input.py drafts/reconciliation_input.json'`
- `item_53` exit 127: `/bin/zsh -lc 'python skills/wealth-management-router/scripts/route.py drafts/route_input.json > drafts/route_output.json'`
- `item_54` exit 127: `/bin/zsh -lc 'python skills/investment-risk-profile-reviewer/scripts/validate_input.py drafts/risk_input.json'`
- `item_55` exit 127: `/bin/zsh -lc 'python skills/household-financial-planning-assistant/scripts/validate_input.py drafts/planning_input.json'`

### P4-03--with-skill

- `item_48` exit 1: `/bin/zsh -lc 'wc -l HH-CEDAR_retirement_cashflow_and_IPS_revision_memo.md retirement_request.json ips_request.json retirement_cashflow_artifact.json ips_revision_artifact.json build_hh_cedar_report.py'`

### P4-04--with-skill

- `item_30` exit 127: `/bin/zsh -lc 'python -B skills/portfolio-construction-assistant/scripts/validate_input.py construction_request.json'`
- `item_31` exit 127: `/bin/zsh -lc 'python -B skills/portfolio-proposal-comparator/scripts/validate_input.py comparison_request.json'`

### P4-05--without-skill

- `item_3` exit 128: `/bin/zsh -lc 'git status --short'`

### P4-06--with-skill

- `item_36` exit 127: `/bin/zsh -lc 'python skills/estate-wealth-transfer-reviewer/scripts/validate_input.py estate_hh_fern_input.json'`
- `item_37` exit 127: `/bin/zsh -lc 'python skills/protection-needs-reviewer/scripts/validate_input.py protection_hh_fern_input.json'`

### P4-07--with-skill

- `item_22` exit 5: `/bin/zsh -lc "jq '.sources // .records // . | type' source_packet.json"`
- `item_40` exit 127: `/bin/zsh -lc 'python skills/wealth-performance-report-builder/scripts/validate_input.py artifacts/hh_grove_performance_input.json'`
- `item_41` exit 127: `/bin/zsh -lc 'python skills/advisory-fee-reviewer/scripts/validate_input.py artifacts/hh_grove_billing_input.json'`

### P4-07--without-skill

- `item_3` exit 128: `/bin/zsh -lc 'git status --short'`

### P4-08--without-skill

- `item_4` exit 127: `/bin/zsh -lc "python -c \"import json, pathlib; p=pathlib.Path('source_packet.json'); print(p.exists(), p.stat().st_size if p.exists() else None); data=json.loads(p.read_text()); print(type(data).__name__); print(list(data.keys()) if isinstance(data, dict) else len(data)); [print(k, type(v).__name__, len(v) if hasattr(v,'__len__') else '') for k,v in (data.items() if isinstance(data, dict) else [])]\""`
