Prepared the HH-BRUME internal draft package for the exact recipient set: Ines, Dario, Celia only.

Main draft: [HH-BRUME_internal_draft_Ines_Dario_Celia_only.md](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-dc0gygay/work/artifacts/HH-BRUME_internal_review/HH-BRUME_internal_draft_Ines_Dario_Celia_only.md)

Working files retained in the same folder:
- [working_tax_supported_input.json](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-dc0gygay/work/artifacts/HH-BRUME_internal_review/working_tax_supported_input.json)
- [working_tax_calculations.json](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-dc0gygay/work/artifacts/HH-BRUME_internal_review/working_tax_calculations.json)
- [estate_native_input.json](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-dc0gygay/work/artifacts/HH-BRUME_internal_review/estate_native_input.json)
- [estate_native_output.json](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-dc0gygay/work/artifacts/HH-BRUME_internal_review/estate_native_output.json)
- [working_permission_check.json](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-dc0gygay/work/artifacts/HH-BRUME_internal_review/working_permission_check.json)
- [working_artifact_manifest.json](/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-dc0gygay/work/artifacts/HH-BRUME_internal_review/working_artifact_manifest.json)

Key supported economics: gross proceeds `5200.00`, basis `7500.00`, net proceeds `5160.00`, loss before wash review `-2340.00`, potential same-exposure replacement quantity `25` units. No tax benefit/reserve was calculated because the approved tax rate and related tax facts were not supplied.

Validation: estate input and estate output both passed the bundled validator with `0` errors. The tax native schema was not used for the final tax artifact because it requires unevidenced tax-profile rates/budgets and explicit RET-B tax treatment; that limitation is documented in the draft and working input. No external contact, delivery, order, approval, transaction, transfer, beneficiary update, or system change was made.