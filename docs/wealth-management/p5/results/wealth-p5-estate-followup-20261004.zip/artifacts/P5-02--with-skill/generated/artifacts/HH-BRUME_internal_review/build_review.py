#!/usr/bin/env python3
"""Build HH-BRUME internal working artifacts from supplied local evidence only."""
from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
RECIPIENTS = ["Ines", "Dario", "Celia"]
AS_OF = "2026-10-04"


def money(value: Decimal) -> str:
    return str(value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def write_json(name: str, payload: dict | list) -> None:
    (OUT / name).write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")


def load_inputs() -> tuple[list[dict], dict]:
    evidence = json.loads((ROOT / "source_packet.json").read_text())
    permission_packet = json.loads((ROOT / "resources/source-packet.json").read_text())
    return evidence, permission_packet


def source_register(permission_packet: dict) -> list[dict]:
    owners = {
        "P5B1": ("Ines", "2026-10-04"),
        "P5B2": ("Jori", "2026-10-03"),
        "P5B3": ("Ines", "2026-10-04"),
        "P5B4": ("Jori", "2026-10-04"),
        "P5B5": ("Celia", "2026-10-04"),
    }
    rows = []
    for source in permission_packet["sources"]:
        owner, as_of = owners[source["source_id"]]
        rows.append(
            {
                "source_id": source["source_id"],
                "reference": source["reference"],
                "owner": owner,
                "as_of": as_of,
                "valid_until": source["access"]["valid_until"],
            }
        )
    return rows


def permission_check(permission_packet: dict) -> dict:
    registered = [r["recipient_id"] for r in permission_packet["recipients"]]
    allowed = {}
    for source in permission_packet["sources"]:
        access = source["access"]
        current = access["effective_date"] <= AS_OF <= access["valid_until"]
        allowed[source["source_id"]] = {
            "all_named_recipients_registered": set(registered) == set(RECIPIENTS),
            "authorized_recipient_ids": RECIPIENTS,
            "source_allowed_recipient_ids": access["allowed_recipient_ids"],
            "current_for_review_as_of": current,
            "included_for_draft": current and all(r in access["allowed_recipient_ids"] for r in RECIPIENTS),
        }
    return {
        "schema_version": "hh-brume-permission-check-v1",
        "artifact_label": "working-permission-check",
        "authorized_recipient_ids": RECIPIENTS,
        "source_packet_path": "resources/source-packet.json",
        "packet_id": permission_packet["packet_id"],
        "as_of": AS_OF,
        "exact_recipient_set": RECIPIENTS,
        "source_results": allowed,
        "action_taken": False,
        "delivery_status": "not-delivered",
    }


def tax_working(evidence: list[dict], permission_packet: dict) -> tuple[dict, dict]:
    quantity = Decimal("100")
    unit_price = Decimal("52")
    unit_basis = Decimal("75")
    fee = Decimal("40")
    gross = quantity * unit_price
    basis = quantity * unit_basis
    net = gross - fee
    gain_loss = net - basis
    sale_date = date.fromisoformat("2026-10-04")
    purchase_date = date.fromisoformat("2026-09-29")
    window_start = sale_date - timedelta(days=30)
    window_end = sale_date + timedelta(days=30)

    supported_input = {
        "schema_version": "hh-brume-tax-supported-input-v1",
        "artifact_label": "working-tax-supported-input",
        "authorized_recipient_ids": RECIPIENTS,
        "request_id": "HH-BRUME-2026-10-04-tax-estate-review",
        "household_id": "HH-BRUME",
        "as_of": AS_OF,
        "source_packet_path": "source_packet.json",
        "permission_packet_path": "resources/source-packet.json",
        "engagement": {"capacity": "advisory", "jurisdiction": "US", "currency": "USD", "source_ids": ["P5B1"]},
        "sources": source_register(permission_packet),
        "sale_lot": {
            "account_id": "TAX-B",
            "account_description": "B-A taxable",
            "tax_treatment": "taxable",
            "lot_id": "LOT-B",
            "security_id": "SEC-B",
            "quantity": "100",
            "unit_cost_basis": "75",
            "unit_price": "52",
            "acquired_on": "2024-05-15",
            "price_as_of": "2026-10-03",
            "source_ids": ["P5B2"],
        },
        "proposed_sale": {
            "sale_id": "SALE-LOT-B-FULL-2026-10-04",
            "lot_id": "LOT-B",
            "quantity": "100",
            "trade_date": "2026-10-04",
            "estimated_fees": "40",
            "execution_status": "not-executed",
            "source_ids": ["P5B2"],
        },
        "replacement_purchase_evidence": {
            "purchase_id": "PURCHASE-RET-B-SEC-B-2026-09-29",
            "account_id": "RET-B",
            "account_header": "IRA only",
            "account_tax_treatment": None,
            "security_id": "SEC-B",
            "quantity": "25",
            "trade_date": "2026-09-29",
            "lifecycle": "executed",
            "same_exposure_group_supplied": True,
            "source_ids": ["P5B3"],
        },
        "unevidenced_or_unaccepted_fields": [
            {"field": "household gains", "status": "absent", "source_ids": ["P5B2"]},
            {"field": "carryforwards", "status": "absent", "source_ids": ["P5B2"]},
            {"field": "approved tax rate", "status": "absent", "source_ids": ["P5B2", "P5B3"]},
            {"field": "RET-B traditional/Roth and tax-deferred/tax-free treatment", "status": "unspecified", "source_ids": ["P5B3"]},
            {"field": "activity coverage after 2026-10-04", "status": "incomplete", "source_ids": ["P5B3"]},
        ],
        "native_tax_tool_status": {
            "status": "withheld",
            "reason": "The bundled tax input schema requires explicit tax_profile rates/budgets and account tax treatment for household purchase screening. Supplied records state those fields are absent or unspecified.",
        },
    }

    calculation = {
        "schema_version": "hh-brume-tax-calculation-v1",
        "artifact_label": "working-tax-calculations",
        "authorized_recipient_ids": RECIPIENTS,
        "request_id": supported_input["request_id"],
        "household_id": "HH-BRUME",
        "as_of": AS_OF,
        "currency": "USD",
        "calculation_inputs": {
            "quantity_sold": "100",
            "unit_price": "52",
            "unit_basis": "75",
            "estimated_fees": "40",
            "replacement_purchase_quantity": "25",
        },
        "supported_sale_economics": {
            "gross_proceeds": money(gross),
            "cost_basis": money(basis),
            "estimated_fees": money(fee),
            "net_proceeds": money(net),
            "gain_loss_before_wash_review": money(gain_loss),
            "positive_taxable_gain": money(max(gain_loss, Decimal("0"))),
            "loss_before_wash_review": money(min(gain_loss, Decimal("0"))),
            "tax_benefit_or_reserve": None,
            "tax_benefit_or_reserve_reason": "No approved tax rate or accepted loss-disallowance conclusion was supplied.",
        },
        "replacement_purchase_screen": {
            "sale_date": "2026-10-04",
            "inclusive_window_start": window_start.isoformat(),
            "inclusive_window_end": window_end.isoformat(),
            "purchase_date": purchase_date.isoformat(),
            "purchase_inside_window": window_start <= purchase_date <= window_end,
            "same_exposure_group_supplied": True,
            "potential_replacement_quantity_for_review": "25",
            "retirement_account_tax_treatment": None,
            "future_window_after_as_of_open": window_end.isoformat() > AS_OF,
            "deductible_loss": "not-determined",
            "basis_adjustment": "not-determined",
        },
        "source_ids": ["P5B1", "P5B2", "P5B3"],
        "action_taken": False,
        "delivery_status": "not-delivered",
    }
    return supported_input, calculation


def estate_native_input(permission_packet: dict) -> dict:
    return {
        "schema_version": "wealth-p0-v1",
        "authorized_recipient_ids": RECIPIENTS,
        "request_id": "HH-BRUME-2026-10-04-estate-record-comparison",
        "household_id": "HH-BRUME",
        "as_of": AS_OF,
        "engagement": {"capacity": "advisory", "jurisdiction": "US", "source_ids": ["P5B1"]},
        "sources": source_register(permission_packet),
        "policy": {
            "version": "EST-B v1",
            "owner": None,
            "capacity": "advisory",
            "jurisdiction": "US",
            "effective_date": "2026-10-01",
            "valid_until": "2026-12-31",
            "required_document_kinds": None,
            "required_beneficiary_tiers": None,
            "source_ids": ["P5B1"],
        },
        "upstream_issues": [
            {
                "artifact_id": "EST-B-19",
                "code": "title-intention-mismatch",
                "message": "BANK-B individual title differs from recorded trust-ownership intention.",
                "status": "unresolved",
                "source_ids": ["P5B5"],
            }
        ],
        "parties": [
            {"party_id": "B-A", "display_name": "B-A", "role": "client / beneficiary", "source_ids": ["P5B1", "P5B5"]},
            {"party_id": "B-B", "display_name": "B-B", "role": "client", "source_ids": ["P5B1", "P5B3"]},
            {"party_id": "TR-BRUME", "display_name": "TR-BRUME", "role": "trust draft / intended owner label", "source_ids": ["P5B4", "P5B5"]},
        ],
        "documents": [
            {
                "document_id": "DOC-TR-BRUME-DRAFT",
                "kind": "trust",
                "version": "draft",
                "summary": "TR-BRUME trust draft is unsigned.",
                "status": "unknown",
                "executed_date": None,
                "source_ids": ["P5B5"],
            }
        ],
        "assets": [
            {
                "asset_id": "BANK-B",
                "description": "BANK-B",
                "registration": "individual",
                "owner_party_ids": ["B-A"],
                "document_ids": None,
                "designation_status": "unknown",
                "source_ids": ["P5B4"],
            },
            {
                "asset_id": "RET-B",
                "description": "RET-B IRA-header retirement account",
                "registration": "retirement",
                "owner_party_ids": ["B-B"],
                "document_ids": None,
                "designation_status": "documented",
                "source_ids": ["P5B3", "P5B5"],
            },
        ],
        "intentions": [
            {
                "intention_id": "INT-BANK-B-TRUST-OWNERSHIP",
                "asset_id": "BANK-B",
                "description": "Client intention is TR-BRUME ownership pending counsel; beneficiary intention was not collected.",
                "target_owner_party_ids": ["TR-BRUME"],
                "governing_document_ids": None,
                "beneficiaries": None,
                "source_ids": ["P5B4"],
            },
            {
                "intention_id": "INT-RET-B-UNKNOWN",
                "asset_id": "RET-B",
                "description": "No supplied consolidated intended owner, document link, or beneficiary schedule for RET-B.",
                "target_owner_party_ids": None,
                "governing_document_ids": None,
                "beneficiaries": None,
                "source_ids": ["P5B1", "P5B5"],
            },
        ],
        "designations": [
            {
                "designation_id": "DES-RET-B-PRIMARY",
                "asset_id": "RET-B",
                "status": "current",
                "document_ids": None,
                "beneficiaries": [
                    {"party_id": "B-A", "tier": "primary", "share": 1.0, "source_ids": ["P5B5"]}
                ],
                "source_ids": ["P5B5"],
            }
        ],
    }


def draft_text(tax_calc: dict, estate_output: dict | None, permission: dict) -> str:
    estate_status = "not yet run"
    estate_artifact = "unknown"
    estate_hash = "unknown"
    estate_summary = "Native estate comparison output was not present when this draft was rendered."
    estate_findings = []
    if estate_output:
        estate_status = estate_output["status"]
        estate_artifact = estate_output["artifact_id"]
        estate_hash = estate_output["input_hash"]
        summary = estate_output["result"]["review_summary"]
        estate_summary = (
            f"Native estate comparison reviewed {summary['assets_reviewed']} supplied assets, "
            f"found {summary['coordination_differences']} literal coordination difference(s), "
            f"and retained {summary['open_items']} open item(s)."
        )
        estate_findings = estate_output["findings"]

    econ = tax_calc["supported_sale_economics"]
    screen = tax_calc["replacement_purchase_screen"]
    lines = [
        "# HH-BRUME coordinated internal draft",
        "",
        "Authorized recipient set: Ines, Dario, Celia only.",
        "Prepared for: Ines (advisor), Dario (tax reviewer), Celia (estate counsel).",
        "Not for client delivery. Human review required. Not delivered. No order, approval, transfer, beneficiary update, system change, or external contact was made.",
        "",
        f"Review as of: {AS_OF}. Household: HH-BRUME. Capacity: US advisory. Sources used: P5B1-P5B5.",
        "",
        "## Permission and source posture",
        "",
        f"The supplied permission packet {permission['packet_id']} registers only Ines, Dario, and Celia as people recipients, and each source P5B1-P5B5 is current for this review date and allowed to the exact recipient set. This is a declared permission check, not delivery, identity authentication, or professional approval. [P5B1-P5B5]",
        "",
        "## Proposed sale economics",
        "",
        f"Supported sale facts: B-A taxable TAX-B contains LOT-B, 100 units of SEC-B, acquired 2024-05-15, unit basis 75, unit price 52 on 2026-10-03. A proposed full sale on 2026-10-04 has a 40 fee and has not executed. [P5B2]",
        "",
        f"Supported arithmetic: gross proceeds {econ['gross_proceeds']} = 100 x 52; cost basis {econ['cost_basis']} = 100 x 75; net proceeds {econ['net_proceeds']} = {econ['gross_proceeds']} - {econ['estimated_fees']}; gain/loss before wash review {econ['gain_loss_before_wash_review']}. Positive taxable gain is {econ['positive_taxable_gain']}; loss before wash review is {econ['loss_before_wash_review']}. [P5B2]",
        "",
        "No tax reserve, deductible loss, or tax benefit is calculated because household gains, carryforwards, and an approved tax rate are absent; the 27% figure appears only as an unreviewed planner assumption and Dario has not accepted a rate or loss-disallowance conclusion. [P5B2, P5B3]",
        "",
        "## Replacement-purchase / wash-sale review posture",
        "",
        f"The supplied 30-day screen around the 2026-10-04 sale runs from {screen['inclusive_window_start']} through {screen['inclusive_window_end']}. B-B bought 25 units of SEC-B in RET-B on 2026-09-29, inside the lookback window, and the purchase and proposed sale are in the supplied same-exposure group. Potential replacement quantity for review is 25 units. [P5B3]",
        "",
        "The RET-B statement header says IRA only; traditional/Roth and tax-deferred/tax-free treatment are unspecified. Activity coverage after 2026-10-04 is incomplete, and the future side of the replacement window remains open through 2026-11-03. Deductible loss and basis adjustments are not determined. [P5B3]",
        "",
        "## Estate record comparison",
        "",
        f"{estate_summary} Status: {estate_status}. Artifact: {estate_artifact}. Input hash: {estate_hash}.",
        "",
        "BANK-B: current title is B-A individual; the recorded client intention is TR-BRUME ownership pending counsel, with no transfer recorded. The bank beneficiary field cannot be treated as confirmed none-recorded because pages were never requested or loaded and legacy export rendered blank as none-recorded. Beneficiary intention was not collected. [P5B4]",
        "",
        "RET-B: the primary page names B-A 100%; the contingent page is absent and no representation of no contingent designation was obtained. TR-BRUME trust draft is unsigned. The email subject line saying Approval complete is not an approval of legal substance; the body only confirms successful upload by an intake assistant. [P5B5]",
        "",
        "The supplied upstream estate issue remains unresolved: Origin EST-B-19, title-intention-mismatch, says BANK-B individual title differs from the recorded trust-ownership intention. [P5B5]",
        "",
        "## Next evidence needs by reviewer",
        "",
        "Ines: confirm whether the proposed sale remains only proposed; obtain current trade-ready pricing/fees if the team later considers action; collect complete household purchase/reinvestment/forward-order coverage through 2026-11-03; obtain complete BANK-B beneficiary pages or custodian confirmation; confirm source ownership and any current account-title extracts. [P5B2, P5B3, P5B4]",
        "",
        "Dario: determine whether SEC-B sale and the 25-unit RET-B purchase create a wash-sale or IRA-related issue; decide whether RET-B tax treatment matters and obtain traditional/Roth/tax-deferred/tax-free evidence; provide any approved rate/budget/carryforward/gain context if a tax-benefit or reserve illustration is desired. [P5B2, P5B3]",
        "",
        "Celia: review the unresolved BANK-B title versus TR-BRUME intention; determine what, if anything, the unsigned TR-BRUME draft means for planning coordination; confirm whether RET-B contingent beneficiary evidence must be obtained; advise on required document inventory because EST-B v1 policy owner and required document/beneficiary tiers were not supplied in the records used here. [P5B1, P5B4, P5B5]",
        "",
        "## Native estate findings retained",
        "",
    ]
    if estate_findings:
        for finding in estate_findings:
            source_suffix = ""
            if finding.get("source_ids"):
                source_suffix = " Sources: " + ", ".join(finding["source_ids"]) + "."
            path = finding.get("path") or finding.get("upstream_artifact_id") or "n/a"
            message = finding["message"].rstrip(".")
            lines.append(f"- {finding['code']} ({path}): {message}.{source_suffix}")
    else:
        lines.append("- Native estate findings unavailable in this render.")
    lines += [
        "",
        "## Working files",
        "",
        "- working_tax_supported_input.json: source-backed tax facts and unevidenced fields retained.",
        "- working_tax_calculations.json: local sale and replacement-window calculations.",
        "- estate_native_input.json: native estate reviewer input with unknown policy fields preserved.",
        "- estate_native_output.json: native estate comparison output after validation, if present.",
        "- working_permission_check.json: declared recipient/source permission check.",
    ]
    return "\n".join(lines) + "\n"


def main() -> None:
    evidence, permission_packet = load_inputs()
    perm = permission_check(permission_packet)
    tax_input, tax_calc = tax_working(evidence, permission_packet)
    estate_input = estate_native_input(permission_packet)
    write_json("working_permission_check.json", perm)
    write_json("working_tax_supported_input.json", tax_input)
    write_json("working_tax_calculations.json", tax_calc)
    write_json("estate_native_input.json", estate_input)

    estate_output_path = OUT / "estate_native_output.json"
    estate_output = json.loads(estate_output_path.read_text()) if estate_output_path.exists() else None
    (OUT / "HH-BRUME_internal_draft_Ines_Dario_Celia_only.md").write_text(draft_text(tax_calc, estate_output, perm))
    write_json(
        "working_artifact_manifest.json",
        {
            "schema_version": "hh-brume-artifact-manifest-v1",
            "artifact_label": "working-artifact-manifest",
            "authorized_recipient_ids": RECIPIENTS,
            "household_id": "HH-BRUME",
            "as_of": AS_OF,
            "files": [
                {"path": "HH-BRUME_internal_draft_Ines_Dario_Celia_only.md", "type": "coordinated_internal_draft", "authorized_recipient_ids": RECIPIENTS},
                {"path": "working_permission_check.json", "type": "permission_working_file", "authorized_recipient_ids": RECIPIENTS},
                {"path": "working_tax_supported_input.json", "type": "structured_input", "authorized_recipient_ids": RECIPIENTS},
                {"path": "working_tax_calculations.json", "type": "calculation_output", "authorized_recipient_ids": RECIPIENTS},
                {"path": "estate_native_input.json", "type": "native_structured_input", "authorized_recipient_ids": RECIPIENTS},
                {"path": "estate_native_output.json", "type": "native_calculation_output", "authorized_recipient_ids": RECIPIENTS},
            ],
            "action_taken": False,
            "delivery_status": "not-delivered",
        },
    )


if __name__ == "__main__":
    main()
