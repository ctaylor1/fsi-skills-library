# HH-BRUME coordinated internal draft

Authorized recipient set: Ines, Dario, Celia only.
Prepared for: Ines (advisor), Dario (tax reviewer), Celia (estate counsel).
Not for client delivery. Human review required. Not delivered. No order, approval, transfer, beneficiary update, system change, or external contact was made.

Review as of: 2026-10-04. Household: HH-BRUME. Capacity: US advisory. Sources used: P5B1-P5B5.

## Permission and source posture

The supplied permission packet P5-02-SOURCES-v1 registers only Ines, Dario, and Celia as people recipients, and each source P5B1-P5B5 is current for this review date and allowed to the exact recipient set. This is a declared permission check, not delivery, identity authentication, or professional approval. [P5B1-P5B5]

## Proposed sale economics

Supported sale facts: B-A taxable TAX-B contains LOT-B, 100 units of SEC-B, acquired 2024-05-15, unit basis 75, unit price 52 on 2026-10-03. A proposed full sale on 2026-10-04 has a 40 fee and has not executed. [P5B2]

Supported arithmetic: gross proceeds 5200.00 = 100 x 52; cost basis 7500.00 = 100 x 75; net proceeds 5160.00 = 5200.00 - 40.00; gain/loss before wash review -2340.00. Positive taxable gain is 0.00; loss before wash review is -2340.00. [P5B2]

No tax reserve, deductible loss, or tax benefit is calculated because household gains, carryforwards, and an approved tax rate are absent; the 27% figure appears only as an unreviewed planner assumption and Dario has not accepted a rate or loss-disallowance conclusion. [P5B2, P5B3]

## Replacement-purchase / wash-sale review posture

The supplied 30-day screen around the 2026-10-04 sale runs from 2026-09-04 through 2026-11-03. B-B bought 25 units of SEC-B in RET-B on 2026-09-29, inside the lookback window, and the purchase and proposed sale are in the supplied same-exposure group. Potential replacement quantity for review is 25 units. [P5B3]

The RET-B statement header says IRA only; traditional/Roth and tax-deferred/tax-free treatment are unspecified. Activity coverage after 2026-10-04 is incomplete, and the future side of the replacement window remains open through 2026-11-03. Deductible loss and basis adjustments are not determined. [P5B3]

## Estate record comparison

Native estate comparison reviewed 2 supplied assets, found 1 literal coordination difference(s), and retained 15 open item(s). Status: needs-data. Artifact: estate-wealth-transfer-reviewer-6e9e02b04ddc05255218. Input hash: 6e9e02b04ddc052552183e5f97eb508ea8be48e73fcc3ef188cf05a6434839ab.

BANK-B: current title is B-A individual; the recorded client intention is TR-BRUME ownership pending counsel, with no transfer recorded. The bank beneficiary field cannot be treated as confirmed none-recorded because pages were never requested or loaded and legacy export rendered blank as none-recorded. Beneficiary intention was not collected. [P5B4]

RET-B: the primary page names B-A 100%; the contingent page is absent and no representation of no contingent designation was obtained. TR-BRUME trust draft is unsigned. The email subject line saying Approval complete is not an approval of legal substance; the body only confirms successful upload by an intake assistant. [P5B5]

The supplied upstream estate issue remains unresolved: Origin EST-B-19, title-intention-mismatch, says BANK-B individual title differs from the recorded trust-ownership intention. [P5B5]

## Next evidence needs by reviewer

Ines: confirm whether the proposed sale remains only proposed; obtain current trade-ready pricing/fees if the team later considers action; collect complete household purchase/reinvestment/forward-order coverage through 2026-11-03; obtain complete BANK-B beneficiary pages or custodian confirmation; confirm source ownership and any current account-title extracts. [P5B2, P5B3, P5B4]

Dario: determine whether SEC-B sale and the 25-unit RET-B purchase create a wash-sale or IRA-related issue; decide whether RET-B tax treatment matters and obtain traditional/Roth/tax-deferred/tax-free evidence; provide any approved rate/budget/carryforward/gain context if a tax-benefit or reserve illustration is desired. [P5B2, P5B3]

Celia: review the unresolved BANK-B title versus TR-BRUME intention; determine what, if anything, the unsigned TR-BRUME draft means for planning coordination; confirm whether RET-B contingent beneficiary evidence must be obtained; advise on required document inventory because EST-B v1 policy owner and required document/beneficiary tiers were not supplied in the records used here. [P5B1, P5B4, P5B5]

## Native estate findings retained

- upstream-unresolved (upstream_issues[0]): BANK-B individual title differs from recorded trust-ownership intention.
- policy-owner-unknown (policy.owner): Accountable policy owner is not supplied; obtain separate policy confirmation.
- policy-requirements-unknown (policy.required_document_kinds): Required review inventory is not supplied; no completeness assertion or default requirements.
- policy-requirements-unknown (policy.required_beneficiary_tiers): Required review inventory is not supplied; no completeness assertion or default requirements.
- recorded-document-links-unknown (designations[0].document_ids): Designation document links were not collected.
- document-status-gap (documents): Confirm document date and recorded status with counsel; no validity inference.
- recorded-document-links-unknown (BANK-B): Recorded asset document links were not collected; no link mismatch can be established.
- designation-gap (BANK-B): Recorded beneficiary evidence is unavailable.
- document-intention-unknown (BANK-B): Intended governing-document links not collected.
- beneficiary-intention-unknown (BANK-B): Beneficiary intention not collected; no inference from current records.
- coordination-difference (BANK-B): intended owners differ from recorded owners; counsel/custodian confirmation required. Sources: P5B4.
- recorded-document-links-unknown (RET-B): Recorded asset document links were not collected; no link mismatch can be established.
- owner-intention-unknown (RET-B): Intended titling not collected.
- document-intention-unknown (RET-B): Intended governing-document links not collected.
- beneficiary-intention-unknown (RET-B): Beneficiary intention not collected; no inference from current records.

## Working files

- working_tax_supported_input.json: source-backed tax facts and unevidenced fields retained.
- working_tax_calculations.json: local sale and replacement-window calculations.
- estate_native_input.json: native estate reviewer input with unknown policy fields preserved.
- estate_native_output.json: native estate comparison output after validation, if present.
- working_permission_check.json: declared recipient/source permission check.
