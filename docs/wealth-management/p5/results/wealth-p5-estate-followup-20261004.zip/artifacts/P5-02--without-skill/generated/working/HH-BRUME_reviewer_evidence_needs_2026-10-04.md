# HH-BRUME Reviewer Evidence Needs

Authorized recipient set: Ines, Dario, Celia only.
Review date: 2026-10-04.
Status: Working artifact for internal draft support only.

## Ines

- Confirm transaction details and proposed-only status for the TAX-B sale: SEC-B, LOT-B, 100 units, price, fee, and no execution. [P5B2]
- Provide complete same-exposure activity coverage through the relevant review window; supplied records say activity coverage after October 4 is incomplete. [P5B3]
- Confirm whether BANK-B trust-ownership intention remains current and whether beneficiary intention should be collected. [P5B4]

## Dario

- Review whether B-B's September 29 RET-B purchase of 25 units SEC-B affects the proposed taxable loss in the supplied same-exposure group. [P5B3]
- Approve, replace, or reject the unreviewed 27% draft planner rate. [P5B3]
- Obtain household gains, carryforwards, and tax offset data; those are absent. [P5B2]
- Clarify RET-B tax character because the supplied evidence only says IRA header, not Traditional/Roth or tax-deferred/tax-free treatment. [P5B3]

## Celia

- Resolve EST-B-19 `title-intention-mismatch` for BANK-B, where B-A individual title differs from recorded TR-BRUME ownership intention. [P5B4, P5B5]
- Provide executed trust evidence or confirm TR-BRUME remains unsigned. [P5B5]
- Obtain BANK-B beneficiary pages or custodian confirmation, and collect BANK-B beneficiary intention. [P5B4]
- Obtain RET-B contingent beneficiary evidence or a representation that no contingent beneficiary exists. [P5B5]

