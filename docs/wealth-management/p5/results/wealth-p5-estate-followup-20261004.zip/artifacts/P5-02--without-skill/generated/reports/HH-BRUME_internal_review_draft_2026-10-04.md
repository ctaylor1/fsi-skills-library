# HH-BRUME Tax-Aware Investment Review and Estate-Record Comparison

Authorized recipient set: Ines, Dario, Celia only.
Review date: 2026-10-04.
Currency: USD.
Status: Internal draft for human review only. Do not send, place orders, approve a transaction, update records, or treat this as tax or legal advice.
Source packet used: `resources/source-packet.json`, packet `P5-02-SOURCES-v1`; all cited sources list allowed recipients Ines, Dario, Celia.

## Scope and Source Controls

HH-BRUME is a US advisory household in USD with clients B-A and B-B. The supplied comparison policies are TAX-B v3 and EST-B v1, effective October 1 through December 31. Account tax treatment and current or intended designations require source evidence, and record comparisons are not legal determinations. [P5B1]

Only the supplied records were used. The root `source_packet.json` contains the record content; `resources/source-packet.json` contains the same source records with the recipient/access envelope. The permissioned packet names only Ines, Dario, and Celia as recipients. [P5B1-P5B5; packet `P5-02-SOURCES-v1`]

## Executive Draft

The proposed sale is a full sale of LOT-B in B-A taxable TAX-B: 100 units of SEC-B acquired May 15, 2024, with unit basis 75 and October 3 unit price 52. The supplied illustration says the proposed October 4 sale would incur a 40 fee that reduces proceeds, and that no sale has been executed. [P5B2]

Supported sale economics:

| Item | Supported amount | Source or method |
| --- | ---: | --- |
| Units proposed for sale | 100 | P5B2 |
| Unit price | 52 | P5B2 |
| Gross proceeds | 5,200 | 100 units x 52, from P5B2 |
| Sale fee | 40 | P5B2 |
| Net proceeds after fee | 5,160 | 5,200 - 40, fee treatment from P5B2 |
| Unit basis | 75 | P5B2 |
| Total basis | 7,500 | 100 units x 75, from P5B2 |
| Supported realized loss before tax | -2,340 | 5,160 - 7,500, from P5B2 |
| Holding period | 872 days, long-term if sold 2026-10-04 | May 15, 2024 to October 4, 2026, from P5B2 |

The supplied records do not support a final tax benefit. Household gains, carryforwards, and an approved tax rate are absent. A draft planner note uses 27% as an unreviewed tax-benefit assumption, but Dario has not accepted a rate or loss-disallowance conclusion. [P5B2, P5B3]

If and only if the 27% draft rate were accepted and the full loss were allowed, the arithmetic tax effect would be 631.80. This is not an approved estimate and should remain an assumption placeholder until Dario reviews tax rate, household offset capacity, and loss-disallowance risk. [P5B3]

## Tax-Aware Investment Review

Supplied investment facts:

| Topic | Supplied fact | Draft implication |
| --- | --- | --- |
| Proposed taxable sale | B-A taxable TAX-B contains LOT-B: 100 units SEC-B; full sale proposed October 4; no sale executed. [P5B2] | The economics can be modeled, but the report must not imply execution or approval. |
| Loss economics | Net proceeds 5,160 against total basis 7,500, producing a supported pre-tax loss of 2,340. [P5B2] | Potential harvesting benefit is plausible only as a review topic, not a conclusion. |
| Same-exposure record | B-B bought 25 units SEC-B on September 29 in RET-B; the purchase and proposed sale are in the supplied same-exposure group. [P5B3] | Dario should review whether any loss-disallowance rule or policy constraint applies. |
| RET-B tax treatment | RET-B statement header says IRA only; Traditional/Roth and tax-deferred/tax-free treatment are unspecified. [P5B3] | Do not assume account tax character beyond "IRA header supplied." |
| Tax inputs absent | Household gains, carryforwards, and approved tax rate are absent. [P5B2] | Do not state net tax benefit or suitability of the sale without tax review. |
| Coverage limitation | Activity coverage after October 4 is incomplete. [P5B3] | Confirm there are no additional same-exposure purchases or account activity before final advice. |

Draft tax posture for reviewers: the sale economics support a loss of 2,340 before tax, subject to Dario's review of tax rate, offset capacity, and loss-disallowance treatment. The 27% figure is a planner note assumption only and should not be used as an accepted client-specific rate. [P5B2, P5B3]

## Estate-Record Comparison

Supplied estate and title facts:

| Record area | Supplied current record | Supplied intended or comparison record | Draft comparison |
| --- | --- | --- | --- |
| BANK-B title | Current title is B-A individual. [P5B4] | Client intention is TR-BRUME ownership pending counsel; no transfer recorded. [P5B4] | Mismatch remains unresolved. This is a record comparison, not a legal determination. [P5B1, P5B5] |
| BANK-B beneficiary field | Blank bank beneficiary field reflects pages never requested or loaded, not confirmation of absence. Legacy export rendered blank as none-recorded. [P5B4] | BANK-B beneficiary intention was not collected. [P5B4] | Beneficiary status and intended beneficiary are unknown. Do not infer no beneficiary. |
| RET-B beneficiary | Primary page names B-A 100%. [P5B5] | Contingent page is absent and no representation of no contingent designation was obtained. [P5B5] | Primary beneficiary is evidenced; contingent beneficiary status is unknown. |
| TR-BRUME trust | TR-BRUME trust draft is unsigned. [P5B5] | No completed trust approval is evidenced; "Approval complete" email body confirms only successful upload by an intake assistant. [P5B5] | Treat trust status as draft/unsigned unless counsel supplies executed documents. |
| EST-B issue | Origin EST-B-19, code `title-intention-mismatch`: BANK-B individual title differs from recorded trust-ownership intention; unresolved. [P5B5] | Not resolved in supplied records. [P5B5] | Celia should resolve title/intention and evidence needed transfer or decision not to transfer. |

Draft estate posture for reviewers: BANK-B title conflicts with the recorded trust-ownership intention, but no transfer is recorded and the trust is unsigned. RET-B primary beneficiary is evidenced as B-A 100%, while contingent beneficiary status remains unknown. Blank BANK-B beneficiary fields are evidence gaps, not negative confirmations. [P5B4, P5B5]

## Reviewer Next Evidence Needs

Ines, advisor:

- Confirm the proposed transaction ticket details before any recommendation: security identifier for SEC-B, account TAX-B, LOT-B quantity, current price, expected fee, and whether the sale is still only proposed. Supported current facts show a proposed full sale and no execution. [P5B2]
- Obtain or point Dario to complete same-exposure activity through the review date and any later relevant coverage, because supplied activity after October 4 is incomplete. [P5B3]
- Confirm with the client or records team whether BANK-B ownership intention is still TR-BRUME and whether beneficiary intention should be collected; current supplied record says title is B-A individual, trust ownership is only an intention pending counsel, and beneficiary intention was not collected. [P5B4]

Dario, tax reviewer:

- Determine whether the 2,340 supported loss is allowable, deferred, or otherwise adjusted in light of B-B's September 29 purchase of SEC-B in RET-B and the supplied same-exposure group. [P5B2, P5B3]
- Supply or reject an approved household tax rate, and confirm whether the unreviewed 27% planner assumption may be used. Current records say Dario has not accepted a rate or loss-disallowance conclusion. [P5B3]
- Request household gains, carryforwards, and other tax-offset inputs; those fields are absent from supplied records. [P5B2]
- Clarify whether RET-B is Traditional, Roth, tax-deferred, tax-free, or otherwise treated for the relevant analysis; the supplied statement header says IRA only. [P5B3]

Celia, estate counsel:

- Resolve whether BANK-B should remain titled to B-A individually or be transferred to TR-BRUME; supplied records show title-intention mismatch EST-B-19 remains unresolved. [P5B4, P5B5]
- Provide executed trust documents or confirm that TR-BRUME remains unsigned; supplied records evidence only an unsigned draft and an upload confirmation email, not approval. [P5B5]
- Obtain the missing BANK-B beneficiary pages or custodian confirmation, and collect BANK-B beneficiary intention. Blank fields are not confirmation of absence. [P5B4]
- Obtain RET-B contingent beneficiary page or a representation that no contingent designation exists. Supplied records evidence only the primary page naming B-A 100%. [P5B5]

## Unknowns Preserved

- Approved tax rate: unknown. [P5B2, P5B3]
- Household gains and carryforwards: unknown. [P5B2]
- Final tax benefit or cost of the proposed sale: unknown. [P5B2, P5B3]
- Loss-disallowance conclusion for the SEC-B same-exposure group: unknown. [P5B3]
- RET-B Traditional/Roth or tax-deferred/tax-free treatment: unknown. [P5B3]
- BANK-B beneficiary status and beneficiary intention: unknown. [P5B4]
- RET-B contingent beneficiary status: unknown. [P5B5]
- TR-BRUME executed status: unsigned draft in supplied records; no executed trust evidenced. [P5B5]

## Source Register

- P5B1: Synthetic record; custodian Ines; recorded 2026-10-04; current through 2026-10-31; allowed recipients Ines, Dario, Celia.
- P5B2: Synthetic record; custodian extract owner Jori; recorded 2026-10-03; current through 2026-10-31; allowed recipients Ines, Dario, Celia.
- P5B3: Synthetic record; custodian Ines recording B-B; recorded 2026-10-04; current through 2026-10-31; allowed recipients Ines, Dario, Celia.
- P5B4: Synthetic record; custodian Jori; recorded 2026-10-04; current through 2026-10-31; allowed recipients Ines, Dario, Celia.
- P5B5: Synthetic record; custodian Celia document intake; recorded 2026-10-04; current through 2026-10-31; allowed recipients Ines, Dario, Celia.
