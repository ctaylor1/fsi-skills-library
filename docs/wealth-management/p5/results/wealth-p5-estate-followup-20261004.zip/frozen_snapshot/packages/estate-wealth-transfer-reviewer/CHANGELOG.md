# Changelog — estate-wealth-transfer-reviewer

## 0.2.1 — 2026-10-04

- Preserve uncollected policy owner, requirement inventories, asset owners and document links as explicit nulls with needs-data findings. Withhold dependent mismatch/completeness assertions.
- Correct the schema pressure exposed by P5-02; original first-pass model failure remains retained separately from follow-up evaluation.

## 0.2.0 — 2026-10-04

- Add portable source-field review and exact-recipient draft gates for P5.
- Preserve existing calculation modes; distinguish native validation from separately reviewed source fidelity and audience scope.

## [0.1.0] — 2026-09-16
- Added the scoped wealth P1 practitioner workflow, substantive source-linked domain results and explicit missingness.
- Added versioned policy applicability, canonical wealth evidence envelope, upstream issue propagation and full snapshot/hash reconstruction.
- Added synthetic complete/incomplete/tampered fixtures and executable arithmetic, evidence, boundary and no-action regressions.
- Controlled integrations, professional SME sign-off, real-model baseline and production privacy/records/release gates remain pending.
