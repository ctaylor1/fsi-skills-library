#!/usr/bin/env python3
"""Replay unchanged model-writer artifacts through frozen P5 gates.

--record creates first audit outputs; default checks the retained record without
replacing any writer artifact or audit decision. All semantic field decisions
were made separately by the disclosed model reviewer, not generated here.
"""
from pathlib import Path
import collections
import hashlib
import json
import os
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ORIGINALS = BASE / 'originals'
RESULTS = BASE / 'results'
CODE = BASE / 'frozen-code'
sys.path.insert(0, str(CODE))
import evidence_gate
import audience_gate
import quality_gate


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    record = sys.argv[1:] == ['--record']
    if sys.argv[1:] not in ([], ['--record']):
        raise SystemExit('Use --record once, or no arguments to verify retained results.')
    manifest = load(BASE / 'original-bindings.json')
    for entry in manifest['records']:
        assert sha(BASE / entry['copy']) == entry['sha256'], entry
    candidate, packet, inventory, review = [load(p) for p in [ORIGINALS/'candidate.json', ORIGINALS/'source-packet.json', ORIGINALS/'inventory.json', BASE/'field-review.json']]
    request, plan = load(ORIGINALS/'request.json'), load(ORIGINALS/'plan.json')
    assert inventory == evidence_gate.make_inventory(candidate, packet, inventory['producer_id'])
    field = evidence_gate.check(candidate, packet, inventory, review)
    projection = audience_gate.project(request, packet, plan)
    quality = quality_gate.assemble(candidate, packet, inventory, review, request, plan)
    assert field['status'] == 'blocked' and field['projected_input'] is None
    assert quality['status'] == 'blocked' and quality['recipient_draft'] is None
    assert projection['rendered_markdown'].encode() == (ORIGINALS/'writer-rendered.md').read_bytes()
    assert audience_gate.validate_rendered(request, packet, plan, (ORIGINALS/'writer-rendered.md').read_bytes(), load(ORIGINALS/'writer-audience-receipt.json')) == []
    ids = {f['claim_id'] for f in inventory['fields']}
    missing = [{'block_id':b['block_id'],'claim_id':p} for b in plan['blocks'] for p in b['claim_ids'] if p not in ids]
    assert len(missing) == 7
    common = ['--candidate',str(ORIGINALS/'candidate.json'),'--sources',str(ORIGINALS/'source-packet.json'),'--inventory',str(ORIGINALS/'inventory.json')]
    field_args = common + ['--review',str(BASE/'field-review.json')]
    audience_args = ['--request',str(ORIGINALS/'request.json'),'--source-packet',str(ORIGINALS/'source-packet.json'),'--plan',str(ORIGINALS/'plan.json')]
    quality_args = common + ['--field-review',str(BASE/'field-review.json'),'--request',str(ORIGINALS/'request.json'),'--plan',str(ORIGINALS/'plan.json')]
    operations = [
      ('field-check',[str(CODE/'evidence_gate.py'),'check',*field_args],1,'field-receipt.json'),
      ('field-reconstruction',[str(CODE/'evidence_gate.py'),'validate',*field_args,'--receipt',str(RESULTS/'field-receipt.json')],0,None),
      ('writer-audience-readback',[str(CODE/'audience_gate.py'),'validate',*audience_args,'--rendered',str(ORIGINALS/'writer-rendered.md'),'--receipt',str(ORIGINALS/'writer-audience-receipt.json')],0,None),
      ('audience-rebuild',[str(CODE/'audience_gate.py'),'render',*audience_args,'--rendered',str(RESULTS/'audience-rebuilt.md'),'--receipt',str(RESULTS/'audience-rebuilt-receipt.json')],0,None),
      ('combined-blocked',[str(CODE/'quality_gate.py'),*quality_args,'--receipt',str(RESULTS/'quality-result.json'),'--rendered',str(RESULTS/'recipient-reviewed.md')],1,None),
      ('combined-actual-byte-rejection',[str(CODE/'quality_gate.py'),*quality_args,'--receipt',str(RESULTS/'quality-result.json'),'--rendered',str(ORIGINALS/'writer-rendered.md'),'--verify'],1,None),
    ]
    if record:
        log = []
        for name,args,expected,output in operations:
            result = subprocess.run([sys.executable,'-B',*args],cwd=BASE,capture_output=True,text=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
            assert result.returncode == expected, (name,result.returncode,result.stdout,result.stderr)
            if output:
                with (RESULTS/output).open('x') as stream: stream.write(result.stdout)
                os.chmod(RESULTS/output,0o600)
            log.append({'name':name,'argv':[sys.executable,'-B',*args],'exit_code':result.returncode,'expected_exit_code':expected,'stdout':result.stdout if not output else {'path':'results/'+output,'sha256':sha(RESULTS/output)},'stderr':result.stderr})
        with (RESULTS/'cli-transcript.json').open('x') as stream:json.dump({'python':sys.version,'operations':log},stream,indent=2)
        with (RESULTS/'unresolved-plan-claims.json').open('x') as stream:json.dump(missing,stream,indent=2)
    else:
        assert load(RESULTS/'unresolved-plan-claims.json') == missing
    assert evidence_gate.validate_receipt(load(RESULTS/'field-receipt.json'),candidate,packet,inventory,review) == []
    assert audience_gate.validate_rendered(request,packet,plan,(RESULTS/'audience-rebuilt.md').read_bytes(),load(RESULTS/'audience-rebuilt-receipt.json')) == []
    assert (RESULTS/'audience-rebuilt.md').read_bytes() == (ORIGINALS/'writer-rendered.md').read_bytes()
    assert evidence_gate.hash_object(load(RESULTS/'quality-result.json')) == evidence_gate.hash_object(quality)
    errors = quality_gate.validate(quality,candidate,packet,inventory,review,request,plan,None,(ORIGINALS/'writer-rendered.md').read_bytes())
    assert errors and not (RESULTS/'recipient-reviewed.md').exists()
    summary = {'run_id':manifest['run_id'],'purpose':'post-generation control audit; initial scoring unchanged',
      'reviewed_field_count':len(review['decisions']),'decision_verdicts':dict(collections.Counter(d['verdict'] for d in review['decisions'])),
      'evidence_gate_status':field['status'],'qualified_field_count':len(field['reviewed_fields']),'blocked_field_count':len(field['withheld_claim_ids']),
      'withheld_claim_ids':field['withheld_claim_ids'],'audience_byte_readback':'matches exact writer machine-rendered artifact',
      'combined_gate_status':quality['status'],'combined_recipient_file_created':False,'unresolved_plan_claim_count':len(missing),
      'writer_human_memo':'Separate bytes are not the audience-gate render and receive no combined clearance in this audit.',
      'field_review_sha256':sha(BASE/'field-review.json'),'original_binding_manifest_sha256':sha(BASE/'original-bindings.json')}
    if record:
        with (RESULTS/'summary.json').open('x') as stream:json.dump(summary,stream,indent=2)
        for path in RESULTS.iterdir():os.chmod(path,0o600)
    else:assert summary == load(RESULTS/'summary.json')
    print(json.dumps(summary,indent=2))


if __name__ == '__main__':
    main()
