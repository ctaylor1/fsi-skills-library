# P5-03 with-skill: post-generation control audit

The unchanged completed writer artifact remains **blocked**. Independent model decisions cover all **93 of 93 inventoried candidate fields**; the evidence gate qualifies 82 and withholds 11. The audience-only check reproduces the writer's machine-rendered draft byte for byte, but the combined gate creates no reviewed recipient file. These are post-generation control results, separate from the initial P5 rubric scoring.

## Scope and reviewer disclosure

The selected first-pass run is `P5-03--with-skill`, completed from 2026-10-05 02:17:44.732477 UTC to 02:24:03.236890 UTC. Its retained runtime records requested GPT-5.5/high through Codex CLI 0.151.0; the exact backend identity is unavailable. Review began only after completion. No live partial output or hidden rubric was read.

The reviewer is a separate model agent from the CLI producer. The condition is visible. The reviewer authored the evidence component, contributed to the combined control, and previously authored the recommendation evidence package. This is generation-independent review, not blinded or organizationally independent review. Reviewer identity is declared, not authenticated. No human, legal, investment, supervisory, or professional approval is implied. The field decisions do not replace the missing client-evidence reviews described in the source packet.

All 18 retained original and frozen-code copies match their source files. `original-bindings.json` identifies original paths and raw-file hashes, plus the completed writer event trace hash. Candidate, inventory, source packet, plan, request, fee calculation, both memo files, and original receipts were not repaired or rewritten. The audit runs the controls copied from this model condition, not later mutable repository code.

## Independent source-field decisions

`field-review.json` binds the unchanged candidate, detached typed source packet, and writer inventory by their canonical JSON hashes. Every inventoried field receives a semantic decision and a rationale. There are 90 supported decisions and 3 unsupported decisions; no inventoried field is left unreviewed. These verdict counts are distinct from the gate's stricter representational qualification: supported semantic judgments about legitimate local metadata can still be blocked by the permitted schema.

The two clear unsupported financial assertions are `USD` in `/fee_quotes/balance_for_illustration/currency` and `/client_and_alignment_facts/near_term_liquidity_need/currency` (`originals/candidate.json`, lines 52 and 88). P5C2 supplies the balance and fee numbers, and P5C3 supplies the liquidity amount, but neither the natural-language packet nor its typed copy supplies a currency. US brokerage capacity does not establish the currency of either amount.

A third decision cautiously withholds `/fee_quotes/current_plan/one_time_exit_fee_recorded` (`originals/candidate.json`, line 61). P5C2 says “no one-time exit fee recorded”; the candidate represents this as numeric zero. Absence of a recorded charge is insufficient for a known zero fee used in a complete economic comparison. The `_recorded` suffix makes this interpretation less categorical than the currency findings: if the intended meaning is only a count or amount recorded in the supplied documents, it should be clarified explicitly. This audit records the conservative semantic judgment; it does not claim the packet proves a positive exit fee or treat this as an independently established arithmetic error.

Eight additional withheld fields are contract or representation limits rather than fabricated financial facts:

- `/artifact_label`, `/artifact_type`, `/not_for_external_delivery`, `/review_as_of`, `/source_files_used/0`, `/source_files_used/1`, and `/permission_resource/source_file` are credible local or task metadata. Their keys or value types do not fit the frozen gate's narrow `local-label` rule. They were not relabeled, deleted, or given invented source quotations to obtain a passing receipt.
- `/permission_resource/packet_id` matches the detached packet's top-level identifier. The frozen evidence schema supports citations into individual source rows, not a binding to that top-level metadata. The review explains this with an audit pointer but leaves its source-evidence list empty, so the control withholds it.

The candidate usefully preserves four null observations: exact native recommendation action, assessed loss capacity, final comparison conclusion, and disclosure delivery receipt. It also preserves the correction withdrawing copied Quinn/October 2 evidence-review attribution, future assignments rather than completed reviews, the unresolved liquidity-versus-growth concern, and the pending affiliated-fee conflict review. These source-supported observations remain available in the blocked receipt; no full projected input is released.

## Content-plan lineage

A separate deterministic inspection finds **seven plan claim pointers absent from the candidate's leaf inventory**. The finding is retained in `results/unresolved-plan-claims.json`:

- `quoted-fee-comparison` references `/outputs/current_plan_annual_fee`, `/outputs/proposed_managed_account_annual_ongoing_fee`, and `/outputs/first_year_difference_including_setup` (`originals/plan.json`, lines 49–51). These values exist in a different fee-calculation artifact, not the inventoried candidate.
- `next-questions` references the whole `/review_readiness_facts/assigned_future_reviews` container (line 110).
- `working-files` references whole `/authorized_recipient_set`, `/source_files_used`, and `/permission_resource/requested_recipient_ids` containers (lines 131–133). The inventory identifies their leaves, not these containers.

The combined control stops earlier because the field receipt is blocked; therefore these seven errors are static audit findings, not errors reached by that CLI invocation. No synthetic merged candidate, expanded inventory, or replacement plan was supplied.

The separate fee file's basic arithmetic is useful: 240000 × 35/10000 = 840; 240000 × 90/10000 = 2160; 2160 + 150 = 2310; ongoing difference 1320 and first-year quoted difference 1470. This spot-check does not establish omitted costs, currency, source completeness, or a gate-qualified derived claim. The writer's native-tool limitation correctly explains that an exact recommendation action was not supplied. This audit does not invent that action or run a native workflow on manufactured input.

## Retained gate replay

Six real CLI operations are retained in `results/cli-transcript.json`:

1. Evidence check exits 1 with status `blocked`, 82 qualified and 11 withheld fields, and `projected_input: null`.
2. Evidence receipt reconstruction exits 0 with no errors. This means the blocked receipt is faithful, not that the candidate is accepted.
3. Audience-only validation of the writer's original machine-rendered draft and original receipt exits 0.
4. Audience rendering exits 0 and produces bytes identical to the writer's machine-rendered draft. The supplied permissions limit the declared audience to Nessa and Quinn. This checks declared permission dependencies and exact rendered bytes; it is not an independent authentication of permission, a substantive source check, delivery, or combined clearance.
5. Combined assembly exits 1 with status `blocked` and no recipient draft. `results/recipient-reviewed.md` is absent.
6. Combined verification against the actual unchanged machine-rendered writer bytes also exits 1. Passing the audience-only check does not turn those bytes into a fully reviewed draft.

The separate human-readable memo has different bytes from the audience render and receives no transferred clearance. This audit does not supply a final prose-review approval after a blocked field review. It also does not assess all claims in every prose artifact or turn coverage of the candidate's 93 fields into a claim of complete semantic validation of the entire writer output.

## Reproduction and limits

Run the retained verifier without `--record`:

```sh
PYTHONDONTWRITEBYTECODE=1 /private/tmp/fsi-p5-venv/bin/python -B /private/tmp/wealth-p5-20261004-rnbphp89/experiment/control-audit/P5-03--with-skill/replay.py
```

It verifies original-copy hashes, inventory reconstruction, field receipt, exact audience bytes, combined blocked result, the seven unresolved plan claims, and the absence of a reviewed recipient file. `--record` was used once to retain the original six CLI invocations; normal replay does not replace the record or writer artifacts.

This single observed case demonstrates a useful blocked handoff on an actual model-generated extraction. It does not establish overall model performance, causality, production readiness, reviewer authentication, complete source truth, or a general success rate. Exact quotation and hashes establish bindings; semantic judgments remain those of the disclosed model reviewer. No external action, account change, recommendation approval, or delivery occurred in this audit.
