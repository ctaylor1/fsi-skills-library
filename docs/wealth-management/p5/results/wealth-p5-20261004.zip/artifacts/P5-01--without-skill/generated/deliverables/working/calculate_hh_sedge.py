# Authorized recipient set: Liora, Tamsin only.
# Purpose: local reproducible calculations for HH-SEDGE planning-to-IPS drafts.

import json
from decimal import Decimal, ROUND_HALF_UP, getcontext
from pathlib import Path

getcontext().prec = 28

REVIEW_DATE = "2026-10-04"
AUTHORIZED_RECIPIENTS = ["Liora", "Tamsin"]


def money(value: Decimal) -> Decimal:
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def pct(value: Decimal) -> Decimal:
    return value.quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)


def annual_inflated_cost(today_cost: Decimal, annual_rate: Decimal, months: int) -> Decimal:
    years = Decimal(months) / Decimal(12)
    return money(today_cost * ((Decimal(1) + annual_rate) ** years))


inputs = {
    "artifact_label": "HH-SEDGE structured planning and IPS inputs",
    "review_date": REVIEW_DATE,
    "authorized_recipient_set": AUTHORIZED_RECIPIENTS,
    "distribution_limit": "Liora and Tamsin only",
    "permission_resource": {
        "path": "resources/source-packet.json",
        "packet_id": "P5-01-SOURCES-v1",
        "schema_version": "wealth-source-packet-v1",
        "source": "P5A1-P5A5 access metadata",
    },
    "household": {
        "household_id": "HH-SEDGE",
        "currency": "USD",
        "jurisdiction": "US advisory household",
        "clients": ["S-A", "S-B"],
        "sources": ["P5A1"],
    },
    "methods": {
        "planning_method": "PLAN-S v1",
        "ips_method": "IPS-S v2",
        "effective_window": "2026-10-01 through 2026-12-31",
        "sources": ["P5A1"],
    },
    "inventory": {
        "joint_taxable_JT_S": 410000,
        "cash_CASH_S": 70000,
        "debt_D_S": 82000,
        "protected_cash_floor": 25000,
        "monthly_take_home_income": 11500,
        "monthly_regular_spending_excluding_debt": 7600,
        "monthly_debt_service": 720,
        "sources": ["P5A2"],
    },
    "goals": [
        {
            "goal_id": "G-T",
            "name": "Tuition",
            "today_dollar_cost": 108000,
            "due_months": 36,
            "allocated_cash": 18000,
            "proposed_monthly_saving": 1600,
            "annual_cost_inflation": 0.03,
            "return_assumption": 0,
            "sources": ["P5A3"],
        },
        {
            "goal_id": "G-H",
            "name": "Home accessibility",
            "today_dollar_cost": 64000,
            "due_months": 24,
            "allocated_cash": 12000,
            "proposed_monthly_saving": 1100,
            "annual_cost_inflation": 0.03,
            "return_assumption": 0,
            "sources": ["P5A3"],
        },
    ],
    "ips_discussion_inputs": {
        "proposed_scope": "JT-S only",
        "cash_scope": "CASH-S remains outside",
        "discussion_allocation": {"equity": 0.50, "fixed_income": 0.40, "cash": 0.10},
        "bands": {"equity": [0.40, 0.60], "fixed_income": [0.30, 0.50], "cash": [0, 0.20]},
        "restrictions": ["No leverage", "No direct tobacco"],
        "review_cycle": "Annual review",
        "band_departure_action": "Human review, not automatic trades",
        "benchmark": None,
        "governing_risk_constraint": None,
        "questionnaire_willingness": "10% loss on 480000 household investment/cash inventory",
        "professional_capacity_assessment": None,
        "joint_owner_assent_to_mandate": None,
        "approval_status": "No prior IPS, approval, effective mandate date, signed planning artifact, or historical hash recorded",
        "sources": ["P5A1", "P5A4", "P5A5"],
    },
    "calculation_assumptions": {
        "future_cost_formula": "today_dollar_cost * (1 + annual_cost_inflation) ** (due_months / 12)",
        "contribution_timing": "End-month contributions; zero return, so contributions sum arithmetically.",
        "priority_treatment": "No client ranking assumed; legacy export numbering is entry order only.",
        "sources": ["P5A3", "P5A5"],
    },
}

inventory = inputs["inventory"]
monthly_income = Decimal(inventory["monthly_take_home_income"])
monthly_spending = Decimal(inventory["monthly_regular_spending_excluding_debt"])
monthly_debt_service = Decimal(inventory["monthly_debt_service"])
monthly_baseline_surplus = monthly_income - monthly_spending - monthly_debt_service

cash = Decimal(inventory["cash_CASH_S"])
protected_floor = Decimal(inventory["protected_cash_floor"])
total_allocated_goal_cash = sum(Decimal(g["allocated_cash"]) for g in inputs["goals"])
unallocated_cash_after_goal_allocations = cash - total_allocated_goal_cash
cash_above_floor_after_goal_allocations = unallocated_cash_after_goal_allocations - protected_floor

goal_results = []
for goal in inputs["goals"]:
    today_cost = Decimal(goal["today_dollar_cost"])
    annual_rate = Decimal(str(goal["annual_cost_inflation"]))
    months = int(goal["due_months"])
    allocated = Decimal(goal["allocated_cash"])
    proposed_monthly = Decimal(goal["proposed_monthly_saving"])
    future_cost = annual_inflated_cost(today_cost, annual_rate, months)
    proposed_contributions = proposed_monthly * Decimal(months)
    total_supported = money(allocated + proposed_contributions)
    shortfall = money(future_cost - total_supported)
    required_monthly = money((future_cost - allocated) / Decimal(months))
    incremental_monthly_needed = money(required_monthly - proposed_monthly)
    goal_results.append(
        {
            "goal_id": goal["goal_id"],
            "name": goal["name"],
            "due_months": months,
            "today_dollar_cost": money(today_cost),
            "inflated_cost_at_due_date": future_cost,
            "allocated_cash": money(allocated),
            "proposed_monthly_saving": money(proposed_monthly),
            "proposed_total_new_saving": money(proposed_contributions),
            "total_supported_by_current_plan": total_supported,
            "shortfall_at_due_date": shortfall,
            "funded_ratio_of_inflated_cost": pct(total_supported / future_cost),
            "monthly_saving_required_to_fully_fund_without_extra_cash": required_monthly,
            "incremental_monthly_needed_above_proposed": incremental_monthly_needed,
            "sources": goal["sources"],
        }
    )

first_24_goal_saving = sum(Decimal(g["proposed_monthly_saving"]) for g in inputs["goals"])
monthly_residual_first_24 = monthly_baseline_surplus - first_24_goal_saving
months_25_36_goal_saving = Decimal(inputs["goals"][0]["proposed_monthly_saving"])
monthly_residual_months_25_36 = monthly_baseline_surplus - months_25_36_goal_saving
full_funding_monthly_first_24 = sum(
    Decimal(str(r["monthly_saving_required_to_fully_fund_without_extra_cash"]))
    for r in goal_results
    if r["due_months"] <= 36
)

calculation_output = {
    "artifact_label": "HH-SEDGE cash-flow and goal calculation output",
    "review_date": REVIEW_DATE,
    "authorized_recipient_set": AUTHORIZED_RECIPIENTS,
    "distribution_limit": "Liora and Tamsin only",
    "source_scope": "Computed from supplied local records only: source_packet.json and resources/source-packet.json.",
    "cash_flow": {
        "monthly_take_home_income": money(monthly_income),
        "monthly_regular_spending_excluding_debt": money(monthly_spending),
        "monthly_debt_service": money(monthly_debt_service),
        "monthly_baseline_surplus_before_goal_saving": money(monthly_baseline_surplus),
        "proposed_goal_saving_months_1_24": money(first_24_goal_saving),
        "monthly_residual_after_proposed_goal_saving_months_1_24": money(monthly_residual_first_24),
        "proposed_goal_saving_months_25_36_if_only_tuition_continues": money(months_25_36_goal_saving),
        "monthly_residual_months_25_36_if_home_saving_stops_and_no_transfers_are_modeled": money(monthly_residual_months_25_36),
        "sources": ["P5A2", "P5A3"],
    },
    "balance_sheet": {
        "joint_taxable_JT_S": money(Decimal(inventory["joint_taxable_JT_S"])),
        "cash_CASH_S": money(cash),
        "debt_D_S": money(Decimal(inventory["debt_D_S"])),
        "investment_and_cash_inventory": money(Decimal(inventory["joint_taxable_JT_S"]) + cash),
        "net_of_listed_debt": money(Decimal(inventory["joint_taxable_JT_S"]) + cash - Decimal(inventory["debt_D_S"])),
        "total_allocated_goal_cash": money(total_allocated_goal_cash),
        "unallocated_cash_after_goal_allocations": money(unallocated_cash_after_goal_allocations),
        "cash_above_protected_floor_after_goal_allocations": money(cash_above_floor_after_goal_allocations),
        "sources": ["P5A2", "P5A4"],
    },
    "goals": goal_results,
    "combined_goal_findings": {
        "combined_inflated_goal_costs": money(sum(Decimal(str(r["inflated_cost_at_due_date"])) for r in goal_results)),
        "combined_total_supported_by_current_plan": money(sum(Decimal(str(r["total_supported_by_current_plan"])) for r in goal_results)),
        "combined_shortfall_at_due_dates": money(sum(Decimal(str(r["shortfall_at_due_date"])) for r in goal_results)),
        "combined_incremental_monthly_needed_for_full_funding_without_extra_cash": money(
            sum(Decimal(str(r["incremental_monthly_needed_above_proposed"])) for r in goal_results)
        ),
        "full_funding_monthly_saving_required_for_both_goals_before_home_deadline_without_extra_cash": money(full_funding_monthly_first_24),
        "monthly_baseline_surplus_gap_vs_full_funding_for_both_goals": money(full_funding_monthly_first_24 - monthly_baseline_surplus),
        "cash_above_floor_after_goal_allocations_if_used_for_goals": money(cash_above_floor_after_goal_allocations),
        "remaining_combined_shortfall_after_using_all_cash_above_floor": money(
            sum(Decimal(str(r["shortfall_at_due_date"])) for r in goal_results) - cash_above_floor_after_goal_allocations
        ),
        "sources": ["P5A2", "P5A3"],
    },
    "unknown_or_not_evidenced": [
        "Client-ranked priority order between G-T and G-H",
        "Mandate benchmark",
        "Governing risk constraint",
        "Professional capacity assessment",
        "Joint owner assent to mandate",
        "Signed planning artifact, historical hash, approval, effective mandate date",
        "Any flows, returns, interest changes, taxes, or contribution escalation beyond supplied records",
    ],
}

output_dir = Path("deliverables/working")
output_dir.mkdir(parents=True, exist_ok=True)
(output_dir / "HH-SEDGE_structured_inputs_2026-10-04.json").write_text(
    json.dumps(inputs, indent=2, default=str) + "\n"
)
(output_dir / "HH-SEDGE_calculation_output_2026-10-04.json").write_text(
    json.dumps(calculation_output, indent=2, default=str) + "\n"
)

print(json.dumps(calculation_output, indent=2, default=str))
