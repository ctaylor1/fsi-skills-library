# HH-SEDGE Household Cash-Flow and Competing-Goal Review

Authorized recipient set: Liora, Tamsin only.

Review date: 2026-10-04  
Draft status: Prepared for planner/advisor human review only. Not sent to clients. No orders, transactions, approvals, mandate adoption, or system changes are authorized by this draft.

## Source Scope

This draft uses only the supplied local records in `source_packet.json` and `resources/source-packet.json`. The permission resource identifies allowed recipients as Liora and Tamsin for sources P5A1-P5A5. [P5A1, P5A2, P5A3, P5A4, P5A5]

All people and records are synthetic. HH-SEDGE is a US advisory household in USD for clients S-A and S-B. PLAN-S v1 and IPS-S v2 are effective October 1 through December 31, 2026. [P5A1]

## Executive Findings

The documented household monthly cash-flow capacity before goal saving is $3,180: $11,500 take-home income less $7,600 regular spending and $720 debt service. [P5A2]

The proposed first-24-month goal savings total $2,700 per month: $1,600 for tuition G-T and $1,100 for home accessibility G-H. That leaves $480 per month of documented surplus during the first 24 months, before any unmodeled flows, taxes, interest changes, or spending changes. [P5A2, P5A3]

The current savings plan supports partial, not full, funding of both goals under the supplied assumptions. Tuition G-T is supported to $75,600 against an estimated inflated due-date cost of $118,014.52, leaving a $42,414.52 shortfall. Home accessibility G-H is supported to $38,400 against an estimated inflated due-date cost of $67,897.60, leaving a $29,497.60 shortfall. [P5A3]

The clients have not ranked the goals, and the legacy export numbers for G-T and G-H were only entry order, not client priority. This review therefore does not recommend a priority order. [P5A3, P5A5]

## Supplied Facts Used

| Area | Supplied fact | Source |
|---|---:|---|
| Joint taxable JT-S | $410,000 | P5A2 |
| Cash CASH-S | $70,000 | P5A2 |
| Debt D-S | $82,000 | P5A2 |
| Protected cash floor | $25,000 | P5A2 |
| Monthly take-home income | $11,500 | P5A2 |
| Regular monthly spending, excluding debt | $7,600 | P5A2 |
| Monthly debt service | $720 | P5A2 |
| Tuition G-T today-dollar cost | $108,000 due in 36 months | P5A3 |
| Tuition G-T allocated cash | $18,000 | P5A3 |
| Tuition G-T proposed end-month saving | $1,600/month | P5A3 |
| Home accessibility G-H today-dollar cost | $64,000 due in 24 months | P5A3 |
| Home accessibility G-H allocated cash | $12,000 | P5A3 |
| Home accessibility G-H proposed end-month saving | $1,100/month | P5A3 |
| Goal cost inflation | 3% annual cost inflation | P5A3 |
| Goal return assumption | Zero return, no contribution escalation, no transfers between goals | P5A3 |

## Calculation Method

Supplied assumption: both goals use 3% annual cost inflation, zero return, no contribution escalation, and end-month savings. [P5A3]

Calculation interpretation: due-date cost is calculated as `today-dollar cost * (1 + 3%) ^ (months / 12)`. Because the return assumption is zero, current allocated cash and future deposits are summed without investment growth.

The structured input file and calculation output are retained as working artifacts:

- `deliverables/working/HH-SEDGE_structured_inputs_2026-10-04.json`
- `deliverables/working/HH-SEDGE_calculation_output_2026-10-04.json`
- `deliverables/working/calculate_hh_sedge.py`

Each working artifact is labeled for authorized recipients Liora and Tamsin only.

## Household Capacity

| Measure | Amount | Source |
|---|---:|---|
| Investment and cash inventory, JT-S plus CASH-S | $480,000 | P5A2, P5A4 |
| Listed debt | $82,000 | P5A2 |
| Net of listed debt | $398,000 | P5A2 |
| Total allocated goal cash | $30,000 | P5A3 |
| Cash remaining after goal allocations | $40,000 | P5A2, P5A3 |
| Cash above protected floor after goal allocations | $15,000 | P5A2, P5A3 |

The reconciled inventory is complete for this model, with ownership represented once; goal allocations are portions of CASH-S, not extra assets. [P5A2]

| Monthly cash-flow item | Amount | Source |
|---|---:|---|
| Take-home income | $11,500 | P5A2 |
| Regular spending excluding debt | ($7,600) | P5A2 |
| Debt service | ($720) | P5A2 |
| Baseline surplus before goal saving | $3,180 | P5A2 |
| Proposed goal saving, months 1-24 | ($2,700) | P5A3 |
| Residual surplus, months 1-24 | $480 | P5A2, P5A3 |
| Proposed goal saving, months 25-36 if only tuition continues and no transfers are modeled | ($1,600) | P5A3 |
| Residual surplus, months 25-36 under that assumption | $1,580 | P5A2, P5A3 |

## Goal Funding Review

| Goal | Due | Inflated due-date cost | Allocated cash | Proposed new saving | Current plan supports | Shortfall | Funded ratio |
|---|---:|---:|---:|---:|---:|---:|---:|
| G-T Tuition | 36 months | $118,014.52 | $18,000 | $57,600 | $75,600 | $42,414.52 | 64.1% |
| G-H Home accessibility | 24 months | $67,897.60 | $12,000 | $26,400 | $38,400 | $29,497.60 | 56.6% |

The current monthly savings plan supports meaningful progress on both goals, but does not fully fund either goal by its stated due date. [P5A3]

To fully fund the goals without using additional cash or changing scope, monthly savings would need to be approximately:

| Goal | Required monthly saving | Current proposed monthly saving | Incremental monthly need |
|---|---:|---:|---:|
| G-T Tuition | $2,778.18 | $1,600 | $1,178.18 |
| G-H Home accessibility | $2,329.07 | $1,100 | $1,229.07 |
| Combined before the 24-month home deadline | $5,107.25 | $2,700 | $2,407.25 |

The combined full-funding monthly requirement of $5,107.25 exceeds the documented $3,180 monthly baseline surplus by $1,927.25 before any use of additional cash. [P5A2, P5A3]

If all $15,000 of cash above the protected floor after goal allocations were also assigned to the goals, the remaining combined due-date shortfall would still be $56,912.12. This is an illustration only; no client priority or cash redeployment decision is evidenced. [P5A2, P5A3]

## Competing-Goal Handoff Points

The two goals compete for the same documented surplus during the first 24 months. The supplied records say the plans run concurrently from the same surplus and that clients have not ranked them. [P5A3]

The planning-to-IPS handoff should avoid treating G-T as priority 1 and G-H as priority 2. The supplied correction says those legacy export numbers were entry order only. [P5A5]

The documented savings plan answers: “Can the current monthly surplus carry the proposed deposits?” Yes, with a modeled $480 monthly residual for months 1-24. [P5A2, P5A3]

The documented savings plan does not answer: “Which goal should absorb shortfall risk?” That needs a client priority discussion because both goals remain underfunded under the supplied assumptions. [P5A3, P5A5]

## Decisions Still Needed From Clients

These items are not decisions made in this draft:

1. Confirm whether tuition G-T, home accessibility G-H, or a balanced rule should receive priority if both cannot be fully funded. [P5A3, P5A5]
2. Decide whether to change monthly savings, change goal amounts, change dates, use some or all of the $15,000 cash above the protected floor, or accept projected shortfalls. [P5A2, P5A3]
3. Confirm whether the protected cash floor remains $25,000 after considering the goal strain and IPS scope. [P5A2, P5A4]
4. Decide whether any debt strategy is relevant; the supplied record includes debt and debt service but does not model interest changes or alternative debt treatment. [P5A2]
5. Confirm whether the IPS mandate should be limited to JT-S only while CASH-S remains outside. [P5A4]
6. Provide explicit priorities, account scope, and human approval before any mandate adoption. [P5A1]

## Unknowns and Tool-Limited Items

The following fields are not evidenced in the supplied records and are preserved as unknown:

- Client-ranked priority order between G-T and G-H. [P5A3, P5A5]
- Any flows, returns, tax effects, debt interest changes, contribution escalation, or transfers between goals beyond the supplied model. [P5A2, P5A3]
- Professional risk capacity assessment. [P5A4]
- Mandate benchmark and governing risk constraint. [P5A4]
- Joint owner assent to mandate. [P5A5]
- Signed planning artifact, historical hash, approval, or effective mandate date. [P5A1, P5A5]

## Source References

- P5A1: Synthetic record; custodian Tamsin; recorded 2026-10-04; current through 2026-10-31; allowed recipients Liora, Tamsin.
- P5A2: Synthetic record; custodian Liora; recorded 2026-10-03; current through 2026-10-31; allowed recipients Liora, Tamsin.
- P5A3: Synthetic record; custodian Liora recording both clients; recorded 2026-10-04; current through 2026-10-31; allowed recipients Liora, Tamsin.
- P5A4: Synthetic record; custodian Tamsin; recorded 2026-10-04; current through 2026-10-31; allowed recipients Liora, Tamsin.
- P5A5: Synthetic record; custodian export custodian Elian; recorded 2026-10-04; current through 2026-10-31; allowed recipients Liora, Tamsin.
