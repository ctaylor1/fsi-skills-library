Prepared the draft package for Nessa and Quinn only:

- [draft_internal_recommendation_evidence_memo_REC-COPPER-6.md](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-34pmte0w/work/draft_internal_recommendation_evidence_memo_REC-COPPER-6.md)
- [working_structured_inputs_REC-COPPER-6.json](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-34pmte0w/work/working_structured_inputs_REC-COPPER-6.json)
- [working_fee_calculations_REC-COPPER-6.json](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-34pmte0w/work/working_fee_calculations_REC-COPPER-6.json)

I used only the supplied local packets, kept the recorded US brokerage capacity, cited source IDs for material claims, preserved unknowns, and avoided selecting or approving the move. The fee calculation shows PLAN-C at `$840/year` versus the proposed managed account at `$2,160/year` ongoing, or `$2,310` in the first year with setup, using the packet’s constant `$240,000` illustration limits.

Validation: both JSON working files pass `jq empty`. No external access, contacts, orders, approvals, or system changes were made.