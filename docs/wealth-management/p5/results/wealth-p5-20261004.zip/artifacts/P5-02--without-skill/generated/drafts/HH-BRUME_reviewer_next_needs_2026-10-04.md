# HH-BRUME Reviewer Next Evidence Needs

Authorized recipient set: Ines, Dario, Celia only.  
Recipient restriction: Coordinated internal draft for advisor Ines, tax reviewer Dario and estate counsel Celia only; no other recipients authorized.  
Review date: 2026-10-04.  
Source packet used: `resources/source-packet.json`.

## Ines - Advisor

1. Confirm whether the SEC-B sale remains only proposed and that no order has been placed or executed. The supplied record says no sale executed. [P5B2]
2. Confirm the household objective for selling 100 units of SEC-B in B-A taxable TAX-B and whether any exposure-management objective should consider B-B's recent 25-unit SEC-B purchase in RET-B. [P5B2, P5B3]
3. Collect complete activity coverage after October 4 for accounts relevant to SEC-B exposure because current coverage after October 4 is incomplete. [P5B3]
4. Coordinate collection of missing estate records without interpreting blank fields as confirmed absence, especially BANK-B beneficiary pages and RET-B contingent beneficiary pages. [P5B4, P5B5]

## Dario - Tax Reviewer

1. Obtain household gains, losses, carryforwards and any approved tax rate. These are absent from the supplied records. [P5B2]
2. Accept, reject or replace the draft 27% tax-benefit assumption. It is currently unreviewed and not accepted by Dario. [P5B3]
3. Review whether B-B's September 29 purchase of 25 units of SEC-B in RET-B affects recognition of the proposed 2,340 pre-tax loss from B-A taxable TAX-B. The records state same-exposure group but provide no accepted loss-disallowance conclusion. [P5B2, P5B3]
4. Confirm RET-B IRA type and tax treatment because the statement header says IRA only and Traditional/Roth and tax-deferred/tax-free treatment are unspecified. [P5B3]
5. Confirm activity coverage after October 4 before approving any tax-benefit estimate or loss-disallowance conclusion. [P5B3]

## Celia - Estate Counsel

1. Confirm whether TR-BRUME remains unsigned or obtain the executed trust. The supplied record says the trust draft is unsigned. [P5B5]
2. Review the unresolved EST-B-19 title-intention mismatch: BANK-B current title is B-A individual while recorded intention is TR-BRUME ownership pending counsel, with no transfer recorded. [P5B4, P5B5]
3. Identify required evidence for any BANK-B transfer to trust ownership, if legally appropriate. The supplied records do not evidence a recorded transfer. [P5B4]
4. Obtain current BANK-B beneficiary documentation or custodian confirmation. The blank field is due to pages never requested or loaded, not confirmation of no beneficiary. [P5B4]
5. Obtain RET-B contingent beneficiary documentation or custodian confirmation. The primary page names B-A 100%, but the contingent page is absent and no representation of no contingent designation was obtained. [P5B5]
