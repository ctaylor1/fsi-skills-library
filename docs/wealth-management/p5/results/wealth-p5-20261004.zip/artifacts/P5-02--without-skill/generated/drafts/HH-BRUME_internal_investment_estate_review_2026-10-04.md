# HH-BRUME Tax-Aware Investment Review and Estate-Record Comparison

Authorized recipient set: Ines, Dario, Celia only.  
Recipient restriction: Coordinated internal draft for advisor Ines, tax reviewer Dario and estate counsel Celia only; no other recipients authorized.  
Review date: 2026-10-04.  
Source packet used: `resources/source-packet.json`.  
Status: Draft for human review. No contact, delivery outside the authorized set, order placement, transaction approval or system change has been made.

## Scope and Source Controls

HH-BRUME is a US advisory household in USD with clients B-A and B-B. TAX-B v3 and EST-B v1 are the supplied comparison policies effective October 1-December 31. Account tax treatment and current or intended designations require source evidence; record comparisons are not legal determinations. The named reviewers are assigned next-step roles and are not recorded as having completed tax or legal reviews. [P5B1]

The permission resource lists only Ines, Dario and Celia as recipients, and each cited source allows those same recipients. [P5B1, P5B2, P5B3, P5B4, P5B5]

## Investment Proposal and Supported Economics

Supplied transaction facts: B-A taxable TAX-B contains LOT-B, consisting of 100 units of SEC-B acquired May 15, 2024, with unit basis 75 and unit price 52 on October 3. The proposed full sale on October 4 would incur a 40 fee reducing proceeds under the supplied illustration. No sale has been executed. [P5B2]

| Item | Calculation | Supported amount |
|---|---:|---:|
| Gross proceeds | 100 units x 52 | 5,200 USD |
| Cost basis | 100 units x 75 | 7,500 USD |
| Sale fee | Supplied fee | 40 USD |
| Net proceeds after fee | 5,200 - 40 | 5,160 USD |
| Pre-tax realized gain/loss before tax review | 5,160 - 7,500 | -2,340 USD |

The elapsed calendar period from the supplied acquisition date to the proposed sale date is 872 days. This is arithmetic only; tax holding-period classification remains for tax review. [P5B2]

A draft planner note uses 27% as an unreviewed tax-benefit assumption. Applying that unreviewed rate to the supported 2,340 loss would produce an illustrative 631.80 potential benefit, but this is not an approved tax estimate because household gains, carryforwards and approved tax rate are absent and Dario has not accepted a rate. [P5B2, P5B3]

## Tax Review Flags

B-B bought 25 units of SEC-B on September 29 in RET-B, whose statement header says IRA only. Traditional/Roth status and tax-deferred/tax-free treatment are unspecified, and activity coverage after October 4 is incomplete. The SEC-B purchase and proposed sale are in the supplied same-exposure group. Dario has not accepted a loss-disallowance conclusion. [P5B3]

The 25-unit same-exposure purchase equals 25% of the 100 units proposed for sale, but the supported record does not establish whether or how any loss disallowance applies. That conclusion should remain unknown until Dario reviews the IRA type, account tax treatment, activity coverage and applicable household facts. [P5B3]

## Estate-Record Comparison

BANK-B current title is B-A individual. The recorded client intention is TR-BRUME ownership pending counsel, and no transfer is recorded. The supplied estate-origin issue EST-B-19 remains unresolved with code `title-intention-mismatch`: BANK-B individual title differs from recorded trust-ownership intention. [P5B4, P5B5]

BANK-B beneficiary status is not confirmed. The blank bank beneficiary field reflects pages never requested or loaded, not custodian confirmation of absence. The legacy export rendered blank as none-recorded, and BANK-B beneficiary intention was not collected. [P5B4]

RET-B primary beneficiary page names B-A 100%. The contingent page is absent, and no representation of no contingent designation was obtained, so contingent beneficiary status is unknown. [P5B5]

TR-BRUME is an unsigned trust draft. An email with subject "Approval complete" confirms only successful upload by an intake assistant; it does not evidence counsel approval, trust execution, title transfer or beneficiary approval. [P5B5]

## Reviewer Next Evidence Needs

Ines should confirm the current advisory proposal and household objective for any contemplated SEC-B sale, verify that no sale has executed, gather any missing activity coverage after October 4 for relevant accounts, and coordinate collection of missing estate and beneficiary pages without treating blanks as confirmations. [P5B2, P5B3, P5B4, P5B5]

Dario should request household gains, losses, carryforwards and any approved tax rate; determine whether the 27% planner assumption is rejected or accepted for a specific reviewed purpose; review whether the September 29 RET-B purchase affects the proposed loss; confirm RET-B IRA type and tax treatment; and review post-October 4 activity coverage before any tax-benefit or loss-disallowance conclusion. [P5B2, P5B3]

Celia should request the executed trust or confirm that TR-BRUME remains unsigned, determine what documents would be required for BANK-B trust ownership if appropriate, review the unresolved EST-B-19 title-intention mismatch, obtain or direct collection of current BANK-B beneficiary evidence, and review RET-B primary and contingent beneficiary records for estate-plan alignment. [P5B4, P5B5]

## Unknowns Preserved

Approved tax rate, household gains, household carryforwards, loss-disallowance conclusion, RET-B Traditional/Roth status, RET-B tax-deferred/tax-free treatment, post-October 4 activity coverage, BANK-B beneficiary status, BANK-B beneficiary intention, RET-B contingent beneficiary status, TR-BRUME execution status beyond "draft unsigned," and legal effect of the title-intention mismatch are all unknown or not concluded from the supplied records. [P5B1, P5B2, P5B3, P5B4, P5B5]
