# Trust-Administration Review - TR-MARROW

Exact recipient set: Xavi and counsel Inez only.

Review date: 2026-10-04.

Use limits: Draft review for human and counsel evaluation. This draft does not approve a transaction, place an order, send a notice, or change any system.

## Scope

TR-MARROW is a separate US trust-capacity review for the USD period October 1 through October 4. BEN-MC maps to actual HH-M2 through the reviewed source link. [P5F4]

## Authority And Document Status

DOC-M2019 and amendment DOC-M2025 are supplied, but amendment signature and precedence are incomplete. CO-M1 appointment is documented; CO-M2 is unconfirmed. AUTH-M joint action and EDU-M education clause need professional interpretation. [P5F4]

LEGAL-M-61 remains unresolved: amendment signature and co-fiduciary authority need counsel review. The admin export states resolved, but the supplied record gives no resolution source or counsel approval, so treat the issue as unresolved for review purposes. [P5F4]

For D-M, authority depends on the document and authority issues above. TA-Mv 1, effective October 1 through December 31, requires authority, purpose/invoice, and human review before approval. [P5F6]

## Ledger Review

| Item | Principal | Income | Total cash | Citation |
| --- | ---: | ---: | ---: | --- |
| Opening before movements, Oct 1 | 40000 | 12000 | 52000 | [P5F5] |
| Settled income receipt, Oct 1 | 0 | 3600 | 3600 | [P5F5] |
| Income expense, Oct 2 | 0 | -1600 | -1600 | [P5F5] |
| Distribution D-M, Oct 3 | -4500 | 0 | -4500 | [P5F5] |
| Reclass income to principal, Oct 4 | 1500 | -1500 | 0 | [P5F5] |
| Calculated close, Oct 4 | 37000 | 12500 | 49500 | [P5F5] |

The calculated close matches the reported October 4 close of 49500 total cash, consisting of 37000 principal and 12500 income. [P5F5]

The cash asset reference of 49500 links to CASH-M. Noncash assets are 135000 dated October 3 and exclude cash, so cash plus noncash inventory is 184500. The supplied record states complete inventory, reserve 12500, and no other trust cash. [P5F5]

The TR-REMOTE appendix cash amount of 77000 is unassociated and is not included in TR-MARROW cash or inventory calculations. [P5F5]

## Distribution D-M Review

D-M was requested September 21 for BEN-MC education in the amount of 15000, needed October 15. Prior paid before October 1 is 2500. The current settled payment is 4500 in P5F5. The pending 3000 dated October 10 is the same request, not additional, and is not settled. [P5F5] [P5F6]

Settled paid to date is 7000. Remaining against the 15000 request after settled payments only is 8000. If the pending 3000 later settles as part of the same request, the remaining amount would be 5000. [P5F5] [P5F6]

Invoice is absent. Purpose letter is present. Beneficiary and conflict records are reported current. Authority remains dependent on counsel review of P5F4 issues. [P5F4] [P5F6]

OB-M under REPORT-M was due October 2, owner CO-M1, and remains open with no completion supplied. No universal cadence is supplied. [P5F6]

## Review Conclusions For Human/Counsel Review

Do not treat D-M as approval-ready on the supplied record alone. The evidenced gaps are authority/counsel interpretation, invoice or purpose/invoice sufficiency under TA-Mv 1, and required human review before approval. [P5F4] [P5F6]

Treat the admin export's "resolved" status as unsupported until a resolution source or counsel approval is supplied. [P5F4]

Use 49500 as the supported October 4 cash close for TR-MARROW and 184500 as cash plus noncash inventory, excluding the unassociated TR-REMOTE appendix cash. [P5F5]

## Minimum Necessary Handoffs

For Inez: review amendment signature/precedence, co-fiduciary authority, AUTH-M joint action, EDU-M education clause, and whether D-M satisfies authority and purpose/invoice requirements. [P5F4] [P5F6]

For Xavi: reconcile ledger to the 49500 cash close, maintain D-M as not additionally counted for the pending 3000, track the missing invoice/purpose support issue, and keep OB-M open unless completion evidence is supplied. [P5F5] [P5F6]

No handoff is made to Faro, Vale, M-A, M-B, or M-C from this review.

## Source References

P5F4: Synthetic record; custodian Xavi; recorded 2026-10-04; current through 2026-10-31; allowed recipients Xavi and Inez.

P5F5: Synthetic record; custodian accountant Petra via Xavi; recorded 2026-10-04; current through 2026-10-31; allowed recipients Xavi and Inez.

P5F6: Synthetic record; custodian Xavi register; recorded 2026-10-04; current through 2026-10-31; allowed recipients Xavi and Inez.
