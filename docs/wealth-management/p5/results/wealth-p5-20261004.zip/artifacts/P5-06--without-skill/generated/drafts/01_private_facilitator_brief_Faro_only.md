# Private Facilitator Brief - FAMILY-MARROW

Exact recipient set: Faro only.

Review date: 2026-10-04.

Use limits: Private facilitator preparation only. Do not distribute this brief, attach it to meeting materials, or use it to imply private source contents to Vale, M-A, M-B, M-C, Xavi, or Inez.

## Scope

This brief covers FAMILY-MARROW discussion readiness, succession-readiness topics, meeting time, and Faro-only preparation notes evidenced for Faro. It does not address trust-administration review.

## Supplied Facts For Facilitation

FAMILY-MARROW is a US advisory family group. M-A and M-B are in HH-M1; M-C is in HH-M2; Faro and Vale are professional nonmembers. All three eligible family members are willing to meet on October 12. The supplied FG-Mv 1 rule for October 1 through December 31 uses a majority of all three eligible members and quorum of 2, with a 60 minute meeting budget. Vale may coordinate public meeting content only. [P5F1]

The public discussion record allocates 18 minutes to ED-M workshop discussion, 22 minutes to TR-QM trustee-replacement discussion, and 16 minutes to a separate workshop exercise. Those supplied topic times total 56 minutes, leaving 4 minutes inside the 60 minute budget for opening, transitions, and close. [P5F2]

On ED-M, M-A and M-B support the workshop discussion; M-C opposes and wants individual learning. On TR-QM, all three support discussion, not appointment. The separate workshop exercise remains unresolved against M-C's preference. [P5F2]

ROLE-LEARN is an education convenor role without trustee or legal power. M-A is the current holder. M-B's candidate interest was confirmed October 2, with a target date of January 31, 2027. Faro documented orientation on October 1; facilitation experience is unknown. [P5F2]

FU-M is a counsel question accepted by Faro, due October 8, and not completed as of the supplied record. Do not represent it as answered. [P5F2]

## Faro-Only Private Preparation Note

M-A has a private 12 minute preparation topic concerning a possible personal guarantee. Amount, effect, and scope are unknown, and the issue is unresolved. The supplied record states this is private planning only, not trust accounting and not a jointly agreed agenda item. [P5F3]

Do not put the private guarantee topic on the family agenda, do not reference its source ID or issue code outside this Faro-only file, and do not let it drive a public implication. If M-A raises it in the meeting, treat that as a new participant-raised item and pause for an authorized handling path before discussion continues. [P5F3]

## Draft Meeting Shape

1. Opening and quorum check: 2 minutes. Confirm October 12 attendance and advisory nature of the session. [P5F1]
2. ED-M learning format discussion: 18 minutes. Surface M-A/M-B workshop support and M-C's individual-learning preference without forcing a group-format conclusion. [P5F2]
3. TR-QM trustee-replacement discussion: 22 minutes. Keep the frame to discussion only, not appointment. [P5F2]
4. Workshop or individual-learning next-step exercise: 16 minutes. Use this as a format-choice exercise unless the family resolves the group-format objection first. [P5F2]
5. Close: 2 minutes. Capture only agreed public next steps and unresolved questions, including FU-M as not completed if it remains open. [P5F2]

## Minimum Necessary Handoffs

To Vale: meeting logistics and public content only - October 12 willingness, 60 minute budget, quorum 2, majority of all three eligible members, public topic timing, and the instruction not to attach the full source packet to family materials. [P5F1] [P5F2] [P5F7]

To M-A/M-B/M-C after Faro review: a family discussion draft limited to public FAMILY-MARROW facts and questions. [P5F1] [P5F2]

No trust-administration handoff is made from this facilitator brief.

## Source References

P5F1: Synthetic record; custodian Faro; recorded 2026-10-04; current through 2026-10-31; allowed recipients Faro, Vale, M-A, M-B, M-C, Xavi, Inez.

P5F2: Synthetic record; custodian Faro register; recorded 2026-10-02; current through 2026-10-31; allowed recipients Faro, Vale, M-A, M-B, M-C, Xavi, Inez.

P5F3: Synthetic record; custodian M-A private note custodian Faro; recorded 2026-10-04; current through 2026-10-31; allowed recipient Faro only; no wider output recipient authorized.

P5F7: Synthetic record; custodian Vale routing correction; recorded 2026-10-04; current through 2026-10-31; allowed recipients Faro, Vale, M-A, M-B, M-C, Xavi, Inez.
