# Meeting-Operations Brief - FAMILY-MARROW

Exact recipient set: Faro and Vale only.

Review date: 2026-10-04.

Use limits: Operations and public meeting-content coordination only. Do not attach the full source packet to the family invite. Do not add records based on family relationship or internal role alone. [P5F7]

## Meeting Frame

FAMILY-MARROW is a US advisory family group. M-A/M-B are in HH-M1; M-C is in HH-M2; Faro and Vale are professional nonmembers. All three family members are willing to meet October 12. [P5F1]

The supplied FG-Mv 1 rule effective October 1 through December 31 requires quorum 2 and a majority of all three eligible members. The meeting budget is 60 minutes. [P5F1]

Vale may coordinate public meeting content only. The routing correction says the old operations cover label and full-packet attachment suggestion were only a routing default without source-specific permission review, and no invite or attachment has been sent. [P5F1] [P5F7]

## Proposed 60 Minute Run Of Show

| Segment | Time | Operations note |
| --- | ---: | --- |
| Opening, attendance, advisory frame | 2 min | Confirm quorum and note that the session is discussion/readiness only. [P5F1] |
| ED-M workshop discussion | 18 min | M-A/M-B support; M-C opposes and wants individual learning. [P5F2] |
| TR-QM trustee-replacement discussion | 22 min | All three support discussion, not appointment. [P5F2] |
| Learning-format exercise | 16 min | Group format is unresolved against M-C's preference; keep output as options or next steps unless resolved. [P5F2] |
| Close and public next steps | 2 min | Capture agreed public next steps and open questions only. [P5F2] |

Supplied topic times total 56 minutes; the remaining 4 minutes are reserved above for opening and close. [P5F2]

## Succession-Readiness Operations Points

ROLE-LEARN is an education convenor role without trustee or legal power. M-A is holder; M-B's candidate interest was confirmed October 2; the target is January 31, 2027. Orientation was documented by Faro on October 1, and facilitation experience is unknown. [P5F2]

FU-M is a counsel question accepted by Faro, due October 8, and not completed in the supplied record. Do not state or imply a counsel conclusion. [P5F2]

## Unknowns And Constraints

Final attendance is not evidenced beyond willingness to meet October 12. [P5F1]

Facilitation experience for the ROLE-LEARN succession-readiness item is unknown. [P5F2]

No invite or attachment has been sent. [P5F7]

## Minimum Necessary Handoffs

Vale may coordinate the public meeting details in this brief: date willingness, 60 minute budget, quorum and majority rule, public run of show, and invite/attachment correction. [P5F1] [P5F2] [P5F7]

Faro should review any family-facing draft before use. The family-facing draft should contain only public FAMILY-MARROW discussion facts and should not include full-packet attachments. [P5F1] [P5F2] [P5F7]

## Source References

P5F1: Synthetic record; custodian Faro; recorded 2026-10-04; current through 2026-10-31; allowed recipients Faro, Vale, M-A, M-B, M-C, Xavi, Inez.

P5F2: Synthetic record; custodian Faro register; recorded 2026-10-02; current through 2026-10-31; allowed recipients Faro, Vale, M-A, M-B, M-C, Xavi, Inez.

P5F7: Synthetic record; custodian Vale routing correction; recorded 2026-10-04; current through 2026-10-31; allowed recipients Faro, Vale, M-A, M-B, M-C, Xavi, Inez.
