# Family Discussion Draft - FAMILY-MARROW

Exact recipient set for review/use: Faro, M-A, M-B, and M-C.

Review date: 2026-10-04.

Use limits: Draft for Faro review before family use. This draft is for FAMILY-MARROW discussion and succession-readiness conversation only.

## Proposed Purpose

Use the October 12 meeting to discuss education-readiness and succession-readiness next steps for FAMILY-MARROW. The meeting is advisory, budgeted for 60 minutes, and uses the supplied rule of quorum 2 with a majority of all three eligible members. [P5F1]

## Draft Agenda

| Segment | Time | Draft discussion prompt |
| --- | ---: | --- |
| Opening and meeting frame | 2 min | Confirm attendance, advisory purpose, and that the goal is discussion/readiness. [P5F1] |
| ED-M learning format | 18 min | M-A and M-B support a workshop discussion; M-C wants individual learning. What next learning format can everyone work with? [P5F2] |
| TR-QM trustee-replacement topic | 22 min | All three support discussion, not appointment. What information or counsel input is needed before any later decision point? [P5F2] |
| ROLE-LEARN readiness exercise | 16 min | ROLE-LEARN is an education convenor role without trustee or legal power. M-A is current holder; M-B has confirmed candidate interest; target timing is January 31, 2027. What readiness steps are needed? [P5F2] |
| Close | 2 min | Record agreed next steps and unresolved questions. [P5F2] |

## Known Readiness Facts

Faro documented orientation on October 1. Facilitation experience is unknown in the supplied record. [P5F2]

FU-M is a counsel question accepted by Faro, due October 8, and not completed in the supplied record. Treat it as open unless Faro confirms an authorized update before use. [P5F2]

## Draft Discussion Guardrails

Keep the TR-QM topic to discussion only; the supplied record does not evidence an appointment decision. [P5F2]

Do not treat the group workshop format as settled; M-C's individual-learning preference remains unresolved in the supplied record. [P5F2]

Do not add packet attachments or other records to this draft unless Faro confirms that each record is authorized for the exact recipient set. [P5F1] [P5F2]

## Minimum Necessary Handoff

The family-facing handoff from this discussion should be limited to agreed public next steps, unresolved public questions, and any authorized update Faro confirms before use. [P5F1] [P5F2]

## Source References

P5F1: Synthetic record; custodian Faro; recorded 2026-10-04; current through 2026-10-31; allowed recipients Faro, Vale, M-A, M-B, M-C, Xavi, Inez.

P5F2: Synthetic record; custodian Faro register; recorded 2026-10-02; current through 2026-10-31; allowed recipients Faro, Vale, M-A, M-B, M-C, Xavi, Inez.
