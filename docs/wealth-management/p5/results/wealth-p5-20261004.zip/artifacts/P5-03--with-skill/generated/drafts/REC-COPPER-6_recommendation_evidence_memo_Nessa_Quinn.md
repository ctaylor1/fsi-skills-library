# Internal Recommendation-Evidence Memo

Exact recipient set: Nessa and Quinn only.

Recommendation: REC-COPPER-6. Household: HH-COPPER. Review as of: 2026-10-04. Synthetic records only.

Purpose: evidence summary for human review. This draft does not select, recommend, approve, deliver, place, adopt or execute the proposed move.

## Capacity And Applicability

The recorded capacity for this recommendation is US brokerage capacity. The record also identifies a retirement context and a proposed destination of a managed account. APP-C v5 was supplied as effective October 1 through December 31 and was reviewed by Quinn on October 2 for applicability routing only. The disclosure deadline in the packet is October 8. The same record states there is no attestation that Quinn reviewed client costs, alternatives, risks, conflicts or the recommendation itself. [P5C1]

The native recommendation-evidence calculator requires a concrete action value such as `rollover` or `account_transfer`. The supplied packet does not explicitly record that action value, so the action remains unknown in the working extraction rather than inferred. [P5C1]

## Quoted Fee Comparison

Using the supplied constant 240000 balance illustration:

| Item | Supplied quote | Local calculation |
| --- | ---: | ---: |
| PLAN-C ongoing fee | 35 bps | 840 per year |
| Proposed managed account ongoing fee | 90 bps | 2160 per year |
| Ongoing difference | 55 bps | 1320 more per year |
| Proposed setup fee | 150 | 150 one time |
| First-year proposed total including setup | 90 bps + 150 | 2310 |
| First-year difference including setup | 55 bps + 150 | 1470 more |

Limitations: this is only the constant-balance illustration supplied in the packet. It excludes unprovided fund costs, taxes, spreads and opportunity cost. [P5C2]

## Evidence Readiness

The file is not ready for approval or adoption on the supplied record. Evidence-specific reviewer/date values are not supplied, and an October 4 correction withdrew copied Quinn/October 2 reviewer/date values from every evidence row. Nessa is assigned costs/alternatives review by October 7 and Quinn supervision by October 8, but neither event has occurred in this packet. [P5C2] [P5C4]

DISC-C version 4 was uploaded to the portal on October 3, but delivery/receipt is blank. The client's assumption that Quinn already cleared the move is not approval evidence. No approval, adoption or account move is recorded. [P5C5]

## Client Alignment And Conflict Gaps

C-A wants growth and needs 60000 for home accessibility by January 15, 2027. The assessed loss-capacity amount is absent. The source-note code `liquidity-versus-growth` says the near-term withdrawal and growth appetite need a governing-constraint review, and it remains unresolved. [P5C3]

The recorded alternatives for review are remaining in PLAN-C or using the proposed managed account; no final comparison conclusion is recorded. [P5C3]

Proposed fees accrue to an affiliated advisory business. Mitigation review and client understanding remain pending. [P5C5]

## Next Questions

1. What exact action value should the firm record for REC-COPPER-6 before native evidence-review tooling is used?
2. Has Nessa completed the assigned costs/alternatives review, including whether PLAN-C, the proposed managed account and any other reasonably available alternatives have been compared under the recorded brokerage capacity?
3. How should the 60000 near-term liquidity need, missing loss-capacity amount and `liquidity-versus-growth` constraint govern or limit the analysis?
4. Was DISC-C version 4 delivered and received before the October 8 deadline?
5. What conflict mitigation and client-understanding evidence supports the affiliated advisory fee?
6. Has Quinn completed the supervision review, separate from the October 2 applicability-routing review?

## Working Files Retained

Exact recipient set for each listed working artifact: Nessa and Quinn only.

- `working/structured-evidence-extraction-REC-COPPER-6.json`
- `working/fee-calculation-REC-COPPER-6.json`
- `working/native-tool-limitation-REC-COPPER-6.md`
- `working/evidence-inventory-REC-COPPER-6-Nessa-Quinn.json`
- `working/audience-request-REC-COPPER-6-Nessa-Quinn.json`
- `working/audience-plan-REC-COPPER-6-Nessa-Quinn.json`
- `working/audience-receipt-REC-COPPER-6-Nessa-Quinn.json`
- `drafts/REC-COPPER-6_internal_memo_Nessa_Quinn.md`

## Source Registry Used

- P5C1: Synthetic record; custodian Quinn; recorded 2026-10-02; current for this exercise through 2026-10-31. Allowed recipients: Nessa, Quinn.
- P5C2: Synthetic record; custodian statement collector Oren; recorded 2026-10-03; current for this exercise through 2026-10-31. Allowed recipients: Nessa, Quinn.
- P5C3: Synthetic record; custodian Nessa client notes; recorded 2026-10-04; current for this exercise through 2026-10-31. Allowed recipients: Nessa, Quinn.
- P5C4: Synthetic record; custodian Oren correction ticket; recorded 2026-10-04; current for this exercise through 2026-10-31. Allowed recipients: Nessa, Quinn.
- P5C5: Synthetic record; custodian Oren; recorded 2026-10-03; current for this exercise through 2026-10-31. Allowed recipients: Nessa, Quinn.
