# Native Evidence-Reviewer Tool Limitation

Authorized recipient set: Nessa and Quinn only.

Review as of: 2026-10-04.

The local investment-recommendation-evidence-reviewer schema requires a concrete `recommendation.action` value, such as `rollover` or `account_transfer`, before it can produce its native 11-check calculation artifact.

The supplied records identify REC-COPPER-6, HH-COPPER, US brokerage capacity, retirement context and a proposed managed-account destination, but they do not explicitly record the action value. I did not infer one. The memo therefore uses a structured extraction and fee calculation instead of a native schema output for the recommendation-evidence calculator.

Primary cited support: P5C1 for capacity/context/destination; P5C2 for fee quote; P5C3 through P5C5 for unresolved evidence items.
