# HH-DUNE Protection-Screening Review Draft

Authorized recipient set: Suri and Emmett only.

Draft status: Prepared for human review; not sent.  
As-of date: 2026-10-04.  
Source basis: Supplied synthetic records only, using `./resources/source-packet.json` as the permission resource and cited packet.  
Non-actions: No diagnosis, no account restriction or hold, no contact, no order, no transaction approval, and no system change.

## Matter

HH-DUNE is a US brokerage household/account context involving D-A, age 74, account AC-DUNE. The focal item is WD-D, a USD 12,400 withdrawal to PAY-D entered on 2026-10-04 and still proposed-not-executed. The USD 36,000 cash figure is only a reported balance and is not authorization. [P5D1]

## Recipient And Access Check

The permission resource lists packet recipients Suri and Emmett, and each consulted source record is marked as allowed for Suri and Emmett. [P5D1, P5D2, P5D3, P5D4, P5D5]

This draft and the working artifacts are therefore labeled for Suri and Emmett only. No other recipient is authorized by the supplied packet.

## Screening Arithmetic

Screening rule applied: SCR-D v2 requires executed September 4-October 3 history, minimum 3, population SD, and mean + 3 SD comparison, excluding proposed, canceled, and focal rows. It also gives a proposed new-payee threshold of USD 7,000 and an executed recent-outflow threshold of USD 15,000 for September 28-October 4 inclusive. [P5D4]

Baseline executed debit inputs: USD 900 on September 4, USD 1,100 on September 14, and USD 1,300 on September 24, all to PAY-R. The supplied baseline is complete, with no other executed debit in the September 4-October 3 baseline window. [P5D2]

Arithmetic:

| Item | Result |
| --- | ---: |
| Baseline count | 3 |
| Mean | USD 1,100.00 |
| Population SD | USD 163.30 |
| Mean + 3 SD | USD 1,589.90 |
| Proposed WD-D amount | USD 12,400.00 |
| Difference over mean + 3 SD | USD 10,810.10 |

Comparison results:

| Screen | Result | Basis |
| --- | --- | --- |
| Mean + 3 SD amount screen | Exceeds | USD 12,400 > USD 1,589.90. [P5D1, P5D2, P5D4] |
| Proposed new-payee amount screen | Exceeds if applicable | USD 12,400 > USD 7,000. Applicability depends on whether PAY-D is treated as a new payee under SCR-D v2; the supplied records show PAY-D differs from the baseline executed payee PAY-R, but do not evidence complete payee history outside the supplied windows. [P5D1, P5D2, P5D4] |
| Recent executed-outflow screen | Does not exceed | No other executed debit appears in the September 28-October 4 recent window; recent executed outflow is USD 0, below USD 15,000. The October 2 USD 4,200 PAY-Z request was canceled before execution, and WD-D remains proposed-not-executed, so both are excluded. [P5D2, P5D4] |

Note: The export `amount_out` column includes every lifecycle, so proposed and canceled rows should not be summed into executed-outflow arithmetic. [P5D2, P5D4]

## Observation Summary And Limits

Bela, as intake observer/observation recorder, recorded that an October 4 caller in the room supplied PAY-D instructions and said, "Do it today and do not mention this to anyone." Bela recorded influence=true, urgency=true, and secrecy=true. [P5D3]

Under SCR-D v2, influence, urgency, or secrecy requires human review. The profile states this is not an incapacity, exploitation, or hold determination. [P5D4]

Observation limits:

- Confusion, recall difficulty, and repetition were not assessed; blank scanned boxes are blank, not checked-no. [P5D3]
- Comprehension and freedom from coercion are not established by the supplied packet. [P5D3]
- Trusted-contact field is blank because staff did not ask; no decline is recorded. Trusted contact is administrative under the profile. [P5D1, P5D4]
- No capacity assessment or legal applicability review occurred in this packet. [P5D5]
- The packet does not evidence an incident reviewer or incident-review date. [P5D5]

## Recorder Versus Reviewer

Observation recorder: Bela recorded the October 4 observations and the unresolved observation-incomplete issue. [P5D3, P5D5]

Incident reviewer: Unknown/absent in the supplied packet. The earlier export values `incident_reviewed_by=Suri`, `incident_reviewed_on=October 1`, and `capacity_screen=no-concern` were withdrawn as inherited defaults. Suri signed profile routing on October 1, but that was not this incident review. [P5D4, P5D5]

Assigned clarification: Emmett is assigned to OBS-D-27, code `observations-incomplete`; completion date is unknown. [P5D5]

## Draft Reviewer Questions

1. Should PAY-D be treated as a new payee under SCR-D v2 for this proposed item, given that the supplied baseline only shows PAY-R executed debits and no complete all-time payee history?
2. Who will be recorded as the incident reviewer, and on what date, if a human incident review is performed?
3. What clarification is needed to resolve OBS-D-27 without treating unassessed fields as negative findings?
4. Can the record be completed to distinguish D-A's own instructions, if any, from the caller's supplied PAY-D instructions?
5. Is there any supplied or later-authorized record showing comprehension or freedom from coercion, or should both remain unknown?
6. Is any legal applicability review required before operational action, given that none occurred in this packet?
7. Should the trusted-contact field remain documented as blank-not-asked rather than declined?
8. Are there any additional authorized records after 2026-10-04 that change WD-D lifecycle status? If not supplied, status remains proposed-not-executed for this draft.

## Draft Conclusion For Human Review

WD-D triggers a human-review draft because the proposed USD 12,400 amount exceeds the mean + 3 SD screen and, if PAY-D is treated as new under the profile, exceeds the USD 7,000 proposed new-payee screen. Separately, Bela recorded influence, urgency, and secrecy indicators, which SCR-D v2 routes to human review. [P5D1, P5D2, P5D3, P5D4]

This draft does not diagnose D-A, does not determine incapacity or exploitation, does not recommend or impose an account restriction, and does not approve or reject WD-D. The supplied packet leaves incident reviewer/date, capacity assessment, legal applicability review, comprehension, freedom from coercion, and OBS-D-27 completion unknown or absent. [P5D3, P5D4, P5D5]

## Source Register

- P5D1: Synthetic record; custodian Emmett; recorded 2026-10-04; current through 2026-10-31; allowed recipients Suri, Emmett.
- P5D2: Synthetic record; custodian ledger custodian Bela; recorded 2026-10-04; current through 2026-10-31; allowed recipients Suri, Emmett.
- P5D3: Synthetic record; custodian intake observer Bela; recorded 2026-10-04; current through 2026-10-31; allowed recipients Suri, Emmett.
- P5D4: Synthetic record; custodian Suri; recorded 2026-10-01; current through 2026-10-31; allowed recipients Suri, Emmett.
- P5D5: Synthetic record; custodian Bela correction addendum; recorded 2026-10-04; current through 2026-10-31; allowed recipients Suri, Emmett.
