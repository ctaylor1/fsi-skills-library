# Draft for review

Recipients: Celia, Dario, Ines

Human review required. Not delivered.

## Scope and recipient control

Authorized recipient set: Ines, Dario and Celia only\. This is a coordinated internal draft for HH\-BRUME as of 2026\-10\-04 in a US advisory capacity\. TAX\-B v3 and EST\-B v1 are supplied comparison policies for October 1 through December 31\. Record comparisons are not legal determinations, named reviewers are next\-step owners rather than completed tax/legal reviewers, human review is required, no draft has been delivered, and no transaction, transfer, beneficiary update or system change has been approved or taken\.

Sources: P5B1

## Supported sale economics

Supplied fact: B\-A taxable TAX\-B holds LOT\-B, 100 units of SEC\-B acquired 2024\-05\-15 with unit basis 75 and unit price 52 on 2026\-10\-03; a proposed full sale on 2026\-10\-04 includes a 40 fee and no sale has been executed\. Supported arithmetic: gross proceeds 5,200\.00, net proceeds 5,160\.00, basis sold 7,500\.00, gain/loss before wash review \-2,340\.00, positive taxable gain 0\.00, and taxable loss before wash review \-2,340\.00\. No supported tax benefit is calculated because household gains, carryforwards and approved tax rate are absent\.

Sources: P5B1, P5B2

## Replacement\-purchase review

Supplied fact: B\-B bought 25 units of SEC\-B on 2026\-09\-29 in RET\-B, and the purchase and proposed sale are in the supplied same\-exposure group\. For a proposed 2026\-10\-04 loss sale, the inclusive 30\-day screen runs 2026\-09\-04 through 2026\-11\-03, so the 25\-unit RET\-B purchase falls inside the screen and is a potential replacement exposure for human tax review\. Deductible loss, wash\-sale disallowance, basis adjustment and IRA treatment remain not determined because Traditional/Roth and tax\-deferred/tax\-free treatment are unspecified, activity coverage after 2026\-10\-04 is incomplete, and Dario has not accepted a rate or loss\-disallowance conclusion\. The 27% planner note is only an unreviewed sensitivity; 27% x 2,340\.00 would be 631\.80 if a loss were allowed, but that is not a supported benefit\.

Sources: P5B1, P5B2, P5B3

## Estate comparison \- BANK\-B

BANK\-B current title is B\-A individual\. The recorded client intention is TR\-BRUME ownership pending counsel, with no transfer recorded\. The blank bank beneficiary field is not custodian confirmation of no beneficiary because the relevant pages were never requested or loaded; BANK\-B beneficiary intention was not collected\. The validated estate artifact therefore remains needs\-data and carries two BANK\-B literal differences: intended owners differ from recorded owners, and intended document links differ from recorded asset document links\. Origin EST\-B\-19, code title\-intention\-mismatch, remains unresolved\.

Sources: P5B1, P5B4, P5B5

## Estate comparison \- RET\-B

RET\-B has a statement header of IRA only\. The current supplied primary page names B\-A 100%; the contingent page is absent and no representation of no contingent designation was obtained\. RET\-B beneficiary intention was not collected, so the draft preserves the missing contingent evidence and unknown intended beneficiary/document links for counsel and custodian review\.

Sources: P5B1, P5B3, P5B5

## Trust\-document status

TR\-BRUME is only evidenced as an unsigned trust draft\. The estate comparison does not determine legal effect, validity, document precedence, beneficiary eligibility or authority to retitle an asset\.

Sources: P5B1, P5B4, P5B5

## Next evidence needs \- Ines

Please confirm current TAX\-B activity/history coverage, forward orders, and whether any additional household SEC\-B or same\-exposure activity exists for the 2026\-09\-04 through 2026\-11\-03 window\. Please also obtain or route BANK\-B beneficiary pages/status from the custodian rather than treating legacy blanks as confirmed absence, and confirm whether any client\-approved BANK\-B or RET\-B intentions were collected outside the supplied packet\.

Sources: P5B1, P5B2, P5B3, P5B4, P5B5

## Next evidence needs \- Dario

Please review whether SEC\-B and the RET\-B same\-exposure activity are substantially identical for wash\-sale purposes and whether IRA rules affect the proposed loss\. Please supply any approved federal, state, NIIT, carryforward, gain\-budget and household loss data if a reserve or benefit illustration is needed, and either confirm the 27% planner note remains unaccepted or replace it with an approved tax\-review assumption\.

Sources: P5B1, P5B2, P5B3

## Next evidence needs \- Celia

Please confirm the status, execution and legal relevance of the TR\-BRUME trust draft before any title comparison is used operationally\. Please resolve EST\-B\-19 and advise whether the BANK\-B title/intention mismatch should be remediated, documented as pending or rejected\. Please also review RET\-B primary/contingent beneficiary evidence and whether any trust\-related beneficiary or ownership intention exists\.

Sources: P5B1, P5B3, P5B4, P5B5

## Working files retained

Restricted working files retained for the exact recipient set are: tax\_supported\_economics\.authorized\.json, combined\_internal\_claims\.authorized\.json, estate\_candidate\_input\.authorized\.json, estate\_native\_output\.authorized\.json, and the pending field inventories\. The native estate output validated with zero validator errors; the source/field and final draft reviews remain pending because no independent reviewer record was supplied\.

Sources: P5B1, P5B2, P5B3, P5B4, P5B5

## Sources used

- P5B1: Synthetic record; custodian Ines; recorded 2026\-10\-04; current for this exercise through 2026\-10\-31\. Allowed recipients: Ines, Dario, Celia\.
- P5B2: Synthetic record; custodian custodian extract owner Jori; recorded 2026\-10\-03; current for this exercise through 2026\-10\-31\. Allowed recipients: Ines, Dario, Celia\.
- P5B3: Synthetic record; custodian Ines recording B\-B; recorded 2026\-10\-04; current for this exercise through 2026\-10\-31\. Allowed recipients: Ines, Dario, Celia\.
- P5B4: Synthetic record; custodian Jori; recorded 2026\-10\-04; current for this exercise through 2026\-10\-31\. Allowed recipients: Ines, Dario, Celia\.
- P5B5: Synthetic record; custodian Celia document intake; recorded 2026\-10\-04; current for this exercise through 2026\-10\-31\. Allowed recipients: Ines, Dario, Celia\.
