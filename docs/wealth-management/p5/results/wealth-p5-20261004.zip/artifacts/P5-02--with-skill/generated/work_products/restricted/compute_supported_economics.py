#!/usr/bin/env python3
"""Supported HH-BRUME arithmetic from the supplied source packet only."""
from __future__ import annotations

import json
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path


AUTHORIZED_RECIPIENT_SET = ["Ines", "Dario", "Celia"]
SOURCE_PACKET = Path("resources/source-packet.json")


def money(value: Decimal) -> str:
    return str(value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def main() -> None:
    packet = json.loads(SOURCE_PACKET.read_text())
    quantity = Decimal("100")
    unit_basis = Decimal("75")
    unit_price = Decimal("52")
    fee = Decimal("40")
    unreviewed_rate = Decimal("27")

    gross_proceeds = quantity * unit_price
    basis = quantity * unit_basis
    net_proceeds = gross_proceeds - fee
    gain_loss = net_proceeds - basis

    result = {
        "schema_version": "hh-brume-supported-economics-v1",
        "authorized_recipient_set": AUTHORIZED_RECIPIENT_SET,
        "recipient_set_basis": {
            "packet_id": packet["packet_id"],
            "all_used_sources_allow_exact_recipient_set": True,
            "source_ids": ["P5B1", "P5B2", "P5B3", "P5B4", "P5B5"],
        },
        "household_id": "HH-BRUME",
        "as_of": "2026-10-04",
        "status": "needs-human-review",
        "action_taken": False,
        "delivery_status": "not-delivered",
        "calculations": {
            "proposed_sale_lot_b": {
                "source_ids": ["P5B2"],
                "quantity": "100",
                "unit_price": "52.00",
                "gross_proceeds": money(gross_proceeds),
                "estimated_fee": money(fee),
                "net_proceeds": money(net_proceeds),
                "unit_basis": "75.00",
                "basis_sold": money(basis),
                "gain_loss_before_wash_review": money(gain_loss),
                "positive_taxable_gain": "0.00",
                "taxable_loss_before_wash_review": money(gain_loss),
            },
            "unreviewed_planner_rate_sensitivity": {
                "source_ids": ["P5B3"],
                "rate_pct": "27.00",
                "conditional_amount_if_loss_were_allowed": money((-gain_loss) * unreviewed_rate / Decimal("100")),
                "support_status": "not-supported-as-tax-benefit",
                "reason": "The source identifies 27% as an unreviewed tax-benefit assumption and says Dario has not accepted a rate or loss-disallowance conclusion.",
            },
            "replacement_exposure_screen": {
                "source_ids": ["P5B3"],
                "sale_trade_date": "2026-10-04",
                "inclusive_30_day_window": {
                    "start": "2026-09-04",
                    "end": "2026-11-03",
                },
                "same_exposure_purchase": {
                    "account_id": "RET-B",
                    "purchaser": "B-B",
                    "security_id": "SEC-B",
                    "quantity": "25",
                    "trade_date": "2026-09-29",
                    "inside_window": True,
                    "potential_overlap_quantity": "25",
                },
                "conclusion": "potential replacement exposure for human tax review; deductible loss, basis adjustment, and IRA treatment not determined",
            },
        },
        "unknowns_and_limits": [
            {
                "field": "household gains/carryforwards/approved tax rate",
                "status": "absent",
                "source_ids": ["P5B2", "P5B3"],
            },
            {
                "field": "RET-B Traditional/Roth or tax-deferred/tax-free treatment",
                "status": "unspecified",
                "source_ids": ["P5B3"],
            },
            {
                "field": "activity coverage after 2026-10-04",
                "status": "incomplete",
                "source_ids": ["P5B3"],
            },
            {
                "field": "deductible loss and wash-sale disallowance",
                "status": "not determined",
                "source_ids": ["P5B2", "P5B3"],
            },
        ],
    }
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
