#!/usr/bin/env python3
"""Wrap generated HH-SEDGE workflow artifacts with explicit recipient labels."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "working"
RECIPIENTS = ["Liora", "Tamsin"]


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def write(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=False) + "\n", encoding="utf-8")


def wrap_native(raw_name: str, wrapped_name: str, label: str) -> None:
    raw = load(WORK / raw_name)
    write(
        WORK / wrapped_name,
        {
            "artifact_label": label,
            "authorized_recipients": RECIPIENTS,
            "recipient_set": "Liora, Tamsin",
            "as_of": "2026-10-04",
            "review_status": "Native output validated; independent source-field and draft review still pending.",
            "action_taken": False,
            "delivery_status": "not-delivered",
            "native_output": raw,
        },
    )


def pending_review(name: str, candidate_file: str, inventory_file: str) -> None:
    write(
        WORK / name,
        {
            "artifact_label": "Independent review not supplied",
            "authorized_recipients": RECIPIENTS,
            "recipient_set": "Liora, Tamsin",
            "as_of": "2026-10-04",
            "candidate_file": candidate_file,
            "inventory_file": inventory_file,
            "status": "pending-independent-review",
            "reason": "The skill controls require a separate reviewer for field and draft review. No separate reviewer identity, review record, or approval was supplied, so no reviewed-draft clearance is asserted.",
            "action_taken": False,
            "delivery_status": "not-delivered",
        },
    )


def wrap_receipt(raw_name: str, wrapped_name: str, label: str) -> None:
    raw = load(WORK / raw_name)
    write(
        WORK / wrapped_name,
        {
            "artifact_label": label,
            "authorized_recipients": RECIPIENTS,
            "recipient_set": "Liora, Tamsin",
            "as_of": "2026-10-04",
            "visibility": "restricted working artifact",
            "action_taken": False,
            "delivery_status": "not-delivered",
            "receipt": raw,
        },
    )


def main() -> None:
    wrap_native(
        "hh-sedge-planning-native-output-raw__authorized-Liora-Tamsin.json",
        "hh-sedge-planning-native-output__authorized-Liora-Tamsin.json",
        "HH-SEDGE native planning calculator output",
    )
    wrap_native(
        "hh-sedge-ips-native-output-raw__authorized-Liora-Tamsin.json",
        "hh-sedge-ips-native-output__authorized-Liora-Tamsin.json",
        "HH-SEDGE native IPS builder output",
    )
    pending_review(
        "hh-sedge-planning-field-review-pending__authorized-Liora-Tamsin.json",
        "working/hh-sedge-planning-candidate__authorized-Liora-Tamsin.json",
        "working/hh-sedge-planning-evidence-inventory__authorized-Liora-Tamsin.json",
    )
    pending_review(
        "hh-sedge-ips-field-review-pending__authorized-Liora-Tamsin.json",
        "working/hh-sedge-ips-candidate__authorized-Liora-Tamsin.json",
        "working/hh-sedge-ips-evidence-inventory__authorized-Liora-Tamsin.json",
    )
    for raw_name, wrapped_name, label in [
        (
            "hh-sedge-planning-audience-receipt-raw__authorized-Liora-Tamsin.json",
            "hh-sedge-planning-audience-receipt__authorized-Liora-Tamsin.json",
            "HH-SEDGE planning audience-gate receipt",
        ),
        (
            "hh-sedge-ips-audience-receipt-raw__authorized-Liora-Tamsin.json",
            "hh-sedge-ips-audience-receipt__authorized-Liora-Tamsin.json",
            "HH-SEDGE IPS audience-gate receipt",
        ),
    ]:
        if (WORK / raw_name).exists():
            wrap_receipt(raw_name, wrapped_name, label)


if __name__ == "__main__":
    main()
