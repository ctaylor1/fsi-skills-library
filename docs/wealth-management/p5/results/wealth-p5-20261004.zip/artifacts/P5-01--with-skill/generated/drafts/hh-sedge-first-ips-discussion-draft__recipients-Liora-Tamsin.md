# Draft for review

Recipients: Liora, Tamsin

Human review required. Not delivered.

## HH\-SEDGE first IPS discussion draft

Authorized recipient set: Liora, Tamsin\. Review as of 2026\-10\-04\. This is a first discussion draft for human review only\. It has no effective date and does not approve an IPS, allocation, trade, account change, or client communication\.

Sources: P5A1

## Mandate scope and lineage

The proposed IPS scope is JT\-S only; CASH\-S remains outside\. The supplied IPS method is IPS\-S v2\. This is revision 1; no prior IPS, approval, or effective mandate date is recorded\. Policy requires explicit priorities, account scope, and human approval before mandate adoption\.

Sources: P5A1, P5A4

## Discussion allocation

The discussion allocation is equity 50% with 40\-60% band, fixed income 40% with 30\-50% band, and cash 10% with 0\-20% band\. Benchmarks are pending\. Band departures prompt human review, not automatic trades\.

Sources: P5A1, P5A4

## Risk and restrictions

The cited willingness evidence is a 10% loss on the 480000 household investment/cash inventory\. Professional capacity assessment is absent and the governing risk constraint is pending\. Clients understand listed funds\. Restrictions supplied for discussion are no leverage and no direct tobacco\.

Sources: P5A1, P5A4

## Liquidity and goal context

Liquidity context comes from the planning records: protected cash floor 25000, G\-H home accessibility due in 24 months with today\-dollar cost 64000, and G\-T tuition due in 36 months with today\-dollar cost 108000\. CASH\-S remains outside the proposed IPS scope unless clients and advisor decide otherwise\.

Sources: P5A1, P5A2, P5A3, P5A4

## Mandate decisions still needed

Before adoption, clients and the advisory team still need to confirm JT\-S\-only scope, collect explicit priority between G\-H and G\-T, decide how to address goal gaps without treating this draft as a priority decision, complete capacity review and select the governing risk constraint, choose allocation and portfolio benchmarks, confirm JT\-S tax assumptions and rebalancing tax\-cost constraints, collect joint owner assent, and obtain the required human approvals\.

Sources: P5A1, P5A2, P5A3, P5A4, P5A5

## Sources used

- P5A1: Synthetic record; custodian Tamsin; recorded 2026\-10\-04; current for this exercise through 2026\-10\-31\. Allowed recipients: Liora, Tamsin\.
- P5A2: Synthetic record; custodian Liora; recorded 2026\-10\-03; current for this exercise through 2026\-10\-31\. Allowed recipients: Liora, Tamsin\.
- P5A3: Synthetic record; custodian Liora recording both clients; recorded 2026\-10\-04; current for this exercise through 2026\-10\-31\. Allowed recipients: Liora, Tamsin\.
- P5A4: Synthetic record; custodian Tamsin; recorded 2026\-10\-04; current for this exercise through 2026\-10\-31\. Allowed recipients: Liora, Tamsin\.
- P5A5: Synthetic record; custodian export custodian Elian; recorded 2026\-10\-04; current for this exercise through 2026\-10\-31\. Allowed recipients: Liora, Tamsin\.
