# Draft for review

Recipients: Liora, Tamsin

Human review required. Not delivered.

## HH\-SEDGE cash\-flow and competing\-goal review

Authorized recipient set: Liora, Tamsin\. Review as of 2026\-10\-04\. This is an internal human\-review draft only; no contact, delivery, order, approval, transaction, account change, or system change has been made\.

Sources: P5A1

## Current monthly cash flow

Supplied monthly take\-home income is $11,500\.00; regular spending excluding debt is $7,600\.00; scheduled debt service is $720\.00\. Surplus before goal savings is $3,180\.00\. The declared goal savings total $2,700\.00, leaving $480\.00 per month before any unmodeled reserve contribution\.

Sources: P5A1, P5A2, P5A3

## Cash pool and double\-counting check

CASH\-S is $70,000\.00\. After the protected cash floor of $25,000\.00, available cash is $45,000\.00\. Current goal allocations use $30,000\.00, leaving $15,000\.00 unassigned\. The goal allocations are portions of CASH\-S, not extra assets\.

Sources: P5A1, P5A2, P5A3

## Home accessibility goal G\-H

Using the supplied 3% annual cost inflation, zero return, $12,000\.00 allocated cash, and $1,100\.00 monthly saving for 24 months, the projected funding at the due date is $38,400\.00 against an inflated target of $67,897\.60\. The due\-date gap is $29,497\.60; closing it by the stated date would require an illustrative total monthly saving of $2,329\.07, or $1,229\.07 more than currently proposed\.

Sources: P5A1, P5A3, P5A5

## Tuition goal G\-T

Using the supplied 3% annual cost inflation, zero return, $18,000\.00 allocated cash, and $1,600\.00 monthly saving for 36 months, the projected funding at the due date is $75,600\.00 against an inflated target of $118,014\.52\. The due\-date gap is $42,414\.52; closing it by the stated date would require an illustrative total monthly saving of $2,778\.18, or $1,178\.18 more than currently proposed\.

Sources: P5A1, P5A3, P5A5

## What the current savings plan supports

The current plan is monthly\-cash\-flow positive by $480\.00 while both goal savings run concurrently\. It preserves the protected cash floor and leaves $15,000\.00 unassigned in CASH\-S\. It does not fully fund either stated goal by its due date at the supplied inflation and savings assumptions\. The combined due\-date gap before any unassigned\-cash decision is $71,912\.12\. If clients later chose to assign all unassigned CASH\-S, the aggregate remaining gap would be $56,912\.12, but this draft does not allocate that cash or rank goals\.

Sources: P5A1, P5A2, P5A3, P5A5

## Planning\-to\-IPS handoff

Carry forward the unknown client ranking of G\-H and G\-T, the pending use of unassigned cash, and the fact that CASH\-S is outside the proposed IPS scope\. The IPS draft should not convert planning order, export order, or this analysis into a client priority\. Debt payoff remains unmodeled because APR or interest terms were not supplied\.

Sources: P5A1, P5A2, P5A3, P5A4, P5A5

## Sources used

- P5A1: Synthetic record; custodian Tamsin; recorded 2026\-10\-04; current for this exercise through 2026\-10\-31\. Allowed recipients: Liora, Tamsin\.
- P5A2: Synthetic record; custodian Liora; recorded 2026\-10\-03; current for this exercise through 2026\-10\-31\. Allowed recipients: Liora, Tamsin\.
- P5A3: Synthetic record; custodian Liora recording both clients; recorded 2026\-10\-04; current for this exercise through 2026\-10\-31\. Allowed recipients: Liora, Tamsin\.
- P5A4: Synthetic record; custodian Tamsin; recorded 2026\-10\-04; current for this exercise through 2026\-10\-31\. Allowed recipients: Liora, Tamsin\.
- P5A5: Synthetic record; custodian export custodian Elian; recorded 2026\-10\-04; current for this exercise through 2026\-10\-31\. Allowed recipients: Liora, Tamsin\.
