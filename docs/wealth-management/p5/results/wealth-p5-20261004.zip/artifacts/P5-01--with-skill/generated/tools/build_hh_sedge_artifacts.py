#!/usr/bin/env python3
"""Build HH-SEDGE planning and IPS working artifacts from supplied local sources."""

from __future__ import annotations

import json
from copy import deepcopy
from datetime import date
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "working"
DRAFTS = ROOT / "drafts"
RECIPIENTS = ["Liora", "Tamsin"]
AS_OF = "2026-10-04"


def money(value: float) -> float:
    return round(value + 1e-9, 2)


def add_months(day: date, months: int) -> date:
    month = day.month - 1 + months
    year = day.year + month // 12
    month = month % 12 + 1
    return date(year, month, day.day)


def write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=False) + "\n", encoding="utf-8")


def source_registry(packet: dict) -> list[dict]:
    rows = []
    for source in packet["sources"]:
        rows.append(
            {
                "source_id": source["source_id"],
                "reference": source["reference"],
                "owner": source["reference"].split("; custodian ", 1)[1].split(";", 1)[0]
                if "; custodian " in source["reference"]
                else "source-packet",
                "as_of": source["access"]["effective_date"],
                "valid_until": source["access"]["valid_until"],
            }
        )
    return rows


def planning_calculations() -> dict:
    as_of = date.fromisoformat(AS_OF)
    income = 11500.0
    spending = 7600.0
    debt_service = 720.0
    goal_contributions = 1600.0 + 1100.0
    surplus_before_goals = income - spending - debt_service
    remaining_after_goals = surplus_before_goals - goal_contributions

    cash_balance = 70000.0
    protected_floor = 25000.0
    available_cash = cash_balance - protected_floor
    assigned_cash = 18000.0 + 12000.0

    goals = []
    for goal_id, label, cost, months, allocated, monthly in [
        ("G-H", "Home accessibility", 64000.0, 24, 12000.0, 1100.0),
        ("G-T", "Tuition", 108000.0, 36, 18000.0, 1600.0),
    ]:
        inflated_target = cost * (1.03 ** (months / 12))
        projected = allocated + monthly * months
        gap = max(0.0, inflated_target - projected)
        extra = gap / months if months else None
        goals.append(
            {
                "goal_id": goal_id,
                "label": label,
                "priority": None,
                "priority_status": "Not ranked by clients; legacy export numbers were entry order.",
                "target_date_used_for_calculation": add_months(as_of, months).isoformat(),
                "months_to_target": months,
                "today_dollar_cost": money(cost),
                "inflation_assumption_annual": 0.03,
                "return_assumption_annual": 0.0,
                "inflated_target_at_due_date": money(inflated_target),
                "allocated_cash": money(allocated),
                "declared_monthly_saving": money(monthly),
                "projected_funding_at_due_date": money(projected),
                "funded_ratio_at_due_date": round(projected / inflated_target, 6),
                "gap_at_due_date": money(gap),
                "illustrative_total_monthly_saving_needed_by_due_date": money((inflated_target - allocated) / months),
                "illustrative_additional_monthly_saving_needed_by_due_date": money(extra),
                "source_ids": ["P5A3", "P5A5"],
            }
        )

    total_gap = sum(goal["gap_at_due_date"] for goal in goals)
    return {
        "artifact_label": "HH-SEDGE planning calculations",
        "authorized_recipients": RECIPIENTS,
        "as_of": AS_OF,
        "currency": "USD",
        "calculation_basis": "Supplied monthly cash flow, debt service, cash allocations, 3% annual cost inflation, zero return, no contribution escalation, and no transfers between goals.",
        "source_ids": ["P5A2", "P5A3", "P5A5"],
        "monthly_cash_flow": {
            "take_home_income": money(income),
            "regular_spending_excluding_debt": money(spending),
            "scheduled_debt_service": money(debt_service),
            "surplus_before_goal_savings": money(surplus_before_goals),
            "declared_goal_savings": money(goal_contributions),
            "remaining_after_declared_goal_savings": money(remaining_after_goals),
            "formula": "11500 - 7600 - 720 - (1600 + 1100) = 480",
            "source_ids": ["P5A2", "P5A3"],
        },
        "cash_pool_ledger": {
            "cash_balance": money(cash_balance),
            "protected_cash_floor": money(protected_floor),
            "available_after_floor": money(available_cash),
            "assigned_to_goals": money(assigned_cash),
            "unassigned_after_floor_and_goal_allocations": money(available_cash - assigned_cash),
            "formula": "70000 - 25000 - 18000 - 12000 = 15000",
            "source_ids": ["P5A2", "P5A3"],
        },
        "goal_due_date_projections": goals,
        "combined_due_date_gap_before_any_unassigned_cash_decision": money(total_gap),
        "combined_gap_if_all_unassigned_cash_were_later_assigned": money(max(0.0, total_gap - 15000.0)),
        "unassigned_cash_note": "This aggregate figure does not allocate the 15000 to either goal; that requires client priority and mandate decisions.",
        "tool_limitations": [
            "Debt payoff is not projected because APR/interest terms were not supplied.",
            "Native planning projection status is withheld where the supplied schema requires goal priority, at-risk ratio, or extension-limit inputs that are not evidenced.",
            "Extension-date illustrations are not included because continuing contributions after the stated due dates would add an assumption not supplied in the packet.",
        ],
    }


def native_planning_request(sources: list[dict]) -> dict:
    return {
        "schema_version": "wealth-p0-v1",
        "request_id": "HH-SEDGE-planning-native-2026-10-04",
        "household_id": "HH-SEDGE",
        "as_of": AS_OF,
        "engagement": {"capacity": "advisory", "jurisdiction": "US"},
        "sources": sources,
        "upstream_issues": [
            {
                "artifact_id": "source-packet-P5-01-SOURCES-v1",
                "code": "goal-priority-unknown",
                "message": "Clients have not ranked G-T and G-H; export priority numbers were only entry order.",
                "status": "unresolved",
                "source_ids": ["P5A3", "P5A5"],
            }
        ],
        "currency": "USD",
        "mode": "household_plan",
        "assumptions": {
            "version": "PLAN-S v1",
            "return_convention": "nominal-rate-monthly-net-of-fees-and-modeled-tax",
            "nominal_annual_return": 0.0,
            "annual_inflation": 0.03,
            "extension_limit_months": None,
            "at_risk_ratio": None,
            "source_ids": ["P5A1", "P5A3"],
        },
        "asset_pools": [
            {"pool_id": "cash-goal-pool", "account_ids": ["CASH-S"], "balance": 70000.0, "reserved_amount": 25000.0, "source_ids": ["P5A2"]}
        ],
        "goals": [
            {
                "goal_id": "G-H",
                "label": "Home accessibility",
                "priority": None,
                "target_amount": 64000.0,
                "target_date": "2028-10-04",
                "target_basis": "as_of_real",
                "monthly_contribution": 1100.0,
                "allocations": [{"pool_id": "cash-goal-pool", "amount": 12000.0, "source_ids": ["P5A3"]}],
                "source_ids": ["P5A3", "P5A5"],
            },
            {
                "goal_id": "G-T",
                "label": "Tuition",
                "priority": None,
                "target_amount": 108000.0,
                "target_date": "2029-10-04",
                "target_basis": "as_of_real",
                "monthly_contribution": 1600.0,
                "allocations": [{"pool_id": "cash-goal-pool", "amount": 18000.0, "source_ids": ["P5A3"]}],
                "source_ids": ["P5A3", "P5A5"],
            },
        ],
        "cash_flow": {
            "expense_basis": "excludes-debt-goals-reserve;income-after-tax",
            "income": [{"item_id": "take-home", "label": "Monthly take-home income", "monthly_amount": 11500.0, "source_ids": ["P5A2"]}],
            "expenses": [{"item_id": "regular-spending", "label": "Regular spending excluding debt", "monthly_amount": 7600.0, "source_ids": ["P5A2"]}],
            "monthly_reserve_contribution": 0.0,
            "source_ids": ["P5A2"],
        },
        "debts": [
            {
                "debt_id": "D-S",
                "label": "Debt D-S",
                "balance": 82000.0,
                "apr": None,
                "minimum_monthly_payment": 720.0,
                "additional_monthly_payment": 0.0,
                "source_ids": ["P5A2"],
            }
        ],
    }


def planning_candidate(packet: dict, calculations: dict, native_request: dict) -> dict:
    return {
        "artifact_label": "HH-SEDGE household cash-flow and competing-goal review candidate",
        "authorized_recipients": RECIPIENTS,
        "audience": "Planner Liora and advisor Tamsin only",
        "as_of": AS_OF,
        "source_packet_id": packet["packet_id"],
        "sources_used": ["P5A1", "P5A2", "P5A3", "P5A4", "P5A5"],
        "supplied_facts": {
            "household": "HH-SEDGE, US advisory household in USD, clients S-A and S-B.",
            "inventory": {"JT-S": 410000.0, "CASH-S": 70000.0, "D-S": 82000.0},
            "cash_floor": 25000.0,
            "monthly_flows": {"take_home_income": 11500.0, "regular_spending_excluding_debt": 7600.0, "debt_service": 720.0},
            "goals": native_request["goals"],
            "client_priority_status": "Unknown. Clients have not ranked the goals; legacy priority numbers were entry order.",
            "action_taken": False,
        },
        "calculation_output": calculations,
        "native_planning_input_file": "working/hh-sedge-planning-native-request__authorized-Liora-Tamsin.json",
        "handoff_to_ips": {
            "do_not_decide_priority": True,
            "useful_context": [
                "Declared savings fit current monthly cash flow by 480 per month before any unmodeled reserve contribution.",
                "Goal due-date projections remain underfunded at the current declared savings rates.",
                "CASH-S is outside proposed IPS scope; JT-S is proposed IPS scope only.",
                "Goal priority, use of unassigned cash, contribution changes, and date/amount tradeoffs require client/advisor decisions.",
            ],
            "source_ids": ["P5A2", "P5A3", "P5A4", "P5A5"],
        },
    }


def ips_candidate(packet: dict) -> dict:
    return {
        "artifact_label": "HH-SEDGE first IPS discussion draft candidate",
        "authorized_recipients": RECIPIENTS,
        "audience": "Planner Liora and advisor Tamsin only",
        "as_of": AS_OF,
        "source_packet_id": packet["packet_id"],
        "ips_id": "HH-SEDGE-IPS-discussion-2026-10-04",
        "revision": 1,
        "effective_date": None,
        "supersedes_artifact_id": None,
        "action_taken": False,
        "scope": {
            "included_account_ids": ["JT-S"],
            "excluded_account_ids": ["CASH-S"],
            "source_ids": ["P5A4"],
        },
        "template_and_policy": {
            "template_or_method": "IPS-S v2",
            "policy_notes": [
                "Explicit priorities, account scope, and human approval are required before mandate adoption.",
                "No prior IPS, approval, or effective mandate date is recorded.",
            ],
            "source_ids": ["P5A1"],
        },
        "discussion_allocation": {
            "equity": {"target_pct": 50.0, "min_pct": 40.0, "max_pct": 60.0, "benchmark": None},
            "fixed_income": {"target_pct": 40.0, "min_pct": 30.0, "max_pct": 50.0, "benchmark": None},
            "cash": {"target_pct": 10.0, "min_pct": 0.0, "max_pct": 20.0, "benchmark": None},
            "benchmark_status": "Pending.",
            "source_ids": ["P5A4"],
        },
        "risk_and_constraints": {
            "willingness": "Client questionnaire willingness is 10% loss on the 480000 household investment/cash inventory.",
            "capacity": None,
            "capacity_status": "Professional capacity assessment absent.",
            "governing_risk_constraint": None,
            "governing_risk_constraint_status": "Pending.",
            "experience": "Clients understand listed funds.",
            "restrictions": ["No leverage", "No direct tobacco"],
            "source_ids": ["P5A4"],
        },
        "liquidity_and_goals_context": {
            "protected_cash_floor": 25000.0,
            "cash_account_outside_ips": "CASH-S",
            "goals": [
                {"goal_id": "G-H", "label": "Home accessibility", "today_dollar_cost": 64000.0, "due_months": 24},
                {"goal_id": "G-T", "label": "Tuition", "today_dollar_cost": 108000.0, "due_months": 36},
            ],
            "source_ids": ["P5A2", "P5A3", "P5A4"],
        },
        "monitoring_and_rebalancing": {
            "review_frequency": "Annual review.",
            "band_departures": "Prompt human review, not automatic trades.",
            "source_ids": ["P5A4"],
        },
        "mandate_decisions_pending": [
            {"decision": "Confirm whether JT-S-only scope is the intended IPS mandate scope and CASH-S remains outside.", "source_ids": ["P5A4"]},
            {"decision": "Collect explicit client priorities for G-T and G-H before using planning goals to govern IPS objectives.", "source_ids": ["P5A1", "P5A3", "P5A5"]},
            {"decision": "Resolve whether goal gaps are addressed by higher savings, unassigned cash, changed dates, changed amounts, or another client-approved tradeoff.", "source_ids": ["P5A2", "P5A3", "P5A5"]},
            {"decision": "Complete professional capacity assessment and choose the governing risk constraint.", "source_ids": ["P5A4"]},
            {"decision": "Select benchmarks for the allocation sleeves and overall portfolio benchmark.", "source_ids": ["P5A4"]},
            {"decision": "Collect joint owner assent and human approvals before mandate adoption.", "source_ids": ["P5A1", "P5A5"]},
            {"decision": "Confirm tax assumptions/treatment for JT-S and any tax-cost constraints for rebalancing.", "source_ids": ["P5A2", "P5A4"]},
        ],
    }


def native_ips_request(sources: list[dict], ips: dict) -> dict:
    sections = [
        "purpose",
        "governance",
        "objectives",
        "risk_profile",
        "time_horizon",
        "liquidity",
        "tax",
        "constraints",
        "allocation",
        "rebalancing",
        "monitoring",
        "approvals",
        "disclosures",
    ]
    return {
        "schema_version": "wealth-p0-v1",
        "request_id": "HH-SEDGE-ips-native-2026-10-04",
        "household_id": "HH-SEDGE",
        "as_of": AS_OF,
        "engagement": {"capacity": "advisory", "jurisdiction": "US"},
        "sources": sources,
        "upstream_issues": [
            {
                "artifact_id": "HH-SEDGE-planning-working-2026-10-04",
                "code": "planning-priority-pending",
                "message": "Planning review preserves unknown goal priority and does not decide between G-T and G-H.",
                "status": "unresolved",
                "source_ids": ["P5A3", "P5A5"],
            }
        ],
        "currency": "USD",
        "ips_id": ips["ips_id"],
        "revision": 1,
        "supersedes_artifact_id": None,
        "template": {"template_id": "IPS-S", "version": "v2", "required_sections": sections, "source_ids": ["P5A1"]},
        "mandate": {
            "purpose": {"text": "Discussion IPS scope proposed for JT-S only; CASH-S remains outside.", "account_ids": ["JT-S"], "source_ids": ["P5A4"]},
            "governance": {
                "decision_authority": "Policy requires explicit priorities, account scope and human approval before mandate adoption.",
                "capacity_basis": "US advisory household; professional capacity assessment for risk is absent.",
                "parties": [
                    {"party_id": "S-A", "role": "client", "responsibility": "Client approval and priority decisions pending.", "source_ids": ["P5A1", "P5A5"]},
                    {"party_id": "S-B", "role": "client", "responsibility": "Client approval and priority decisions pending; joint owner assent not collected.", "source_ids": ["P5A1", "P5A5"]},
                ],
                "source_ids": ["P5A1", "P5A4", "P5A5"],
            },
            "objectives": {
                "return_objective": "Pending client priority and governing risk decision; current planning context shows stated goal schedules are underfunded at declared savings rates.",
                "spending_objective": "No portfolio distribution objective supplied for JT-S.",
                "items": [
                    {"objective_id": "preserve-discussion-allocation", "description": "Discuss proposed 50/40/10 allocation for JT-S only.", "priority": None, "source_ids": ["P5A4"]},
                    {"objective_id": "coordinate-goal-funding", "description": "Coordinate IPS discussion with G-H and G-T timing without ranking goals.", "priority": None, "source_ids": ["P5A3", "P5A5"]},
                ],
                "source_ids": ["P5A3", "P5A4", "P5A5"],
            },
            "risk_profile": {
                "profile_artifact_id": None,
                "governing_constraint": None,
                "human_reviewer": None,
                "assessment_reference": "Client questionnaire willingness: 10% loss on 480000 household investment/cash inventory.",
                "dimensions": [
                    {"dimension": "willingness", "assessment": "10% loss willingness on 480000 household investment/cash inventory.", "source_ids": ["P5A4"]},
                    {"dimension": "loss-capacity", "assessment": None, "source_ids": ["P5A4"]},
                    {"dimension": "liquidity", "assessment": "Protected cash floor 25000; CASH-S outside proposed IPS scope; goal dates follow planning records.", "source_ids": ["P5A2", "P5A3", "P5A4"]},
                    {"dimension": "horizon", "assessment": "Goal context includes 24-month G-H and 36-month G-T dates; separate JT-S investment horizon pending.", "source_ids": ["P5A3", "P5A4"]},
                    {"dimension": "experience", "assessment": "Clients understand listed funds.", "source_ids": ["P5A4"]},
                    {"dimension": "constraints", "assessment": "No leverage/direct tobacco; benchmark and governing risk constraint pending.", "source_ids": ["P5A4"]},
                ],
                "unresolved_findings": [
                    {"description": "Benchmark and governing risk constraint pending; professional capacity assessment absent.", "source_ids": ["P5A4"]},
                    {"description": "Joint owner assent to mandate not collected.", "source_ids": ["P5A5"]},
                ],
                "source_ids": ["P5A4", "P5A5"],
            },
            "time_horizon": {"months": None, "stage": "Separate JT-S mandate horizon pending; planning goals occur in 24 and 36 months.", "source_ids": ["P5A3", "P5A4"]},
            "liquidity": {
                "reserve_amount": 25000.0,
                "annual_distribution": None,
                "events": [
                    {"event_id": "G-H", "date": "2028-10-04", "amount": 64000.0, "purpose": "Home accessibility today-dollar cost; funding source decision pending.", "source_ids": ["P5A3"]},
                    {"event_id": "G-T", "date": "2029-10-04", "amount": 108000.0, "purpose": "Tuition today-dollar cost; funding source decision pending.", "source_ids": ["P5A3"]},
                ],
                "source_ids": ["P5A2", "P5A3", "P5A4"],
            },
            "tax": {
                "assumptions_version": None,
                "limitations": "Tax assumptions and tax-cost constraints were not supplied; JT-S is identified as joint taxable.",
                "account_treatments": [{"account_id": "JT-S", "registration": "joint taxable", "treatment": "taxable", "source_ids": ["P5A2"]}],
                "source_ids": ["P5A2", "P5A4"],
            },
            "constraints": {
                "none_identified": False,
                "items": [
                    {"constraint_id": "no-leverage", "description": "No leverage.", "source_ids": ["P5A4"]},
                    {"constraint_id": "no-direct-tobacco", "description": "No direct tobacco.", "source_ids": ["P5A4"]},
                ],
                "source_ids": ["P5A4"],
            },
            "allocation": [
                {"asset_class": "Equity", "target_pct": 50.0, "min_pct": 40.0, "max_pct": 60.0, "benchmark": None, "source_ids": ["P5A4"]},
                {"asset_class": "Fixed income", "target_pct": 40.0, "min_pct": 30.0, "max_pct": 50.0, "benchmark": None, "source_ids": ["P5A4"]},
                {"asset_class": "Cash", "target_pct": 10.0, "min_pct": 0.0, "max_pct": 20.0, "benchmark": None, "source_ids": ["P5A4"]},
            ],
            "rebalancing": {
                "method": "hybrid",
                "frequency": "annual",
                "tax_cost_constraints": None,
                "exception_owner": None,
                "threshold_percentage_points": 10.0,
                "source_ids": ["P5A4"],
            },
            "monitoring": {
                "portfolio_benchmark": None,
                "frequency": "annual",
                "owner": None,
                "review_triggers": ["Annual review", "Band departures prompt human review"],
                "source_ids": ["P5A4"],
            },
            "approvals": [],
            "disclosures": {
                "text": "Draft discussion only. No prior IPS, approval or effective mandate date is recorded; band departures prompt human review, not automatic trades.",
                "version": "revision 1 discussion draft",
                "source_ids": ["P5A1", "P5A4"],
            },
        },
    }


def audience_request(request_id: str) -> dict:
    return {
        "schema_version": "wealth-audience-request-v1",
        "request_id": request_id,
        "as_of": AS_OF,
        "recipient_ids": RECIPIENTS,
    }


def planning_plan(calc: dict) -> dict:
    cf = calc["monthly_cash_flow"]
    ledger = calc["cash_pool_ledger"]
    home, tuition = calc["goal_due_date_projections"]
    return {
        "schema_version": "wealth-audience-plan-v1",
        "blocks": [
            {
                "block_id": "planning-purpose",
                "heading": "HH-SEDGE cash-flow and competing-goal review",
                "text": "Authorized recipient set: Liora, Tamsin. Review as of 2026-10-04. This is an internal human-review draft only; no contact, delivery, order, approval, transaction, account change, or system change has been made.",
                "source_ids": ["P5A1"],
                "depends_on_block_ids": [],
                "claim_ids": ["/artifact_label", "/authorized_recipients", "/as_of"],
            },
            {
                "block_id": "planning-cash-flow",
                "heading": "Current monthly cash flow",
                "text": f"Supplied monthly take-home income is ${cf['take_home_income']:,.2f}; regular spending excluding debt is ${cf['regular_spending_excluding_debt']:,.2f}; scheduled debt service is ${cf['scheduled_debt_service']:,.2f}. Surplus before goal savings is ${cf['surplus_before_goal_savings']:,.2f}. The declared goal savings total ${cf['declared_goal_savings']:,.2f}, leaving ${cf['remaining_after_declared_goal_savings']:,.2f} per month before any unmodeled reserve contribution.",
                "source_ids": ["P5A2", "P5A3"],
                "depends_on_block_ids": ["planning-purpose"],
                "claim_ids": ["/calculation_output/monthly_cash_flow"],
            },
            {
                "block_id": "planning-cash-ledger",
                "heading": "Cash pool and double-counting check",
                "text": f"CASH-S is ${ledger['cash_balance']:,.2f}. After the protected cash floor of ${ledger['protected_cash_floor']:,.2f}, available cash is ${ledger['available_after_floor']:,.2f}. Current goal allocations use ${ledger['assigned_to_goals']:,.2f}, leaving ${ledger['unassigned_after_floor_and_goal_allocations']:,.2f} unassigned. The goal allocations are portions of CASH-S, not extra assets.",
                "source_ids": ["P5A2", "P5A3"],
                "depends_on_block_ids": ["planning-purpose"],
                "claim_ids": ["/calculation_output/cash_pool_ledger"],
            },
            {
                "block_id": "planning-home",
                "heading": "Home accessibility goal G-H",
                "text": f"Using the supplied 3% annual cost inflation, zero return, ${home['allocated_cash']:,.2f} allocated cash, and ${home['declared_monthly_saving']:,.2f} monthly saving for 24 months, the projected funding at the due date is ${home['projected_funding_at_due_date']:,.2f} against an inflated target of ${home['inflated_target_at_due_date']:,.2f}. The due-date gap is ${home['gap_at_due_date']:,.2f}; closing it by the stated date would require an illustrative total monthly saving of ${home['illustrative_total_monthly_saving_needed_by_due_date']:,.2f}, or ${home['illustrative_additional_monthly_saving_needed_by_due_date']:,.2f} more than currently proposed.",
                "source_ids": ["P5A3", "P5A5"],
                "depends_on_block_ids": ["planning-purpose"],
                "claim_ids": ["/calculation_output/goal_due_date_projections/0"],
            },
            {
                "block_id": "planning-tuition",
                "heading": "Tuition goal G-T",
                "text": f"Using the supplied 3% annual cost inflation, zero return, ${tuition['allocated_cash']:,.2f} allocated cash, and ${tuition['declared_monthly_saving']:,.2f} monthly saving for 36 months, the projected funding at the due date is ${tuition['projected_funding_at_due_date']:,.2f} against an inflated target of ${tuition['inflated_target_at_due_date']:,.2f}. The due-date gap is ${tuition['gap_at_due_date']:,.2f}; closing it by the stated date would require an illustrative total monthly saving of ${tuition['illustrative_total_monthly_saving_needed_by_due_date']:,.2f}, or ${tuition['illustrative_additional_monthly_saving_needed_by_due_date']:,.2f} more than currently proposed.",
                "source_ids": ["P5A3", "P5A5"],
                "depends_on_block_ids": ["planning-purpose"],
                "claim_ids": ["/calculation_output/goal_due_date_projections/1"],
            },
            {
                "block_id": "planning-choices",
                "heading": "What the current savings plan supports",
                "text": f"The current plan is monthly-cash-flow positive by ${cf['remaining_after_declared_goal_savings']:,.2f} while both goal savings run concurrently. It preserves the protected cash floor and leaves ${ledger['unassigned_after_floor_and_goal_allocations']:,.2f} unassigned in CASH-S. It does not fully fund either stated goal by its due date at the supplied inflation and savings assumptions. The combined due-date gap before any unassigned-cash decision is ${calc['combined_due_date_gap_before_any_unassigned_cash_decision']:,.2f}. If clients later chose to assign all unassigned CASH-S, the aggregate remaining gap would be ${calc['combined_gap_if_all_unassigned_cash_were_later_assigned']:,.2f}, but this draft does not allocate that cash or rank goals.",
                "source_ids": ["P5A2", "P5A3", "P5A5"],
                "depends_on_block_ids": ["planning-cash-flow", "planning-cash-ledger", "planning-home", "planning-tuition"],
                "claim_ids": ["/calculation_output/combined_due_date_gap_before_any_unassigned_cash_decision", "/calculation_output/combined_gap_if_all_unassigned_cash_were_later_assigned"],
            },
            {
                "block_id": "planning-handoff",
                "heading": "Planning-to-IPS handoff",
                "text": "Carry forward the unknown client ranking of G-H and G-T, the pending use of unassigned cash, and the fact that CASH-S is outside the proposed IPS scope. The IPS draft should not convert planning order, export order, or this analysis into a client priority. Debt payoff remains unmodeled because APR or interest terms were not supplied.",
                "source_ids": ["P5A2", "P5A3", "P5A4", "P5A5"],
                "depends_on_block_ids": ["planning-choices"],
                "claim_ids": ["/handoff_to_ips", "/calculation_output/tool_limitations"],
            },
        ],
    }


def ips_plan() -> dict:
    return {
        "schema_version": "wealth-audience-plan-v1",
        "blocks": [
            {
                "block_id": "ips-purpose",
                "heading": "HH-SEDGE first IPS discussion draft",
                "text": "Authorized recipient set: Liora, Tamsin. Review as of 2026-10-04. This is a first discussion draft for human review only. It has no effective date and does not approve an IPS, allocation, trade, account change, or client communication.",
                "source_ids": ["P5A1"],
                "depends_on_block_ids": [],
                "claim_ids": ["/artifact_label", "/authorized_recipients", "/as_of", "/effective_date"],
            },
            {
                "block_id": "ips-scope",
                "heading": "Mandate scope and lineage",
                "text": "The proposed IPS scope is JT-S only; CASH-S remains outside. The supplied IPS method is IPS-S v2. This is revision 1; no prior IPS, approval, or effective mandate date is recorded. Policy requires explicit priorities, account scope, and human approval before mandate adoption.",
                "source_ids": ["P5A1", "P5A4"],
                "depends_on_block_ids": ["ips-purpose"],
                "claim_ids": ["/scope", "/template_and_policy"],
            },
            {
                "block_id": "ips-allocation",
                "heading": "Discussion allocation",
                "text": "The discussion allocation is equity 50% with 40-60% band, fixed income 40% with 30-50% band, and cash 10% with 0-20% band. Benchmarks are pending. Band departures prompt human review, not automatic trades.",
                "source_ids": ["P5A4"],
                "depends_on_block_ids": ["ips-purpose"],
                "claim_ids": ["/discussion_allocation", "/monitoring_and_rebalancing"],
            },
            {
                "block_id": "ips-risk",
                "heading": "Risk and restrictions",
                "text": "The cited willingness evidence is a 10% loss on the 480000 household investment/cash inventory. Professional capacity assessment is absent and the governing risk constraint is pending. Clients understand listed funds. Restrictions supplied for discussion are no leverage and no direct tobacco.",
                "source_ids": ["P5A4"],
                "depends_on_block_ids": ["ips-purpose"],
                "claim_ids": ["/risk_and_constraints"],
            },
            {
                "block_id": "ips-liquidity",
                "heading": "Liquidity and goal context",
                "text": "Liquidity context comes from the planning records: protected cash floor 25000, G-H home accessibility due in 24 months with today-dollar cost 64000, and G-T tuition due in 36 months with today-dollar cost 108000. CASH-S remains outside the proposed IPS scope unless clients and advisor decide otherwise.",
                "source_ids": ["P5A2", "P5A3", "P5A4"],
                "depends_on_block_ids": ["ips-scope"],
                "claim_ids": ["/liquidity_and_goals_context"],
            },
            {
                "block_id": "ips-decisions",
                "heading": "Mandate decisions still needed",
                "text": "Before adoption, clients and the advisory team still need to confirm JT-S-only scope, collect explicit priority between G-H and G-T, decide how to address goal gaps without treating this draft as a priority decision, complete capacity review and select the governing risk constraint, choose allocation and portfolio benchmarks, confirm JT-S tax assumptions and rebalancing tax-cost constraints, collect joint owner assent, and obtain the required human approvals.",
                "source_ids": ["P5A1", "P5A2", "P5A3", "P5A4", "P5A5"],
                "depends_on_block_ids": ["ips-scope", "ips-allocation", "ips-risk", "ips-liquidity"],
                "claim_ids": ["/mandate_decisions_pending"],
            },
        ],
    }


def main() -> None:
    packet = json.loads((ROOT / "resources" / "source-packet.json").read_text(encoding="utf-8"))
    sources = source_registry(packet)
    calculations = planning_calculations()
    plan_request = native_planning_request(sources)
    plan_candidate = planning_candidate(packet, calculations, plan_request)
    ips = ips_candidate(packet)
    ips_request = native_ips_request(sources, ips)

    WORK.mkdir(exist_ok=True)
    DRAFTS.mkdir(exist_ok=True)

    write_json(WORK / "hh-sedge-planning-calculations__authorized-Liora-Tamsin.json", calculations)
    write_json(WORK / "hh-sedge-planning-native-request__authorized-Liora-Tamsin.json", plan_request)
    write_json(WORK / "hh-sedge-planning-candidate__authorized-Liora-Tamsin.json", plan_candidate)
    write_json(WORK / "hh-sedge-ips-candidate__authorized-Liora-Tamsin.json", ips)
    write_json(WORK / "hh-sedge-ips-native-request__authorized-Liora-Tamsin.json", ips_request)
    write_json(WORK / "hh-sedge-planning-audience-request__authorized-Liora-Tamsin.json", audience_request("HH-SEDGE-planning-Liora-Tamsin-2026-10-04"))
    write_json(WORK / "hh-sedge-ips-audience-request__authorized-Liora-Tamsin.json", audience_request("HH-SEDGE-ips-Liora-Tamsin-2026-10-04"))
    write_json(WORK / "hh-sedge-planning-content-plan__authorized-Liora-Tamsin.json", planning_plan(calculations))
    write_json(WORK / "hh-sedge-ips-content-plan__authorized-Liora-Tamsin.json", ips_plan())

    index = {
        "artifact_label": "HH-SEDGE artifact index",
        "authorized_recipients": RECIPIENTS,
        "as_of": AS_OF,
        "delivery_status": "not-delivered",
        "action_taken": False,
        "files": [
            "drafts/hh-sedge-cash-flow-and-competing-goal-review__recipients-Liora-Tamsin.md",
            "drafts/hh-sedge-first-ips-discussion-draft__recipients-Liora-Tamsin.md",
            "working/hh-sedge-planning-calculations__authorized-Liora-Tamsin.json",
            "working/hh-sedge-planning-native-request__authorized-Liora-Tamsin.json",
            "working/hh-sedge-planning-native-output__authorized-Liora-Tamsin.json",
            "working/hh-sedge-planning-candidate__authorized-Liora-Tamsin.json",
            "working/hh-sedge-ips-candidate__authorized-Liora-Tamsin.json",
            "working/hh-sedge-ips-native-request__authorized-Liora-Tamsin.json",
            "working/hh-sedge-ips-native-output__authorized-Liora-Tamsin.json",
            "working/*inventory*__authorized-Liora-Tamsin.json",
            "working/*audience*__authorized-Liora-Tamsin.json",
        ],
        "review_status": "Pending independent source-field and draft review; no reviewer identity or approval was supplied.",
    }
    write_json(WORK / "hh-sedge-artifact-index__authorized-Liora-Tamsin.json", index)


if __name__ == "__main__":
    main()
