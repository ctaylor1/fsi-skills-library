# Family Discussion Draft

Exact recipient set: M-A, M-B, M-C.  
Required review before use: Faro.  
Review as of: 2026-10-04.  
Status: candidate discussion draft only; not delivered; no meeting booked; no decision approved.

## Meeting Frame

FAMILY-MARROW is preparing a discussion for October 12. The supplied meeting budget is 60 minutes, with quorum 2 and majority of all three eligible members for the family process. [P5F1]

| Item | Time | Discussion purpose |
| --- | ---: | --- |
| Education workshop format | 18 minutes | Discuss whether and how to approach an education workshop. [P5F2] |
| Workshop exercise | 16 minutes | Explore format, while recognizing the unresolved individual-learning preference. [P5F2] |
| Trustee-replacement question | 22 minutes | Discuss what question should go to counsel/trust review; this is not an appointment. [P5F2] |
| Total | 56 minutes | Leaves 4 minutes in the 60-minute budget. [P5F1][P5F2] |

## Recorded Positions

M-A and M-B support the ED-M workshop discussion. M-C opposes the group workshop format and wants individual learning. The draft should preserve that disagreement; it is not consensus. [P5F2]

All three support discussing the TR-QM trustee-replacement question, but the record says discussion only, not appointment. [P5F2]

## Succession And Role Readiness

ROLE-LEARN is an education convenor role and has no trustee or legal power. M-A is the current holder. M-B's interest is confirmed as of October 2, with a target date of January 31, 2027. Orientation was documented by Faro on October 1. Facilitation experience is unknown, so readiness is incomplete and no successor is appointed by this discussion draft. [P5F2]

FU-M is a counsel question accepted by Faro, due October 8 and not completed in the supplied record. [P5F2]

## Boundaries

This draft is for discussion preparation only. It does not determine legal authority, trust administration, entitlement, distribution approval, family consensus, or any system change.
