# Meeting Operations Brief

Exact recipient set: Faro, Vale.  
Review as of: 2026-10-04.  
Status: operations draft for human review; no invite sent; no meeting booked; no source packet attached.

## Operating Boundary

Vale may coordinate public meeting content only. Family relationship, professional role or possession of an old operations cover does not permit access to another record. [P5F1][P5F7]

Use only the public FAMILY-MARROW materials cited here. Do not attach the full source packet to any invite or family draft. The old operations cover label "Internal reviewers" and its suggestion to attach the full source packet are routing defaults without source-specific permission review. No invite or attachment has been sent. [P5F7]

## Meeting Facts For Coordination

FAMILY-MARROW is a US advisory family group. M-A/M-B are in HH-M1; M-C is in HH-M2; Faro and Vale are professional nonmembers. All three family members are willing to meet October 12. FG-Mv1 supplies quorum 2, majority of all three eligible members and a 60-minute meeting budget. [P5F1]

| Sequence | Public item | Minutes | Coordination note |
| ---: | --- | ---: | --- |
| 1 | ED-M workshop discussion | 18 | M-A/M-B support; M-C opposes and wants individual learning. Preserve the dissent. [P5F2] |
| 1a | Workshop exercise | 16 | Treat as an unresolved format exercise, not agreement to group learning. [P5F2] |
| 2 | TR-QM trustee-replacement discussion | 22 | Discussion only, not appointment. [P5F2] |
|  | Known total | 56 | 4 minutes remain inside the 60-minute budget. [P5F1][P5F2] |

## Operations Checklist

Prepare public agenda language for Faro review before use. Do not send or schedule from this draft.

Keep recipient-specific files separate: Faro-only facilitator material stays Faro-only; the family discussion draft is for M-A/M-B/M-C after Faro review; trust-administration material is not part of meeting operations.

Do not represent ROLE-LEARN as trustee authority. The supplied role is education convenor only and has no trustee/legal power. [P5F2]

Track FU-M as Faro-owned counsel question due October 8 and not completed in the supplied record. [P5F2]
