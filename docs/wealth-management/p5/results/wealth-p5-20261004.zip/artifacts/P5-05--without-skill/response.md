Done. I prepared the three recipient-specific draft files plus two separately labeled working artifacts:

- [Advisor prep / assessment note, Remi only](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-_gs_lz22/work/outputs/HH-OLIVE_advisor_preparation_assessment_Remi_only_2026-10-04.md:1)
- [Service follow-up brief, Remi and Sasha](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-_gs_lz22/work/outputs/HH-OLIVE_service_follow_up_brief_Remi_Sasha_2026-10-04.md:1)
- [Joint-client follow-up draft, Remi review then Mae and Nolan](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-_gs_lz22/work/outputs/HH-OLIVE_joint_client_follow_up_draft_Mae_Nolan_Remi_review_2026-10-04.md:1)
- [Remi-only source/permission working file](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-_gs_lz22/work/outputs/HH-OLIVE_working_remi_only_source_permission_assessment_2026-10-04.json:1)
- [Shared calculation working file](/private/var/folders/dg/4dnc0v5d0vg_v97qdpt22y500000gn/T/wealth-p4-model-_gs_lz22/work/outputs/HH-OLIVE_working_shared_calculation_pack_2026-10-04.json:1)

I validated both JSON files and scanned the Sasha/client/shared artifacts for the Remi-only private source terms; no restricted private material leaked into those files.