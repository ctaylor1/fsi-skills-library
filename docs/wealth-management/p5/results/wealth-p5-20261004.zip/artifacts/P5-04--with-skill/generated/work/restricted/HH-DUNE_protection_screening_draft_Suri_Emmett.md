# Draft for review

Recipients: Emmett, Suri

Human review required. Not delivered.

## Recipient set and scope

Exact recipient set: Suri and Emmett only\. This is a pending internal protection\-screening draft for HH\-DUNE as of 2026\-10\-04 under the supplied US brokerage profile\. It is based only on the supplied synthetic records\. WD\-D is a proposed\-not\-executed 12400 debit request to PAY\-D; no account restriction, hold, contact, order, approval, filing, delivery, diagnosis, or system change has occurred\. Sources: P5D1, P5D4, P5D5\.

Sources: P5D1, P5D4, P5D5

## Screening arithmetic

Supplied executed baseline debits before the focal request are 900 on 2026\-09\-04, 1100 on 2026\-09\-14, and 1300 on 2026\-09\-24, all to PAY\-R\. Population mean is 1100\. Population SD is approximately 163\.299316\. Mean plus 3 SD is approximately 1589\.897949\. The proposed WD\-D amount, 12400, exceeds that comparison level\. PAY\-D is absent from the supplied pre\-focal baseline payees and the focal amount exceeds the supplied 7000 proposed new\-payee threshold\. For the 2026\-09\-28 through 2026\-10\-04 recent\-outflow screen, executed debit total is 0 against the supplied 15000 threshold because proposed and cancelled activity are excluded\. The 4200 PAY\-Z request was cancelled before execution\. Sources: P5D1, P5D2, P5D4\.

Sources: P5D1, P5D2, P5D4

## Observation limits

Observation recorder: Bela\. Incident reviewer: unknown or absent in the supplied packet\. The packet states that inherited incident\_reviewed\_by, incident\_reviewed\_on, and capacity\_screen defaults were withdrawn on 2026\-10\-04; Suri signed profile routing on 2026\-10\-01, not this incident\. Supplied observations record influence=true, urgency=true, and secrecy=true\. Confusion, recall difficulty, and repetition were not assessed; blank boxes are not checked\-no\. Comprehension, freedom from coercion, capacity assessment, legal applicability review, and exploitation determination are not established\. Sources: P5D3, P5D4, P5D5\.

Sources: P5D3, P5D4, P5D5

## Native tool status and data gaps

The native screener output validates structurally but remains needs\-data\. Tool limitation: because the supplied SCR\-D v2 record does not evidence change\_window\_days or tc\_stale\_days, the native calculator marks several configuration\-gated signals not evaluable rather than applying a default\. Additional unknowns preserved in the candidate are impairment applicability, new caregiver or POA, confusion, recall, repetition, refusal of family involvement, scam narrative flag, and recent account\-change coverage\. The trusted\-contact field is blank because staff did not ask; no decline is recorded, and the supplied profile says trusted contact is administrative\. Sources: P5D1, P5D3, P5D4, P5D5\.

Sources: P5D1, P5D3, P5D4, P5D5

## Screening priority only

Screening priority for human review: escalate for human review under the supplied profile and library convention, because third\-party influence and communication red flags are supplied as positive observations\. This is not a finding of exploitation, incapacity, coercion, legal applicability, or transaction approval\. It is not an instruction to hold funds, restrict the account, contact anyone, file a report, approve the withdrawal, or change a system\. Sources: P5D3, P5D4\.

Sources: P5D3, P5D4

## Reviewer questions

Questions for Suri and Emmett: confirm whether WD\-D remains proposed\-not\-executed and whether any later lifecycle event exists outside this packet; confirm the source and role of the caller who supplied PAY\-D instructions; determine whether PAY\-D has any relationship to HH\-DUNE outside the bounded supplied baseline; complete or document the unassessed observation fields without treating blanks as negative observations; determine whether any beneficiary, registration, or address changes exist in the relevant change window; resolve the trusted\-contact collection status under firm policy without treating absence as exploitation; assign any incident reviewer and legal\-applicability review through the human process; ask for benign explanations such as planned purchase, client\-directed gift or assistance, or communication/accessibility preference if appropriate through authorized procedures\. Sources: P5D1, P5D2, P5D3, P5D4, P5D5\.

Sources: P5D1, P5D2, P5D3, P5D4, P5D5

## Sources used

- P5D1: Synthetic record; custodian Emmett; recorded 2026\-10\-04; current for this exercise through 2026\-10\-31\. Allowed recipients: Suri, Emmett\.
- P5D2: Synthetic record; custodian ledger custodian Bela; recorded 2026\-10\-04; current for this exercise through 2026\-10\-31\. Allowed recipients: Suri, Emmett\.
- P5D3: Synthetic record; custodian intake observer Bela; recorded 2026\-10\-04; current for this exercise through 2026\-10\-31\. Allowed recipients: Suri, Emmett\.
- P5D4: Synthetic record; custodian Suri; recorded 2026\-10\-01; current for this exercise through 2026\-10\-31\. Allowed recipients: Suri, Emmett\.
- P5D5: Synthetic record; custodian Bela correction addendum; recorded 2026\-10\-04; current for this exercise through 2026\-10\-31\. Allowed recipients: Suri, Emmett\.
